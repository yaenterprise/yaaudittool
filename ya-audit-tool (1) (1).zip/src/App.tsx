import { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileCheck, 
  Database, 
  Percent, 
  CheckCircle, 
  XSquare, 
  FileSpreadsheet,
  TrendingUp,
  AlertCircle,
  Laptop,
  Download,
  Terminal,
  Copy,
  Check,
  ChevronLeft,
  ChevronRight,
  ShoppingBag,
  BookOpen,
  Key,
  ShieldCheck,
  ShieldAlert,
  Mail,
  Cpu,
  Globe,
  Calendar,
  FileText,
  RefreshCw,
  RotateCcw,
  Upload,
  Settings
} from "lucide-react";

import { SheetState, UploadedFile, ValidationRecord, ValidationSummary, GlobalReferenceMapping, IgnoreDigitRule } from "./types";
import MultiFileWorkspace from "./components/MultiFileWorkspace";
import ProductsWorkspace from "./components/ProductsWorkspace";
import ProductMasterWorkspace from "./components/ProductMasterWorkspace";
import WorkspaceReference from "./components/WorkspaceReference";
import LicensePage from "./components/LicensePage";
import MetricCard from "./components/MetricCard";
import ValidationTable from "./components/ValidationTable";
import ProductsReportTable from "./components/ProductsReportTable";
import { loadStoredReferenceFiles } from "./utils/referenceStorage";
import * as XLSX from "xlsx";
import JSZip from "jszip";
import { generateAndDownloadExcel, generateSeparateExcel, generateSeparateCSVAsync, generateSeparateExcelCapped, generateSeparateExcelSplittedAsync } from "./utils/excel";
import { normalizeProducts } from "./utils/parser";
import {
  clearGlobalValidationRecords,
  setGlobalValidationRecords,
  getValidationSummary,
  getAllDisplayRecords,
  PerformanceValidationRecord,
} from "./utils/validationCache";

function isProductMatch(p1: string, p2: string): boolean {
  const norm1 = p1.trim().toLowerCase();
  const norm2 = p2.trim().toLowerCase();
  if (norm1 === norm2) return true;
  
  const parts1 = p1.includes("/") ? p1.split("/").map(p => p.trim().toLowerCase()) : [norm1];
  const parts2 = p2.includes("/") ? p2.split("/").map(p => p.trim().toLowerCase()) : [norm2];
  
  return parts1.some(part => parts2.includes(part));
}

function buildPerformanceRecord(
  key: string,
  aProds: string[],
  bProds: string[],
  cProds: string[]
): PerformanceValidationRecord {
  const isNum = /^\d+$/.test(key);
  const numVal = isNum ? parseInt(key, 10) : NaN;

  const extra_AB_A = aProds.filter(ap => !bProds.some(bp => isProductMatch(ap, bp)));
  const extra_AB_B = bProds.filter(bp => !aProds.some(ap => isProductMatch(ap, bp)));

  const extra_BC_B = bProds.filter(bp => !cProds.some(cp => isProductMatch(bp, cp)));
  const extra_BC_C = cProds.filter(cp => !bProds.some(bp => isProductMatch(bp, cp)));

  const extra_AC_A = aProds.filter(ap => !cProds.some(cp => isProductMatch(ap, cp)));
  const extra_AC_C = cProds.filter(cp => !aProds.some(ap => isProductMatch(ap, cp)));

  const extra_ABC_A = aProds.filter(ap => !bProds.some(bp => isProductMatch(ap, bp)) || !cProds.some(cp => isProductMatch(ap, cp)));
  const extra_ABC_B = bProds.filter(bp => !aProds.some(ap => isProductMatch(ap, bp)) || !cProds.some(cp => isProductMatch(bp, cp)));
  const extra_ABC_C = cProds.filter(cp => !aProds.some(ap => isProductMatch(ap, cp)) || !bProds.some(bp => isProductMatch(bp, cp)));

  const matchAB = extra_AB_A.length === 0 && extra_AB_B.length === 0;
  const matchBC = extra_BC_B.length === 0 && extra_BC_C.length === 0;
  const matchAC = extra_AC_A.length === 0 && extra_AC_C.length === 0;
  const matchABC = matchAB && matchBC;

  const searchIndex = `${key.toLowerCase()}|${aProds.join(",")}|${bProds.join(",")}|${cProds.join(",")}|${extra_AB_A.join(",")}|${extra_AB_B.join(",")}|${extra_BC_B.join(",")}|${extra_BC_C.join(",")}|${extra_AC_A.join(",")}|${extra_AC_C.join(",")}`.toLowerCase();

  return {
    key,
    aProducts: aProds,
    bProducts: bProds,
    cProducts: cProds,
    keyIsNum: isNum,
    keyNumVal: numVal,
    status_AB: matchAB ? "MATCH" : "MISMATCH",
    status_BC: matchBC ? "MATCH" : "MISMATCH",
    status_AC: matchAC ? "MATCH" : "MISMATCH",
    status_ABC: matchABC ? "MATCH" : "MISMATCH",
    extra_AB_A,
    extra_AB_B,
    extra_BC_B,
    extra_BC_C,
    extra_AC_A,
    extra_AC_C,
    extra_ABC_A,
    extra_ABC_B,
    extra_ABC_C,
    searchIndex
  };
}

export default function App() {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [sheets, setSheets] = useState<SheetState[]>([]);
  const [continuitySheets, setContinuitySheets] = useState<boolean>(false);

  const [ignoreDigitEnabled, setIgnoreDigitEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("ya_ignore_digit_enabled");
    return saved === "true";
  });
  const [ignoreZeroProductEnabled, setIgnoreZeroProductEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("ya_ignore_zero_product_enabled");
    return saved !== "false";
  });

  useEffect(() => {
    localStorage.setItem("ya_ignore_zero_product_enabled", ignoreZeroProductEnabled ? "true" : "false");
  }, [ignoreZeroProductEnabled]);
  const [ignoreDigitRules, setIgnoreDigitRules] = useState<IgnoreDigitRule[]>(() => {
    const saved = localStorage.getItem("ya_ignore_digit_rules");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback below
      }
    }
    // Fallback/initial default rule based on old single states
    const oldCas = localStorage.getItem("ya_ignore_digit_cas") || "ALL";
    const oldLength = localStorage.getItem("ya_ignore_digit_length") ? Number(localStorage.getItem("ya_ignore_digit_length")) : 10;
    const oldDir = (localStorage.getItem("ya_ignore_digit_direction") as "FORWARD" | "BACKWARD") || "BACKWARD";
    const oldCount = localStorage.getItem("ya_ignore_digit_count") ? Number(localStorage.getItem("ya_ignore_digit_count")) : 1;
    return [{
      id: "default",
      cas: oldCas,
      length: oldLength,
      direction: oldDir,
      count: oldCount
    }];
  });

  useEffect(() => {
    localStorage.setItem("ya_ignore_digit_enabled", String(ignoreDigitEnabled));
  }, [ignoreDigitEnabled]);

  useEffect(() => {
    localStorage.setItem("ya_ignore_digit_rules", JSON.stringify(ignoreDigitRules));
  }, [ignoreDigitRules]);
  
  const [globalReferenceEnabled, setGlobalReferenceEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("ya_global_reference_enabled");
    return saved === "true";
  });
  
  const [globalReferenceMappings, setGlobalReferenceMappings] = useState<GlobalReferenceMapping[]>(() => {
    const saved = localStorage.getItem("ya_global_reference_mappings");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [{ id: "default", referenceFileId: "", casName: "" }];
  });

  useEffect(() => {
    localStorage.setItem("ya_global_reference_enabled", String(globalReferenceEnabled));
  }, [globalReferenceEnabled]);

  useEffect(() => {
    localStorage.setItem("ya_global_reference_mappings", JSON.stringify(globalReferenceMappings));
  }, [globalReferenceMappings]);

  const [isValidating, setIsValidating] = useState(false);
  const [validationProgress, setValidationProgress] = useState(0);
  const [validationToken, setValidationToken] = useState(0);
  const [comparisonMode, setComparisonMode] = useState<"A_B" | "B_C" | "A_C" | "A_B_C">("A_C");
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportFormatLabel, setExportFormatLabel] = useState<"CSV" | "Excel">("CSV");
  const [isValidationCollapsed, setIsValidationCollapsed] = useState(false);
  const [isSmsPanelCollapsed, setIsSmsPanelCollapsed] = useState(false);
  const [isCasPanelCollapsed, setIsCasPanelCollapsed] = useState(false);
  const [isLogicPanelCollapsed, setIsLogicPanelCollapsed] = useState(false);
  const [activeReportTab, setActiveReportTab] = useState<"DATA_UPLOAD" | "ACTIVE_COUNT" | "PRODUCTS" | "PRODUCT_MASTER" | "WORKSPACE" | "SETTINGS">("DATA_UPLOAD");
  const [isLicensed, setIsLicensed] = useState(() => localStorage.getItem("ya_is_licensed") === "true");
  const [selectedCasFilter, setSelectedCasFilter] = useState("ALL");

  const showCas = comparisonMode === "A_B" || comparisonMode === "A_C" || comparisonMode === "A_B_C";
  const showSms = comparisonMode === "A_B" || comparisonMode === "B_C" || comparisonMode === "A_B_C";
  const showApp = comparisonMode === "B_C" || comparisonMode === "A_C" || comparisonMode === "A_B_C";

  // Clear results if catalog is emptied
  useEffect(() => {
    if (sheets.length === 0) {
      clearGlobalValidationRecords();
      setValidationToken(0);
    }
  }, [sheets]);

  // Proactively suggest optimal comparison mode based on loaded datasets
  useEffect(() => {
    if (validationToken > 0) {
      const hasA = sheets.some(s => s.role === "CAS");
      const hasB = sheets.some(s => s.role === "SMS");
      const hasC = sheets.some(s => s.role === "APP");

      if (hasA && hasB && hasC) {
        setComparisonMode("A_B_C");
      } else {
        setComparisonMode("A_C");
      }
    }
  }, [validationToken, sheets]);

  // Re-run validation automatically when Exclude '0' Product toggle changes
  useEffect(() => {
    if (validationToken > 0 && !isValidating && sheets.length > 0) {
      triggerValidation();
    }
  }, [ignoreZeroProductEnabled]);

  const triggerValidation = async () => {
    const casSheets = sheets.filter(s => s.role === "CAS");
    const smsSheets = sheets.filter(s => s.role === "SMS");
    const appSheets = sheets.filter(s => s.role === "APP");

    const activeCount = (casSheets.length > 0 ? 1 : 0) + (smsSheets.length > 0 ? 1 : 0) + (appSheets.length > 0 ? 1 : 0);
    if (activeCount < 2) return;

    // Automatically collapse SMS Upload, CAS Upload and Attached Logic workspace panels, and expand validation report panel
    setIsSmsPanelCollapsed(true);
    setIsCasPanelCollapsed(true);
    setIsLogicPanelCollapsed(true);
    setIsValidationCollapsed(false);

    setIsValidating(true);
    setValidationProgress(5);
    setSelectedCasFilter("ALL");

    // Allow UI to render loading state immediately
    await new Promise(r => setTimeout(r, 20));

    // Load stored reference files
    let storedReferences: any[] = [];
    try {
      storedReferences = loadStoredReferenceFiles();
    } catch (err) {
      console.error("Error loading stored references for validation:", err);
    }

    // Pre-index global reference mappings by lowercase CAS for O(1) retrieval
    const refByCasLower = new Map<string, any>();
    let defaultRefFile: any = null;
    if (globalReferenceEnabled && globalReferenceMappings.length > 0) {
      globalReferenceMappings.forEach(m => {
        if (!m.referenceFileId) return;
        const ref = storedReferences.find(r => r.id === m.referenceFileId);
        if (!ref) return;
        if (!m.casName || m.casName === "" || m.casName.toUpperCase() === "ALL") {
          if (!defaultRefFile) defaultRefFile = ref;
        } else {
          refByCasLower.set(m.casName.toLowerCase(), ref);
        }
      });
    }

    // Helper function to get the reference file for a given record key (Card ID)
    const getRefFileForRecord = (cardId: string) => {
      if (!globalReferenceEnabled) return null;
      const cardCas = cardToCasMap.get(cardId);
      if (cardCas && refByCasLower.has(cardCas.toLowerCase())) {
        return refByCasLower.get(cardCas.toLowerCase());
      }
      return defaultRefFile;
    };

    // Pre-compile ignore digit rules for O(1) matching
    const allRule = ignoreDigitEnabled ? ignoreDigitRules.find(r => r.cas === "ALL") : null;
    const rulesByCasLower = new Map<string, IgnoreDigitRule>();
    if (ignoreDigitEnabled) {
      ignoreDigitRules.forEach(r => {
        if (r.cas && r.cas !== "ALL") {
          rulesByCasLower.set(r.cas.toLowerCase(), r);
        }
      });
    }

    // Helper to normalize keys if Ignore Digit is active
    const getNormalizedKey = (k: string) => {
      if (!ignoreDigitEnabled) return k;
      const cardCasName = cardToCasMap.get(k) || "";
      const rule = (cardCasName ? rulesByCasLower.get(cardCasName.toLowerCase()) : undefined) || allRule;
      if (rule && k.length > rule.length) {
        if (rule.direction === "BACKWARD") {
          return k.slice(0, Math.max(0, k.length - rule.count));
        } else {
          return k.slice(rule.count);
        }
      }
      return k;
    };

    const filterZeroProduct = (prods: string[]): string[] => {
      if (!ignoreZeroProductEnabled) return prods;
      return prods.filter(p => {
        if (!p) return false;
        const clean = p.split("/")[0].trim();
        return clean !== "0" && clean !== "00";
      });
    };

    setValidationProgress(15);
    await new Promise(r => setTimeout(r, 10));

    // Merge and normalize all CAS sheets (union overlapping keys)
    const rawCasGroup: Record<string, string[]> = {};
    for (const s of casSheets) {
      const associatedCas = s.associatedCasName;
      const parsedData = s.parsedData || {};
      for (const k in parsedData) {
        if (associatedCas) {
          const cardCas = cardToCasMap.get(k);
          if (!cardCas || cardCas.toLowerCase() !== associatedCas.toLowerCase()) {
            continue;
          }
        }
        const finalKey = getNormalizedKey(k);
        if (!rawCasGroup[finalKey]) {
          rawCasGroup[finalKey] = [];
        }
        rawCasGroup[finalKey].push(...parsedData[k]);
      }
    }
    const aData: Record<string, string[]> = {};
    for (const k in rawCasGroup) {
      aData[k] = filterZeroProduct(normalizeProducts(rawCasGroup[k].join(","), "CAS"));
    }

    setValidationProgress(30);
    await new Promise(r => setTimeout(r, 10));

    // Merge and normalize all SMS sheets (union overlapping keys)
    const rawSmsGroup: Record<string, string[]> = {};
    for (const s of smsSheets) {
      const perSheetRefFile = (s.useReferenceFile && s.selectedReferenceFileId)
        ? storedReferences.find(r => r.id === s.selectedReferenceFileId)
        : null;

      const parsedData = s.parsedData || {};
      for (const k in parsedData) {
        const finalKey = getNormalizedKey(k);
        if (!rawSmsGroup[finalKey]) {
          rawSmsGroup[finalKey] = [];
        }
        const productsList = parsedData[k] || [];
        const refFile = globalReferenceEnabled ? getRefFileForRecord(finalKey) : perSheetRefFile;
        const processedProducts = productsList.map(prod => {
          if (refFile && refFile.lookupMap) {
            const mappedVal = refFile.lookupMap[prod];
            if (mappedVal) {
              return `${prod} / ${mappedVal}`;
            }
          }
          return prod;
        });
        rawSmsGroup[finalKey].push(...processedProducts);
      }
    }
    const bData: Record<string, string[]> = {};
    for (const k in rawSmsGroup) {
      bData[k] = filterZeroProduct(normalizeProducts(rawSmsGroup[k].join(","), "SMS"));
    }

    setValidationProgress(45);
    await new Promise(r => setTimeout(r, 10));

    // Merge and normalize all APP sheets (union overlapping keys)
    const rawAppGroup: Record<string, string[]> = {};
    for (const s of appSheets) {
      const perSheetRefFile = (s.useReferenceFile && s.selectedReferenceFileId)
        ? storedReferences.find(r => r.id === s.selectedReferenceFileId)
        : null;

      const parsedData = s.parsedData || {};
      for (const k in parsedData) {
        const finalKey = getNormalizedKey(k);
        if (!rawAppGroup[finalKey]) {
          rawAppGroup[finalKey] = [];
        }
        const productsList = parsedData[k] || [];
        const refFile = globalReferenceEnabled ? getRefFileForRecord(finalKey) : perSheetRefFile;
        const processedProducts = productsList.map(prod => {
          if (refFile && refFile.lookupMap) {
            const mappedVal = refFile.lookupMap[prod];
            if (mappedVal) {
              return `${prod} / ${mappedVal}`;
            }
          }
          return prod;
        });
        rawAppGroup[finalKey].push(...processedProducts);
      }
    }
    const cData: Record<string, string[]> = {};
    for (const k in rawAppGroup) {
      cData[k] = filterZeroProduct(normalizeProducts(rawAppGroup[k].join(","), "APP"));
    }

    setValidationProgress(60);
    await new Promise(r => setTimeout(r, 10));

    // Get union of all keys among CAS, SMS, and APP, filtering by active associated CAS names if specified
    const activeAssociatedCasNames = casSheets
      .map(s => s.associatedCasName)
      .filter((name): name is string => typeof name === "string" && name.trim() !== "");

    const allKeysSet = new Set<string>();
    
    const tryAddKey = (k: string) => {
      if (activeAssociatedCasNames.length > 0) {
        const cardCas = cardToCasMap.get(k);
        if (!cardCas || !activeAssociatedCasNames.some(name => name.toLowerCase() === cardCas.toLowerCase())) {
          return; // Skip key because it doesn't match the associated CAS filter
        }
      }
      allKeysSet.add(k);
    };

    for (const k in aData) tryAddKey(k);
    for (const k in bData) tryAddKey(k);
    for (const k in cData) tryAddKey(k);

    const allKeysRaw = Array.from(allKeysSet);

    setValidationProgress(70);
    await new Promise(r => setTimeout(r, 10));

    // Pre-calculate numerical attributes in O(N) single pass to speed up subsequent O(N log N) sorting comparisons
    const annotatedKeys = allKeysRaw.map(key => {
      const isNum = /^\d+$/.test(key);
      return {
        key,
        isNum,
        numVal: isNum ? parseInt(key, 10) : NaN
      };
    });

    annotatedKeys.sort((a, b) => {
      if (a.isNum && b.isNum) {
        return a.numVal - b.numVal;
      } else if (a.isNum) {
        return -1;
      } else if (b.isNum) {
        return 1;
      } else {
        return a.key.localeCompare(b.key);
      }
    });

    const allKeys = annotatedKeys.map(x => x.key);
    const total = allKeys.length;

    setValidationProgress(75);
    await new Promise(r => setTimeout(r, 10));

    let currentIdx = 0;
    // Break computation into small batches to simulate animation & avoid UI locks
    const batchSize = Math.min(5000, Math.max(500, Math.ceil(total / 50))); 
    const resultsList: PerformanceValidationRecord[] = [];

    const processNextBatch = () => {
      const endIdx = Math.min(currentIdx + batchSize, total);
      
      for (let i = currentIdx; i < endIdx; i++) {
        const key = allKeys[i];
        const aProds = aData[key] || [];
        const bProds = bData[key] || [];
        const cProds = cData[key] || [];

        resultsList.push(buildPerformanceRecord(key, aProds, bProds, cProds));
      }

      currentIdx = endIdx;
      setValidationProgress(Math.floor(75 + (currentIdx / total) * 25));

      if (currentIdx < total) {
        setTimeout(processNextBatch, 15);
      } else {
        setGlobalValidationRecords(resultsList);
        setValidationToken(prev => prev + 1);
        setIsValidating(false);
      }
    };

    setTimeout(processNextBatch, 10);
  };

  // Get map of Card ID -> CAS name from APP sheets (role === "APP") and CAS sheets
  const cardToCasMap = useMemo(() => {
    const map = new Map<string, string>();
    sheets.forEach(sheet => {
      if ((sheet.role === "APP" || sheet.role === "SMS") && sheet.parsedCasData) {
        const casData = sheet.parsedCasData;
        for (const key in casData) {
          const val = casData[key];
          const strVal = String(val === null || val === undefined ? "" : val).trim();
          if (strVal !== "" && !key.includes("_")) {
            map.set(key, strVal);
          }
        }
      }
    });
    // Fallback: Populate from CAS sheets for keys not present in APP sheets
    sheets.forEach(sheet => {
      if (sheet.role === "CAS" && sheet.associatedCasName) {
        const associatedCas = sheet.associatedCasName.trim();
        if (associatedCas && sheet.parsedData) {
          const parsedData = sheet.parsedData;
          for (const key in parsedData) {
            if (!map.has(key)) {
              map.set(key, associatedCas);
            }
          }
        }
      }
    });

    // Expand map with normalized keys if Ignore Digit is active
    if (ignoreDigitEnabled && ignoreDigitRules.length > 0) {
      const allRule = ignoreDigitRules.find(r => r.cas === "ALL");
      const rulesByCas = new Map<string, IgnoreDigitRule>();
      ignoreDigitRules.forEach(r => {
        if (r.cas && r.cas !== "ALL") {
          rulesByCas.set(r.cas.toLowerCase(), r);
        }
      });

      const keysToAdd: [string, string][] = [];
      map.forEach((casName, originalKey) => {
        const rule = (casName ? rulesByCas.get(casName.toLowerCase()) : undefined) || allRule;
        if (rule && originalKey.length > rule.length) {
          const normalizedKey = rule.direction === "BACKWARD"
            ? originalKey.slice(0, Math.max(0, originalKey.length - rule.count))
            : originalKey.slice(rule.count);
          if (normalizedKey && normalizedKey !== originalKey && !map.has(normalizedKey)) {
            keysToAdd.push([normalizedKey, casName]);
          }
        }
      });
      for (let i = 0; i < keysToAdd.length; i++) {
        map.set(keysToAdd[i][0], keysToAdd[i][1]);
      }
    }

    return map;
  }, [sheets, ignoreDigitEnabled, ignoreDigitRules]);

  const uploadedCasNames = useMemo<Set<string>>(() => {
    const names = new Set<string>();
    sheets.forEach((sheet) => {
      if (sheet.role === "CAS" && sheet.associatedCasName) {
        const cleanName = sheet.associatedCasName.trim().toLowerCase();
        if (cleanName) {
          names.add(cleanName);
        }
      }
    });
    return names;
  }, [sheets]);

  const summary = useMemo(() => {
    if (validationToken === 0) return null;
    return getValidationSummary(comparisonMode, selectedCasFilter, cardToCasMap);
  }, [validationToken, comparisonMode, selectedCasFilter, cardToCasMap]);

  const handleDownloadExcel = async (
    exportType: "ALL" | "MATCH" | "MISMATCH" | "ONLY_A" | "ONLY_B" | "ONLY_C" | "A_DATA" | "B_DATA" | "C_DATA" = "ALL",
    format: "CSV" | "EXCEL" = "CSV",
    casFilter: string = selectedCasFilter
  ) => {
    if (validationToken === 0) return;

    const fileExtension = format === "CSV" ? "csv" : "xlsx";
    const casTag = casFilter && casFilter !== "ALL" ? `_${casFilter.replace(/[^a-zA-Z0-9_-]/g, "_")}` : "_ALL_CAS";

    let fileName = "";
    if (exportType === "ALL") fileName = `Validation_Report_${comparisonMode}${casTag}.${fileExtension}`;
    else if (exportType === "MATCH") fileName = `Validation_Report_${comparisonMode}_MATCH${casTag}.${fileExtension}`;
    else if (exportType === "MISMATCH") fileName = `Validation_Report_${comparisonMode}_MISMATCH${casTag}.${fileExtension}`;
    else if (exportType === "ONLY_A") fileName = `CAS_ONLY_Report${casTag}.${fileExtension}`;
    else if (exportType === "ONLY_B") fileName = `SMS_B_ONLY_Report${casTag}.${fileExtension}`;
    else if (exportType === "ONLY_C") fileName = `SMS_S_ONLY_Report${casTag}.${fileExtension}`;
    else if (exportType === "A_DATA") fileName = `CAS_C_DATA_Report${casTag}.${fileExtension}`;
    else if (exportType === "B_DATA") fileName = `SMS_B_DATA_Report${casTag}.${fileExtension}`;
    else if (exportType === "C_DATA") fileName = `SMS_S_DATA_Report${casTag}.${fileExtension}`;
    else fileName = `Validation_Report_${exportType}${casTag}.${fileExtension}`;

    setExportFormatLabel(format === "CSV" ? "CSV" : "Excel");
    setIsExporting(true);
    setExportProgress(0);

    try {
      if (format === "CSV") {
        // High performance async CSV generation split into parts of 1,000,000 rows each
        const parts = await generateSeparateCSVAsync(
          exportType,
          comparisonMode,
          (percent) => {
            // CSV parsing accounts for 0-85% of progress
            setExportProgress(Math.floor(percent * 0.85));
          },
          casFilter,
          cardToCasMap,
          uploadedCasNames
        );

        if (parts.length === 1) {
          // Single file: Direct CSV download
          const partObj = parts[0];
          const url = URL.createObjectURL(partObj.blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = fileName;
          document.body.appendChild(a);
          a.click();

          setTimeout(() => {
            if (document.body.contains(a)) {
              document.body.removeChild(a);
            }
            URL.revokeObjectURL(url);
          }, 100);
        } else if (parts.length > 1) {
          // Multi-part file: Package cleanly into a single ZIP file
          setExportProgress(88);
          const zip = new JSZip();

          for (let i = 0; i < parts.length; i++) {
            const partObj = parts[i];
            const partFileName = fileName.replace(/\.csv$/, `_Part${partObj.part}.csv`);
            zip.file(partFileName, partObj.blob);
          }

          const zipBlob = await zip.generateAsync(
            {
              type: "blob",
              compression: "DEFLATE",
              compressionOptions: { level: 6 }
            },
            (metadata) => {
              setExportProgress(88 + Math.floor((metadata.percent * 0.12)));
            }
          );

          const zipFileName = fileName.replace(/\.csv$/, ".zip");
          const url = URL.createObjectURL(zipBlob);
          const a = document.createElement("a");
          a.href = url;
          a.download = zipFileName;
          document.body.appendChild(a);
          a.click();

          setTimeout(() => {
            if (document.body.contains(a)) {
              document.body.removeChild(a);
            }
            URL.revokeObjectURL(url);
          }, 100);
        }
      } else {
        // Fully asynchronous Excel generation split across sheets when rows exceed 1,000,000
        const wb = await generateSeparateExcelSplittedAsync(
          exportType,
          comparisonMode,
          (percent) => {
            setExportProgress(percent);
          },
          casFilter,
          cardToCasMap,
          uploadedCasNames
        );

        XLSX.writeFile(wb, fileName);
        setExportProgress(100);
      }
    } catch (error) {
      console.error("Export failed:", error);
    } finally {
      // Keep loader visible briefly so user sees the 100% completion state
      setTimeout(() => {
        setIsExporting(false);
      }, 600);
    }
  };

  const renderValidationReport = () => {
    return (
      <div className="flex-1 flex flex-col gap-3 min-h-0 h-full w-full">
        {/* Validation Progress Indicator */}
        <AnimatePresence>
          {isValidating && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-slate-900/40 backdrop-blur-sm border border-slate-700/80 rounded-2xl p-6 text-center shadow-lg space-y-4">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300 max-w-md mx-auto">
                  <span className="flex items-center space-x-1.5">
                    <TrendingUp size={13} className="text-indigo-400 animate-pulse" />
                    <span>Crunching matrices...</span>
                  </span>
                  <span className="font-mono text-indigo-400">{validationProgress}%</span>
                </div>
                <div className="w-full max-w-md bg-slate-950 rounded-full h-2.5 mx-auto overflow-hidden border border-slate-800">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${validationProgress}%` }}
                    transition={{ ease: "easeOut", duration: 0.15 }}
                    className="bg-indigo-500 h-full rounded-full shadow-[0_0_12px_rgba(99,102,241,0.5)]"
                  />
                </div>
                <p className="text-[11px] text-slate-500">Removing hidden spaces and calculating key status ratios</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Summary Metric Dashboard and Validation Table Grid View */}
        <div className="flex-1 min-h-0 lg:h-full lg:flex lg:flex-col lg:overflow-hidden relative">
          <AnimatePresence mode="wait">
            {summary ? (
              <motion.div
                key="summary-results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.35 }}
                className="space-y-3 flex-1 min-h-0 lg:h-full lg:flex lg:flex-col lg:overflow-hidden"
              >
                {/* Compact Metrics & Highlights Single Row Layout */}
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-3 items-stretch shrink-0">
                  <div className={`${(summary.onlyInA > 0 || summary.onlyInB > 0 || (summary.onlyInC && summary.onlyInC > 0)) ? "xl:col-span-8" : "xl:col-span-12"} grid grid-cols-2 lg:grid-cols-4 gap-2.5`}>
                    <MetricCard
                      label="Match Alignment"
                      value={`${summary.matchRate}%`}
                      description={`${summary.matchCount}/${summary.totalKeys}`}
                      colorClass="bg-emerald-500 text-emerald-600"
                      icon={<Percent size={13} />}
                    />
                    <MetricCard
                      label="Aligned Records"
                      value={summary.matchCount}
                      description="Matched completely"
                      colorClass="bg-emerald-500 text-emerald-600"
                      icon={<CheckCircle size={13} />}
                    />
                    <MetricCard
                      label="Mismatches"
                      value={summary.mismatchCount}
                      description="Missing/extra codes"
                      colorClass="bg-rose-500 text-rose-600"
                      icon={<XSquare size={13} />}
                    />
                    <MetricCard
                      label="Lookup Keys Base"
                      value={summary.totalKeys}
                      description="Total union evaluated"
                      colorClass="bg-indigo-555 text-indigo-400"
                      icon={<Database size={13} />}
                    />
                  </div>

                  {/* Compact Side-by-Side Highlights Panel */}
                  {(summary.onlyInA > 0 || summary.onlyInB > 0 || (summary.onlyInC && summary.onlyInC > 0)) && (
                    <div className="xl:col-span-4 bg-amber-500/[0.02] border border-amber-500/15 p-2.5 rounded-lg flex items-start gap-2.5 text-xs text-amber-300 leading-normal">
                      <AlertCircle size={13} className="shrink-0 text-amber-500 mt-0.5" />
                      <div className="space-y-1 w-full flex-1 min-h-0">
                        <span className="font-bold text-[10.5px] text-amber-400 block tracking-tight">Key Presence Highlights</span>
                        <div className="flex flex-col gap-0.5 text-amber-200/90 text-[10.5px]">
                          {summary.onlyInA > 0 && (
                            <div className="flex justify-between items-center border-b border-amber-500/10 pb-0.5 last:border-0 last:pb-0">
                              <span>In CAS(C) Only</span>
                              <strong className="font-semibold font-mono text-amber-300 bg-amber-500/10 px-1 py-0.2 rounded">{summary.onlyInA} VC</strong>
                            </div>
                          )}
                          {summary.onlyInB > 0 && (
                            <div className="flex justify-between items-center border-b border-amber-500/10 pb-0.5 last:border-0 last:pb-0">
                              <span>In SMS(B) Only</span>
                              <strong className="font-semibold font-mono text-amber-300 bg-amber-500/10 px-1 py-0.2 rounded">{summary.onlyInB} VC</strong>
                            </div>
                          )}
                           {summary.onlyInC && summary.onlyInC > 0 && (
                             <div className="flex justify-between items-center last:border-0">
                               <span>In SMS(S) Only</span>
                               <strong className="font-semibold font-mono text-amber-300 bg-amber-500/10 px-1 py-0.2 rounded">{summary.onlyInC} VC</strong>
                             </div>
                           )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Data Table */}
                <div className="flex-1 min-h-0 lg:h-full lg:flex lg:flex-col lg:overflow-hidden">
                  <ValidationTable
                    records={[]}
                    onDownloadExcel={handleDownloadExcel}
                    comparisonMode={comparisonMode}
                    summaryStats={summary}
                    sheets={sheets}
                    selectedCasFilter={selectedCasFilter}
                    onCasFilterChange={setSelectedCasFilter}
                    ignoreDigitEnabled={ignoreDigitEnabled}
                    ignoreDigitRules={ignoreDigitRules}
                    ignoreZeroProductEnabled={ignoreZeroProductEnabled}
                    onIgnoreZeroProductToggle={setIgnoreZeroProductEnabled}
                  />
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="empty-instructions"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-slate-900/20 border border-slate-800/80 rounded-3xl p-10 text-center space-y-6 flex-1 flex flex-col justify-center items-center min-h-0 h-full w-full"
              >
                <div className="mx-auto w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 flex items-center justify-center">
                  <FileCheck size={28} />
                </div>
                <div className="space-y-2 max-w-md mx-auto">
                  <h3 className="text-base font-bold text-slate-100">Audit & Validation Report</h3>
                  <p className="text-xs text-slate-400 leading-relaxed font-sans">
                    Your master comparisons and difference highlights will display in this wide report view.
                  </p>
                </div>

                <div className="max-w-md mx-auto p-4 bg-slate-950/40 rounded-2xl border border-slate-850/60 text-left space-y-3">
                  <span className="text-[10px] font-extrabold uppercase text-indigo-400 tracking-wider">Quick Instructions:</span>
                  <ul className="text-[11px] text-slate-400 space-y-2 font-sans list-decimal pl-4">
                    <li>Use the left panel to drop or select your <strong>CAS (C)</strong> or <strong>SMS (S)</strong> files.</li>
                    <li>Double check that column mappings match your sheets' headers.</li>
                    <li>Click the button above to execute validation rules and extract mismatches.</li>
                  </ul>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    );
  };


  return (
    <div id="app-root" className="min-h-screen lg:h-screen lg:overflow-hidden bg-[#090d16] text-slate-200 pb-12 lg:pb-0 font-sans antialiased flex flex-col">
      {/* Dynamic Upper Top Bar */}
      <header className="sticky top-0 z-40 bg-slate-900/50 backdrop-blur-md border-b border-slate-800/80 shrink-0">
        <div className="max-w-full px-3 sm:px-6 md:px-8 lg:px-10 py-2.5 flex flex-col xl:flex-row items-center justify-between gap-3 xl:gap-4">
          <div className="flex items-center space-x-2.5 shrink-0">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 text-white shadow-lg shadow-indigo-990/40 flex items-center justify-center">
              <FileCheck size={18} />
            </div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight shrink-0 whitespace-nowrap">
                YA AUDIT TOOL
              </h1>
              <span className="px-2 py-0.5 bg-violet-500/10 border border-violet-500/35 text-violet-400 rounded-lg font-bold text-[9.5px] flex items-center gap-1 shadow-sm shrink-0 whitespace-nowrap">
                <span className="w-1.5 h-1.5 rounded-full bg-violet-500"></span>
                <span>CAS vs SMS (C vs S)</span>
              </span>
            </div>
          </div>

          {/* Primary Navigation Switcher: [DATA UPLOAD, ACTIVE COUNT, PRODUCTS, PRODUCT MASTER DATA, REFERENCE, SETTINGS] */}
          <div className="flex items-center flex-nowrap gap-1.5 sm:gap-2 shrink-0 overflow-x-auto max-w-full py-0.5">
            {/* Core Workspaces: DATA UPLOAD, ACTIVE COUNT, PRODUCTS, PRODUCT MASTER DATA */}
            <div className="flex items-center bg-slate-950/80 p-0.5 sm:p-1 rounded-xl border border-slate-800/90 shadow-inner shrink-0">
              <button
                type="button"
                onClick={() => setActiveReportTab("DATA_UPLOAD")}
                className={`px-2.5 sm:px-3 lg:px-3.5 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold tracking-wide transition-all cursor-pointer select-none flex items-center gap-1.5 whitespace-nowrap ${
                  activeReportTab === "DATA_UPLOAD"
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/50"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                }`}
              >
                <Upload size={12} className="shrink-0" />
                <span>DATA UPLOAD</span>
                {files.length > 0 && (
                  <span className="text-[9px] bg-slate-900 border border-slate-700 px-1 py-0.2 rounded font-mono font-bold text-slate-300">
                    {files.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setActiveReportTab("ACTIVE_COUNT")}
                className={`px-2.5 sm:px-3 lg:px-3.5 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold tracking-wide transition-all cursor-pointer select-none flex items-center gap-1.5 whitespace-nowrap ${
                  activeReportTab === "ACTIVE_COUNT"
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/50"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                }`}
              >
                <Database size={12} className="shrink-0" />
                <span>ACTIVE COUNT</span>
                {!isLicensed && <span className="text-[8.5px] bg-rose-950 text-rose-400 border border-rose-800 px-1 py-0.2 rounded font-mono font-bold">LOCKED</span>}
                {summary && (
                  <span className={`text-[9px] px-1 py-0.2 rounded font-mono font-bold ${summary.mismatchCount > 0 ? "bg-amber-950/80 border border-amber-800/60 text-amber-300" : "bg-emerald-950/80 border border-emerald-800/60 text-emerald-300"}`}>
                    {summary.matchRate}%
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setActiveReportTab("PRODUCTS")}
                className={`px-2.5 sm:px-3 lg:px-3.5 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold tracking-wide transition-all cursor-pointer select-none flex items-center gap-1.5 whitespace-nowrap ${
                  activeReportTab === "PRODUCTS"
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/50"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                }`}
              >
                <ShoppingBag size={12} className="shrink-0" />
                <span>PRODUCTS</span>
                {!isLicensed && <span className="text-[8.5px] bg-rose-950 text-rose-400 border border-rose-800 px-1 py-0.2 rounded font-mono font-bold">LOCKED</span>}
              </button>

              <button
                type="button"
                onClick={() => setActiveReportTab("PRODUCT_MASTER")}
                className={`px-2.5 sm:px-3 lg:px-3.5 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold tracking-wide transition-all cursor-pointer select-none flex items-center gap-1.5 whitespace-nowrap ${
                  activeReportTab === "PRODUCT_MASTER"
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/50"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                }`}
              >
                <FileSpreadsheet size={12} className="shrink-0" />
                <span>PRODUCT MASTER DATA</span>
                {!isLicensed && <span className="text-[8.5px] bg-rose-950 text-rose-400 border border-rose-800 px-1 py-0.2 rounded font-mono font-bold">LOCKED</span>}
              </button>
            </div>

            {/* Utility Workspaces: REFERENCE & SETTINGS */}
            <div className="flex items-center bg-slate-950/80 p-0.5 sm:p-1 rounded-xl border border-slate-800/90 shadow-inner shrink-0">
              <button
                type="button"
                onClick={() => setActiveReportTab("WORKSPACE")}
                className={`px-2.5 sm:px-3 lg:px-3.5 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold tracking-wide transition-all cursor-pointer select-none flex items-center gap-1.5 whitespace-nowrap ${
                  activeReportTab === "WORKSPACE"
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/50"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                }`}
              >
                <BookOpen size={12} className="shrink-0" />
                <span>REFERENCE</span>
                {!isLicensed && <span className="text-[8.5px] bg-rose-950 text-rose-400 border border-rose-800 px-1 py-0.2 rounded font-mono font-bold">LOCKED</span>}
              </button>
              <button
                type="button"
                onClick={() => setActiveReportTab("SETTINGS")}
                className={`px-2.5 sm:px-3 lg:px-3.5 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold tracking-wide transition-all cursor-pointer select-none flex items-center gap-1.5 whitespace-nowrap ${
                  activeReportTab === "SETTINGS"
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/50"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                }`}
              >
                <Settings size={12} className="shrink-0" />
                <span>SETTINGS</span>
              </button>
            </div>
          </div>

          <div className="flex flex-row items-center gap-2.5 shrink-0 justify-end">
            {/* License Indicator */}
            <div className="flex items-center space-x-2 shrink-0">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                License:
              </span>
              {isLicensed ? (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 border border-emerald-500/25 text-emerald-400 flex items-center space-x-1">
                  <ShieldCheck size={11} className="text-emerald-400" />
                  <span>LICENSED</span>
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-500/15 border border-rose-500/30 text-rose-400 flex items-center space-x-1">
                  <AlertCircle size={11} className="text-rose-400" />
                  <span>EXPIRED / UNLICENSED</span>
                </span>
              )}
            </div>

            <div className="flex items-center space-x-2 shrink-0">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                Status:
              </span>
              {sheets.length > 0 ? (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center space-x-1 animate-pulse">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 block"></span>
                  <span>{sheets.length} SHEETS WORKSPACE ACTIVE</span>
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-800 border border-slate-700 text-slate-400 flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-600 block"></span>
                  <span>EMPTY WORKSPACE</span>
                </span>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-full px-4 sm:px-8 md:px-12 lg:px-16 mt-3 flex-1 min-h-0 lg:overflow-hidden flex flex-col pb-3 space-y-3">
        {!isLicensed && activeReportTab !== "SETTINGS" ? (
          <div className="flex-1 flex items-center justify-center py-12 px-4">
            <div className="bg-slate-900/90 border border-rose-900/60 rounded-3xl p-8 sm:p-12 text-center max-w-xl w-full shadow-2xl space-y-6 relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl pointer-events-none"></div>
              <div className="w-16 h-16 mx-auto bg-rose-950/80 border border-rose-800/80 rounded-2xl flex items-center justify-center text-rose-400 shadow-xl">
                <ShieldAlert size={32} />
              </div>
              <div className="space-y-3">
                <h2 className="text-xl font-extrabold text-white uppercase tracking-wider font-mono">
                  Application is Unlicensed
                </h2>
                <div className="p-4 bg-rose-950/40 rounded-2xl border border-rose-900/50 text-sm font-semibold text-slate-200 leading-relaxed">
                  This application is currently unlicensed or the active key has expired.
                  To restore full system functionality, please renew your authorization license by contacting{" "}
                  <a
                    href="mailto:support@yatech.co.in"
                    className="text-indigo-400 hover:text-indigo-300 underline font-extrabold transition"
                  >
                    support@yatech.co.in
                  </a>
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800/80 font-mono text-xs text-slate-400 space-y-2 text-left">
                <div className="flex items-center justify-center border-b border-slate-800/60 pb-2">
                  <span className="text-rose-400 font-bold px-3 py-1 bg-rose-950/60 border border-rose-800/60 rounded-lg text-center">
                    LOCKED (UNLICENSED)
                  </span>
                </div>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-slate-500 uppercase">RENEWAL CONTACT:</span>
                  <a href="mailto:accounts@yatech.co.in" className="text-indigo-300 font-bold hover:underline">
                    accounts@yatech.co.in
                  </a>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setActiveReportTab("SETTINGS")}
                  className="w-full sm:w-auto px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-950/50 transition cursor-pointer flex items-center justify-center space-x-2"
                >
                  <Key size={14} />
                  <span>Activate License (.key)</span>
                </button>
                <a
                  href="mailto:accounts@yatech.co.in"
                  className="w-full sm:w-auto px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase tracking-wider rounded-xl border border-slate-700 transition flex items-center justify-center space-x-2"
                >
                  <Mail size={14} />
                  <span>Contact Accounts</span>
                </a>
              </div>
            </div>
          </div>
        ) : null}

        {/* 1. DATA UPLOAD Tab: Common File Upload Area and Attached Logic Assign */}
        <div className={!isLicensed && activeReportTab !== "SETTINGS" ? "hidden" : activeReportTab === "DATA_UPLOAD" ? "space-y-3 flex-1 min-h-0 lg:overflow-hidden flex flex-col" : "hidden"}>
          {/* Top Quick Navigation & Actions Banner */}
          <div className="bg-slate-900/40 border border-slate-800/80 p-2.5 px-4 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3 shrink-0 shadow-md">
            <div className="flex items-center gap-3 w-full md:w-auto">
              <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shrink-0">
                <Upload size={16} />
              </div>
              <div>
                <h2 className="text-xs font-black text-slate-100 uppercase tracking-wider flex items-center gap-2">
                  <span>Data Upload & Logic Configuration</span>
                  <span className="px-2 py-0.2 text-[9.5px] font-bold rounded-full bg-indigo-950 text-indigo-300 border border-indigo-500/30">
                    3 Layout: SMS UPLOAD | CAS UPLOAD | ATTACHED LOGIC ASSIGN
                  </span>
                </h2>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Upload transaction files across three dedicated layout sections. Configured mappings apply to both Active Count and Products validations.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto shrink-0 justify-end">
              <button
                type="button"
                onClick={() => {
                  setActiveReportTab("ACTIVE_COUNT");
                  if (sheets.some(s => s.role === "CAS") && sheets.some(s => s.role === "APP" || s.role === "SMS")) {
                    triggerValidation();
                  }
                }}
                className="px-3.5 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white shadow-lg shadow-indigo-950/40 hover:scale-[1.01] active:scale-[0.99] transition flex items-center gap-1.5 cursor-pointer"
              >
                <Database size={13} />
                <span>VALIDATE ACTIVE COUNT →</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveReportTab("PRODUCTS")}
                className="px-3.5 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-lg shadow-emerald-950/40 hover:scale-[1.01] active:scale-[0.99] transition flex items-center gap-1.5 cursor-pointer"
              >
                <ShoppingBag size={13} />
                <span>VALIDATE PRODUCTS →</span>
              </button>
            </div>
          </div>

          {/* MultiFileWorkspace handles 3 Layout: SMS UPLOAD | CAS UPLOAD | ATTACHED LOGIC ASSIGN */}
          <div className="flex-1 min-h-0 lg:overflow-hidden flex flex-col">
            <MultiFileWorkspace 
              sheets={sheets}
              setSheets={setSheets}
              files={files}
              setFiles={setFiles}
              onStartValidation={() => {
                setActiveReportTab("ACTIVE_COUNT");
                triggerValidation();
              }}
              isValidating={isValidating}
              showCas={showCas}
              showSms={showSms}
              showApp={showApp}
              isSmsPanelCollapsed={isSmsPanelCollapsed}
              setIsSmsPanelCollapsed={setIsSmsPanelCollapsed}
              isCasPanelCollapsed={isCasPanelCollapsed}
              setIsCasPanelCollapsed={setIsCasPanelCollapsed}
              isLogicPanelCollapsed={isLogicPanelCollapsed}
              setIsLogicPanelCollapsed={setIsLogicPanelCollapsed}
              continuitySheets={continuitySheets}
              setContinuitySheets={setContinuitySheets}
              globalReferenceEnabled={globalReferenceEnabled}
              setGlobalReferenceEnabled={setGlobalReferenceEnabled}
              globalReferenceMappings={globalReferenceMappings}
              setGlobalReferenceMappings={setGlobalReferenceMappings}
              ignoreDigitEnabled={ignoreDigitEnabled}
              setIgnoreDigitEnabled={setIgnoreDigitEnabled}
              ignoreDigitRules={ignoreDigitRules}
              setIgnoreDigitRules={setIgnoreDigitRules}
              isLicensed={isLicensed}
              onNavigateToReference={() => setActiveReportTab("WORKSPACE")}
            />
          </div>
        </div>

        {/* 2. ACTIVE COUNT Tab: Dedicated Full-Width Active Count Validation */}
        <div className={!isLicensed && activeReportTab !== "SETTINGS" ? "hidden" : activeReportTab === "ACTIVE_COUNT" ? "space-y-3 flex-1 min-h-0 lg:overflow-hidden flex flex-col" : "hidden"}>
          {/* Top Control & Action Bar for Active Count */}
          <div className="bg-slate-900/40 border border-slate-800/80 p-2.5 px-4 rounded-2xl flex flex-col lg:flex-row items-center justify-between gap-3 shrink-0 shadow-md">
            <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shrink-0">
                  <Database size={15} />
                </div>
                <div>
                  <h2 className="text-xs font-black text-slate-100 uppercase tracking-wider">
                    Active Count Validation
                  </h2>
                  <span className="text-[10.5px] text-slate-400">
                    Source: <strong className="text-emerald-400">{sheets.filter(s => s.role === "CAS").length} CAS</strong> and <strong className="text-violet-400">{sheets.filter(s => s.role === "APP" || s.role === "SMS").length} SMS/APP</strong> sheets loaded
                  </span>
                </div>
              </div>

              {/* Quick jump to DATA UPLOAD to change files or logic */}
              <button
                type="button"
                onClick={() => setActiveReportTab("DATA_UPLOAD")}
                className="px-2.5 py-1.5 rounded-xl text-[11px] font-bold bg-slate-950 border border-slate-800 hover:border-indigo-500/50 text-slate-300 hover:text-white transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                title="Edit uploaded files or attached logic in DATA UPLOAD"
              >
                <Upload size={12} className="text-indigo-400" />
                <span>Edit Upload & Logic</span>
              </button>
            </div>

            {/* Actions: Reset & Prominent VALIDATE ACTIVE COUNT button */}
            <div className="flex items-center gap-2.5 w-full lg:w-auto shrink-0 justify-end">
              {files.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (confirm("Reset active count validation results?")) {
                      clearGlobalValidationRecords();
                      setValidationToken(0);
                    }
                  }}
                  className="px-3 py-2 bg-slate-950 hover:bg-slate-850 text-slate-300 hover:text-rose-400 border border-slate-800/80 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer shadow-sm"
                >
                  <RotateCcw size={12} />
                  <span>RESET</span>
                </button>
              )}

              <button
                type="button"
                onClick={triggerValidation}
                disabled={((sheets.filter(s => s.role === "CAS").length === 0 || sheets.filter(s => s.role === "APP" || s.role === "SMS").length === 0) || isValidating)}
                className={`py-2 px-5 rounded-xl text-xs font-black tracking-wide transition-all flex items-center space-x-2 shadow-lg cursor-pointer ${
                  (sheets.filter(s => s.role === "CAS").length > 0 && sheets.filter(s => s.role === "APP" || s.role === "SMS").length > 0)
                    ? "bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white shadow-indigo-950/40 hover:scale-[1.01] active:scale-[0.99]"
                    : "bg-slate-800/50 text-slate-500 border border-slate-800/60 cursor-not-allowed"
                }`}
              >
                <RefreshCw size={13} className={isValidating ? "animate-spin" : ""} />
                <span>{isValidating ? "VALIDATING..." : "VALIDATE ACTIVE COUNT"}</span>
              </button>
            </div>
          </div>

          {/* Validation Report Content View (Full Width) */}
          <div className="flex-1 min-h-0 overflow-hidden relative flex flex-col">
            {renderValidationReport()}
          </div>
        </div>

        {/* 3. PRODUCTS Tab: Product Validation using Common Files and Master Catalog */}
        <div className={!isLicensed && activeReportTab !== "SETTINGS" ? "hidden" : activeReportTab === "PRODUCTS" ? "flex-1 min-h-0 lg:overflow-hidden flex flex-col" : "hidden"}>
          <ProductsWorkspace 
            files={files}
            setFiles={setFiles}
            sheets={sheets}
            setSheets={setSheets}
            continuitySheets={continuitySheets}
            setContinuitySheets={setContinuitySheets}
            globalReferenceEnabled={globalReferenceEnabled}
            setGlobalReferenceEnabled={setGlobalReferenceEnabled}
            globalReferenceMappings={globalReferenceMappings}
            setGlobalReferenceMappings={setGlobalReferenceMappings}
            ignoreDigitEnabled={ignoreDigitEnabled}
            setIgnoreDigitEnabled={setIgnoreDigitEnabled}
            ignoreDigitRules={ignoreDigitRules}
            setIgnoreDigitRules={setIgnoreDigitRules}
            ignoreZeroProductEnabled={ignoreZeroProductEnabled}
            setIgnoreZeroProductEnabled={setIgnoreZeroProductEnabled}
            onNavigateToTab={(tab) => setActiveReportTab(tab)}
          />
        </div>

        {/* 4. PRODUCT MASTER DATA Tab: Standalone Product Master Catalog Workspace */}
        <div className={!isLicensed && activeReportTab !== "SETTINGS" ? "hidden" : activeReportTab === "PRODUCT_MASTER" ? "flex-1 min-h-0 lg:overflow-hidden flex flex-col" : "hidden"}>
          <ProductMasterWorkspace 
            onNavigateToProducts={() => setActiveReportTab("PRODUCTS")}
          />
        </div>

        {/* 5. Reference Tab */}
        <div className={!isLicensed && activeReportTab !== "SETTINGS" ? "hidden" : activeReportTab === "WORKSPACE" ? "flex-1 min-h-0 lg:overflow-hidden flex flex-col" : "hidden"}>
          <WorkspaceReference files={files} setFiles={setFiles} />
        </div>

        {/* 6. Settings / License Tab */}
        <div className={activeReportTab === "SETTINGS" ? "flex-1 min-h-0 lg:overflow-hidden flex flex-col" : "hidden"}>
          <LicensePage onLicenseChange={(isLic) => setIsLicensed(isLic)} />
        </div>
      </main>

      {/* Global Application Footer */}
      <footer className="px-4 sm:px-8 py-2.5 bg-slate-950/80 border-t border-slate-900/80 flex flex-col sm:flex-row justify-between items-center gap-2 text-[10px] text-slate-500 font-mono shrink-0 select-none">
        <div className="flex items-center space-x-2">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="font-bold text-slate-400">YA Audit Tool Client Service</span>
        </div>
        <div className="text-slate-400 font-medium text-center sm:text-right">
          Copyright © 2026 YA ENTERPRISE Technologies Private Limited. All rights reserved.
        </div>
      </footer>

      {/* High Performance Export Progress Modal */}
      <AnimatePresence>
        {isExporting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-2xl max-w-sm w-full space-y-4"
            >
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-emerald-500/15 border border-emerald-500/20 text-emerald-400 rounded-xl animate-pulse">
                  <FileSpreadsheet size={22} />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Generating Clean Export</h3>
                  <p className="text-[11px] text-slate-400">Format: {exportFormatLabel} File</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="h-2 bg-slate-950 border border-slate-800/80 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"
                    style={{ width: `${exportProgress}%` }}
                    transition={{ ease: "easeInOut", duration: 0.2 }}
                  />
                </div>
                <div className="flex justify-between text-[11px] font-mono text-slate-400">
                  <span>Progressing chunks...</span>
                  <span className="font-bold text-emerald-400">{exportProgress}%</span>
                </div>
              </div>

              <p className="text-[10.5px] text-slate-400/90 leading-relaxed bg-slate-950 p-2.5 rounded-lg border border-slate-800/60">
                {exportFormatLabel === "CSV" 
                  ? "✓ Building file chunk-by-chunk in background memory to keep your Chrome page fluid and prevent browser crashes."
                  : "✓ Packing first 100,000 records into a compressed Excel workbook to respect browser heap limits."}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>


    </div>
  );
}
