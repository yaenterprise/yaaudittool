import { SheetState } from "../types";

const sheetCasCache = new WeakMap<SheetState, string[]>();

/**
 * Fast cached retrieval of unique CAS names associated with or detected within a sheet.
 * Guaranteed O(1) after the first computation for a sheet instance.
 */
export function getSheetUniqueCasNames(sheet: SheetState): string[] {
  if (sheet.uniqueCasNames && Array.isArray(sheet.uniqueCasNames)) {
    return sheet.uniqueCasNames;
  }
  if (sheetCasCache.has(sheet)) {
    return sheetCasCache.get(sheet)!;
  }
  const set = new Set<string>();
  if (sheet.associatedCasName && sheet.associatedCasName.trim()) {
    set.add(sheet.associatedCasName.trim());
  }
  if (sheet.parsedCasData) {
    const vals = Object.values(sheet.parsedCasData);
    for (let i = 0; i < vals.length; i++) {
      const val = vals[i];
      if (typeof val === "string") {
        const trimmed = val.trim();
        if (trimmed && !trimmed.includes("_")) {
          set.add(trimmed);
        }
      }
    }
  }
  const result = Array.from(set).sort((a, b) => a.localeCompare(b));
  sheetCasCache.set(sheet, result);
  return result;
}

/**
 * Fast aggregated retrieval of all unique CAS names across sheets.
 * Combines cached sheet-level results without iterating millions of card keys.
 */
export function getAllUniqueCasNames(sheets: SheetState[]): string[] {
  const map = new Map<string, string>();
  for (let i = 0; i < sheets.length; i++) {
    const s = sheets[i];
    if (s.role === "SKIP") continue;
    const list = getSheetUniqueCasNames(s);
    for (let j = 0; j < list.length; j++) {
      const name = list[j];
      const lower = name.toLowerCase();
      if (!map.has(lower)) {
        map.set(lower, name);
      } else {
        const existing = map.get(lower)!;
        if (existing === existing.toUpperCase() && name !== name.toUpperCase()) {
          map.set(lower, name);
        }
      }
    }
  }
  return Array.from(map.values()).sort((a, b) => a.localeCompare(b));
}
