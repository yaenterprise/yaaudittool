import * as XLSX from "xlsx";
import { StoredReferenceFile, SheetState } from "../types";

export const REF_STORAGE_KEY_V2 = "ya_reference_stored_files_v2";
export const REF_STORAGE_KEY_V1 = "ya_reference_stored_files";
export const REF_EVENT_NAME = "ya_reference_files_updated";

/**
 * Load all registered reference files with version fallback
 */
export function loadStoredReferenceFiles(): StoredReferenceFile[] {
  try {
    const v2 = localStorage.getItem(REF_STORAGE_KEY_V2);
    if (v2) {
      const parsed = JSON.parse(v2);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
    const v1 = localStorage.getItem(REF_STORAGE_KEY_V1);
    if (v1) {
      const parsed = JSON.parse(v1);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Auto-migrate to V2
        localStorage.setItem(REF_STORAGE_KEY_V2, JSON.stringify(parsed));
        return parsed;
      }
    }
  } catch (err) {
    console.error("Error reading stored reference files:", err);
  }
  return [];
}

/**
 * Save reference files and notify all subscribers across tabs/components
 */
export function saveStoredReferenceFiles(files: StoredReferenceFile[]): void {
  try {
    const serialized = JSON.stringify(files);
    const existing = localStorage.getItem(REF_STORAGE_KEY_V2);
    if (existing === serialized) {
      return; // Data has not changed, prevent redundant writes and circular event storms
    }
    localStorage.setItem(REF_STORAGE_KEY_V2, serialized);
    window.dispatchEvent(new CustomEvent(REF_EVENT_NAME, { detail: files }));
  } catch (err) {
    console.error("Error saving reference files:", err);
  }
}

/**
 * Add a new reference file
 */
export function addStoredReferenceFile(file: StoredReferenceFile): StoredReferenceFile[] {
  const current = loadStoredReferenceFiles();
  const existingIndex = current.findIndex(f => f.id === file.id || f.referenceName.toUpperCase() === file.referenceName.toUpperCase());
  let updated: StoredReferenceFile[];
  if (existingIndex >= 0) {
    updated = [...current];
    updated[existingIndex] = file;
  } else {
    updated = [file, ...current];
  }
  saveStoredReferenceFiles(updated);
  return updated;
}

/**
 * Delete a reference file by ID
 */
export function deleteStoredReferenceFile(id: string): StoredReferenceFile[] {
  const current = loadStoredReferenceFiles();
  const updated = current.filter(f => f.id !== id);
  saveStoredReferenceFiles(updated);
  return updated;
}

/**
 * Parse a reference spreadsheet (.xlsx, .xls, .csv) and generate a lookup map
 */
export async function parseReferenceSpreadsheet(file: File, customRefName?: string): Promise<StoredReferenceFile> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array" });

  if (!workbook.SheetNames.length) {
    throw new Error("Spreadsheet contains no sheets.");
  }

  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];

  // Raw headers
  const rawJson = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
  const headers = ((rawJson[0] as any[]) || []).map(h => String(h || "").trim()).filter(Boolean);
  const totalRows = rawJson.length > 0 ? rawJson.length - 1 : 0;

  // Raw data rows
  const rawRows = XLSX.utils.sheet_to_json<any>(worksheet);

  // Auto-detect columns
  let detectedIdCol = headers[0] || "";
  let detectedValCol = headers[1] || headers[0] || "";

  for (const h of headers) {
    const lower = h.toLowerCase();
    if (lower.includes("productid") || lower.includes("prodid") || lower === "id" || lower.includes("card") || lower.includes("product_id") || lower.includes("productcode")) {
      detectedIdCol = h;
    }
    if (lower.includes("reference") || lower.includes("value") || lower.includes("cas") || lower.includes("code") || lower.includes("sys") || lower.includes("map")) {
      detectedValCol = h;
    }
  }

  // Generate lookup map
  const lookupMap: Record<string, string> = {};
  for (const row of rawRows) {
    const key = String(row[detectedIdCol] !== undefined && row[detectedIdCol] !== null ? row[detectedIdCol] : "").trim();
    const val = String(row[detectedValCol] !== undefined && row[detectedValCol] !== null ? row[detectedValCol] : "").trim();
    if (key) {
      lookupMap[key] = val;
    }
  }

  const cleanName = (customRefName || file.name.split(".")[0])
    .toUpperCase()
    .replace(/[^A-Z0-9_-]/g, "_")
    .substring(0, 30);

  const newRef: StoredReferenceFile = {
    id: `${Date.now()}-${file.name.replace(/\s+/g, "_")}`,
    referenceName: cleanName || `REF_${Date.now()}`,
    originalName: file.name,
    fileSize: file.size,
    totalRows,
    sheetCount: workbook.SheetNames.length,
    headers,
    savedAt: new Date().toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }),
    productIdCol: detectedIdCol,
    referenceValueCol: detectedValCol,
    lookupMap
  };

  return newRef;
}

/**
 * Convert an already uploaded sheet from Part 1 into a registered reference file
 */
export function convertSheetToStoredReference(
  sheet: SheetState,
  refName: string,
  idCol: string,
  valCol: string
): StoredReferenceFile {
  const lookupMap: Record<string, string> = {};
  if (sheet.rawRows) {
    for (const row of sheet.rawRows) {
      const key = String(row[idCol] !== undefined && row[idCol] !== null ? row[idCol] : "").trim();
      const val = String(row[valCol] !== undefined && row[valCol] !== null ? row[valCol] : "").trim();
      if (key) {
        lookupMap[key] = val;
      }
    }
  }

  const cleanName = refName
    .toUpperCase()
    .replace(/[^A-Z0-9_-]/g, "_")
    .substring(0, 30);

  const newRef: StoredReferenceFile = {
    id: `sheet-${sheet.id}-${Date.now()}`,
    referenceName: cleanName || sheet.sheetName.toUpperCase(),
    originalName: `${sheet.fileName} [${sheet.sheetName}]`,
    fileSize: 0,
    totalRows: sheet.rowCount || 0,
    sheetCount: 1,
    headers: sheet.columns || [],
    savedAt: new Date().toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }),
    productIdCol: idCol,
    referenceValueCol: valCol,
    lookupMap
  };

  return newRef;
}
