import { ValidationRecord, ValidationSummary } from "../types";

export interface PerformanceValidationRecord {
  key: string;
  aProducts: string[];
  bProducts: string[];
  cProducts: string[];
  
  // Numeric sort pre-computation flags
  keyIsNum: boolean;
  keyNumVal: number;

  // Pre-calculated status for each comparison mode
  status_AB: "MATCH" | "MISMATCH";
  status_BC: "MATCH" | "MISMATCH";
  status_AC: "MATCH" | "MISMATCH";
  status_ABC: "MATCH" | "MISMATCH";

  // Pre-calculated extras for each comparison mode
  extra_AB_A: string[]; // Items in A but not in B
  extra_AB_B: string[]; // Items in B but not in A
  
  extra_BC_B: string[]; // Items in B but not in C
  extra_BC_C: string[]; // Items in C but not in B

  extra_AC_A: string[]; // Items in A but not in C
  extra_AC_C: string[]; // Items in C but not in A

  extra_ABC_A: string[]; // A items missing in B or C
  extra_ABC_B: string[]; // B items missing in A or C
  extra_ABC_C: string[]; // C items missing in A or B

  // Pre-compiled search index string (lowercase)
  searchIndex: string;
}

// Global cached records list
let globalValidationRecords: PerformanceValidationRecord[] = [];

/**
 * Clears the global validation records cache
 */
export function clearGlobalValidationRecords(): void {
  globalValidationRecords = [];
}

/**
 * Sets the global validation records in memory
 */
export function setGlobalValidationRecords(records: PerformanceValidationRecord[]): void {
  globalValidationRecords = records;
}

/**
 * Returns the count of global validation records in memory
 */
export function getGlobalValidationRecordsCount(): number {
  return globalValidationRecords.length;
}

/**
 * Returns a single validation record by index from memory
 */
export function getGlobalValidationRecordAt(index: number): PerformanceValidationRecord {
  return globalValidationRecords[index];
}

/**
 * Maps a single PerformanceValidationRecord to a standard ValidationRecord format based on layout mode.
 */
export function getDisplayRecord(
  rec: PerformanceValidationRecord,
  mode: "A_B" | "B_C" | "A_C" | "A_B_C",
  cardToCasMap?: Map<string, string>
): ValidationRecord {
  const casName = cardToCasMap?.get(rec.key) || "";
  if (mode === "A_B") {
    return {
      key: rec.key,
      casName,
      aProducts: rec.aProducts,
      bProducts: rec.bProducts,
      cProducts: rec.cProducts,
      status: rec.status_AB,
      aExtra: rec.extra_AB_A,
      bExtra: rec.extra_AB_B,
      cExtra: [],
    };
  } else if (mode === "B_C") {
    return {
      key: rec.key,
      casName,
      aProducts: rec.aProducts,
      bProducts: rec.bProducts,
      cProducts: rec.cProducts,
      status: rec.status_BC,
      aExtra: [],
      bExtra: rec.extra_BC_B,
      cExtra: rec.extra_BC_C,
    };
  } else if (mode === "A_C") {
    return {
      key: rec.key,
      casName,
      aProducts: rec.aProducts,
      bProducts: rec.bProducts,
      cProducts: rec.cProducts,
      status: rec.status_AC,
      aExtra: rec.extra_AC_A,
      bExtra: [],
      cExtra: rec.extra_AC_C,
    };
  } else {
    return {
      key: rec.key,
      casName,
      aProducts: rec.aProducts,
      bProducts: rec.bProducts,
      cProducts: rec.cProducts,
      status: rec.status_ABC,
      aExtra: rec.extra_ABC_A,
      bExtra: rec.extra_ABC_B,
      cExtra: rec.extra_ABC_C,
    };
  }
}

/**
 * Lazily computes the summary statistics in an incredibly fast single-pass iteration
 */
export function getValidationSummary(
  mode: "A_B" | "B_C" | "A_C" | "A_B_C",
  casFilter?: string,
  cardToCasMap?: Map<string, string>
): ValidationSummary {
  let matchCount = 0;
  let mismatchCount = 0;
  let onlyInA = 0;
  let onlyInB = 0;
  let onlyInC = 0;
  let countedLen = 0;
  
  const len = globalValidationRecords.length;
  for (let i = 0; i < len; i++) {
    const rec = globalValidationRecords[i];
    
    // CAS Filter Check
    if (casFilter && casFilter !== "ALL" && cardToCasMap) {
      const cardCas = cardToCasMap.get(rec.key) || "";
      if (cardCas.toLowerCase() !== casFilter.toLowerCase()) {
        continue;
      }
    }

    countedLen++;
    
    let status: "MATCH" | "MISMATCH";
    if (mode === "A_B") status = rec.status_AB;
    else if (mode === "B_C") status = rec.status_BC;
    else if (mode === "A_C") status = rec.status_AC;
    else status = rec.status_ABC;

    if (status === "MATCH") {
      matchCount++;
    } else {
      mismatchCount++;
    }

    const hasA = rec.aProducts.length > 0;
    const hasB = rec.bProducts.length > 0;
    const hasC = rec.cProducts.length > 0;

    if (mode === "A_B") {
      if (hasA && !hasB) onlyInA++;
      if (hasB && !hasA) onlyInB++;
    } else if (mode === "B_C") {
      if (hasB && !hasC) onlyInB++;
      if (hasC && !hasB) onlyInC++;
    } else if (mode === "A_C") {
      if (hasA && !hasC) onlyInA++;
      if (hasC && !hasA) onlyInC++;
    } else if (mode === "A_B_C") {
      if (hasA && !hasB && !hasC) onlyInA++;
      if (hasB && !hasA && !hasC) onlyInB++;
      if (hasC && !hasA && !hasB) onlyInC++;
    }
  }

  const matchRate = countedLen > 0 ? parseFloat(((matchCount / countedLen) * 100).toFixed(1)) : 0;

  return {
    totalKeys: countedLen,
    matchCount,
    mismatchCount,
    matchRate,
    onlyInA,
    onlyInB,
    onlyInC,
  };
}

/**
 * Returns all display records mapped out for exporting to Excel in O(N).
 * This runs inside user-triggered events and keeps garbage collection clean.
 */
export function getAllDisplayRecords(mode: "A_B" | "B_C" | "A_C" | "A_B_C"): ValidationRecord[] {
  const result: ValidationRecord[] = [];
  const len = globalValidationRecords.length;
  for (let i = 0; i < len; i++) {
    result.push(getDisplayRecord(globalValidationRecords[i], mode));
  }
  return result;
}

interface QueryOptions {
  searchTerm: string;
  statusFilter: "ALL" | "MATCH" | "MISMATCH" | "ONLY_A" | "ONLY_B" | "ONLY_C";
  comparisonMode: "A_B" | "B_C" | "A_C" | "A_B_C";
  sortField: "key" | "status" | "aLength" | "bLength" | "cLength";
  sortOrder: "asc" | "desc";
  page: number;
  pageSize: number;
  casFilter?: string;
  cardToCasMap?: Map<string, string>;
  uploadedCasNames?: Set<string>;
}

interface QueryResult {
  records: ValidationRecord[];
  totalFiltered: number;
}

/**
 * Filters, sorts, paginated and builds display objects in a highly optimized manner.
 * Runs on index-cached references in milliseconds even on 500k+ rows.
 */
export function queryValidationRecords({
  searchTerm,
  statusFilter,
  comparisonMode,
  sortField,
  sortOrder,
  page,
  pageSize,
  casFilter,
  cardToCasMap,
  uploadedCasNames,
}: QueryOptions): QueryResult {
  const term = searchTerm.trim().toLowerCase();
  const hasFilter = term !== "";
  const len = globalValidationRecords.length;
  
  const filtered: PerformanceValidationRecord[] = [];

  for (let i = 0; i < len; i++) {
    const rec = globalValidationRecords[i];
    
    // NEW: Filter by uploaded CAS names if any are uploaded!
    if (cardToCasMap && uploadedCasNames && uploadedCasNames.size > 0) {
      const cardCas = cardToCasMap.get(rec.key) || "";
      if (!uploadedCasNames.has(cardCas.trim().toLowerCase())) {
        continue;
      }
    }

    // 0. CAS Filter Check
    if (casFilter && casFilter !== "ALL" && cardToCasMap) {
      const cardCas = cardToCasMap.get(rec.key) || "";
      if (cardCas.toLowerCase() !== casFilter.toLowerCase()) {
        continue;
      }
    }
    
    // 1. Status Filter Check
    if (statusFilter !== "ALL") {
      let status: "MATCH" | "MISMATCH";
      if (comparisonMode === "A_B") status = rec.status_AB;
      else if (comparisonMode === "B_C") status = rec.status_BC;
      else if (comparisonMode === "A_C") status = rec.status_AC;
      else status = rec.status_ABC;
      
      if (statusFilter === "MATCH" && status !== "MATCH") continue;
      if (statusFilter === "MISMATCH" && status !== "MISMATCH") continue;
      
      const hasA = rec.aProducts.length > 0;
      const hasB = rec.bProducts.length > 0;
      const hasC = rec.cProducts.length > 0;
      
      if (statusFilter === "ONLY_A") {
        if (comparisonMode === "A_B_C") { if (!(hasA && !hasB && !hasC)) continue; }
        else if (comparisonMode === "A_B") { if (!(hasA && !hasB)) continue; }
        else if (comparisonMode === "A_C") { if (!(hasA && !hasC)) continue; }
        else continue;
      }
      if (statusFilter === "ONLY_B") {
        if (comparisonMode === "A_B_C") { if (!(hasB && !hasA && !hasC)) continue; }
        else if (comparisonMode === "A_B") { if (!(hasB && !hasA)) continue; }
        else if (comparisonMode === "B_C") { if (!(hasB && !hasC)) continue; }
        else continue;
      }
      if (statusFilter === "ONLY_C") {
        if (comparisonMode === "A_B_C") { if (!(hasC && !hasA && !hasB)) continue; }
        else if (comparisonMode === "B_C") { if (!(hasC && !hasB)) continue; }
        else if (comparisonMode === "A_C") { if (!(hasC && !hasA)) continue; }
        else continue;
      }
    }
    
    // 2. Search Term Check
    if (hasFilter) {
      if (!rec.searchIndex.includes(term)) continue;
    }
    
    filtered.push(rec);
  }

  const totalFiltered = filtered.length;

  // 3. Sort Filtered Reference List
  filtered.sort((a, b) => {
    let valA: any = "";
    let valB: any = "";
    
    if (sortField === "key") {
      const isNumA = a.keyIsNum;
      const isNumB = b.keyIsNum;
      if (isNumA && isNumB) {
        return sortOrder === "asc" ? a.keyNumVal - b.keyNumVal : b.keyNumVal - a.keyNumVal;
      }
      valA = a.key;
      valB = b.key;
    } else if (sortField === "status") {
      if (comparisonMode === "A_B") { valA = a.status_AB; valB = b.status_AB; }
      else if (comparisonMode === "B_C") { valA = a.status_BC; valB = b.status_BC; }
      else if (comparisonMode === "A_C") { valA = a.status_AC; valB = b.status_AC; }
      else { valA = a.status_ABC; valB = b.status_ABC; }
    } else if (sortField === "aLength") {
      valA = a.aProducts.length;
      valB = b.aProducts.length;
    } else if (sortField === "bLength") {
      valA = a.bProducts.length;
      valB = b.bProducts.length;
    } else if (sortField === "cLength") {
      valA = a.cProducts.length;
      valB = b.cProducts.length;
    }

    if (valA < valB) return sortOrder === "asc" ? -1 : 1;
    if (valA > valB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });

  // 4. Paginate and map references (only PAGE_SIZE objects are allocated)
  const totalPages = Math.ceil(totalFiltered / pageSize) || 1;
  const activePage = Math.min(Math.max(1, page), totalPages);
  
  const startIdx = (activePage - 1) * pageSize;
  const paginatedRefs = filtered.slice(startIdx, startIdx + pageSize);
  
  const displayRecords = paginatedRefs.map((rec) => getDisplayRecord(rec, comparisonMode, cardToCasMap));

  return {
    records: displayRecords,
    totalFiltered,
  };
}
