import * as XLSX from "xlsx";
import { ValidationRecord } from "../types";
import { getGlobalValidationRecordsCount, getGlobalValidationRecordAt, getDisplayRecord } from "./validationCache";

/**
 * Creates and downloads the Excel sheet structured precisely to support CAS (C) vs SMS (B) vs SMS (S) comparison metrics.
 * Four sheets: CAS_DATA (C), SMS_DATA (B), SMS_DATA (S), VALIDATION (Matrix)
 */
export function generateAndDownloadExcel(
  records: ValidationRecord[],
  fileName: string = "Validation_Report.xlsx",
  comparisonMode: "A_B" | "B_C" | "A_C" | "A_B_C" = "A_C"
): void {
  // 1. Prepare CAS_DATA sheet content (VC_NUMBER, CAS_NAME, CAS_PRODUCTS)
  const aSheet = records.map((rec) => ({
    VC_NUMBER: rec.key,
    CAS_NAME: rec.casName || "",
    CAS_PRODUCTS: (rec.aProducts || []).join(","),
  }));

  // 2. Prepare SMS_DATA sheet content (VC_NUMBER, CAS_NAME, SMS_PRODUCTS)
  const bSheet = records.map((rec) => ({
    VC_NUMBER: rec.key,
    CAS_NAME: rec.casName || "",
    SMS_PRODUCTS: (rec.bProducts || []).join(","),
  }));

  // 3. Prepare SMS_DATA (S) sheet content (VC_NUMBER, CAS_NAME, SMS_PRODUCTS_S)
  const cSheet = records.map((rec) => ({
    VC_NUMBER: rec.key,
    CAS_NAME: rec.casName || "",
    SMS_PRODUCTS_S: (rec.cProducts || []).join(","),
  }));

  // 4. Prepare VALIDATION sheet content
  const validationSheet = records.map((rec) => ({
    VC_NUMBER: rec.key,
    CAS_NAME: rec.casName || "",
    CAS_PRODUCTS_C: (rec.aProducts || []).join(","),
    SMS_PRODUCTS_B: (rec.bProducts || []).join(","),
    SMS_PRODUCTS_S: (rec.cProducts || []).join(","),
    STATUS: rec.status,
    COMPARISON_MODE: comparisonMode,
    CAS_EXTRA_C: (rec.aExtra || []).join(","),
    SMS_EXTRA_B: (rec.bExtra || []).join(","),
    SMS_EXTRA_S: (rec.cExtra || []).join(","),
  }));

  // Convert array of objects to Excel Sheet
  const wsA = XLSX.utils.json_to_sheet(aSheet, { raw: true } as any);
  const wsB = XLSX.utils.json_to_sheet(bSheet, { raw: true } as any);
  const wsC = XLSX.utils.json_to_sheet(cSheet, { raw: true } as any);
  const wsVal = XLSX.utils.json_to_sheet(validationSheet, { raw: true } as any);

  // Set visual column widths
  const autoWidthsA = [{ wch: 20 }, { wch: 18 }, { wch: 30 }];
  const autoWidthsB = [{ wch: 20 }, { wch: 18 }, { wch: 30 }];
  const autoWidthsC = [{ wch: 20 }, { wch: 18 }, { wch: 30 }];
  const autoWidthsVal = [
    { wch: 18 }, // VC_NUMBER
    { wch: 18 }, // CAS_NAME
    { wch: 22 }, // CAS
    { wch: 22 }, // SMS
    { wch: 22 }, // APP
    { wch: 12 }, // STATUS
    { wch: 18 }, // COMPARISON_MODE
    { wch: 22 }, // CAS_EXTRA
    { wch: 22 }, // SMS_EXTRA
    { wch: 22 }, // APP_EXTRA
  ];

  wsA["!cols"] = autoWidthsA;
  wsB["!cols"] = autoWidthsB;
  wsC["!cols"] = autoWidthsC;
  wsVal["!cols"] = autoWidthsVal;

  // Create Workbook structure
  const wb = XLSX.utils.book_new();
  
  // Append sheets
  XLSX.utils.book_append_sheet(wb, wsA, "CAS_DATA");
  XLSX.utils.book_append_sheet(wb, wsB, "SMS_DATA");
  XLSX.utils.book_append_sheet(wb, wsC, "SMS_DATA_S");
  XLSX.utils.book_append_sheet(wb, wsVal, "VALIDATION");

  // Output file trigger in client browser
  XLSX.writeFile(wb, fileName);
}

/**
 * Creates and downloads specialized standalone reports for subsets like MATCH, MISMATCH, ONLY_A, ONLY_B, ONLY_C, or individual systems.
 */
export function generateSeparateExcel(
  records: ValidationRecord[],
  exportType: "ALL" | "MATCH" | "MISMATCH" | "ONLY_A" | "ONLY_B" | "ONLY_C" | "A_DATA" | "B_DATA" | "C_DATA",
  fileName: string,
  comparisonMode: "A_B" | "B_C" | "A_C" | "A_B_C" = "A_C"
): void {
  const wb = XLSX.utils.book_new();

  if (exportType === "ALL") {
    generateAndDownloadExcel(records, fileName, comparisonMode);
    return;
  }

  if (exportType === "MATCH") {
    const matchRecords = records.filter((r) => r.status === "MATCH");
    const sheetData = matchRecords.map((rec) => {
      const row: Record<string, string> = { VC_NUMBER: rec.key };
      if (rec.casName) row["CAS_NAME"] = rec.casName;
      if (comparisonMode.includes("A")) row["CAS_PRODUCTS (C)"] = (rec.aProducts || []).join(",");
      if (comparisonMode.includes("B")) row["SMS_PRODUCTS (B)"] = (rec.bProducts || []).join(",");
      if (comparisonMode.includes("C")) row["SMS_PRODUCTS (S)"] = (rec.cProducts || []).join(",");
      row["STATUS"] = "MATCH";
      return row;
    });

    const ws = XLSX.utils.json_to_sheet(sheetData, { raw: true } as any);
    ws["!cols"] = [{ wch: 20 }, { wch: 18 }, { wch: 25 }, { wch: 25 }, { wch: 25 }, { wch: 12 }];
    XLSX.utils.book_append_sheet(wb, ws, "MATCHES_ONLY");

  } else if (exportType === "MISMATCH") {
    const mismatchRecords = records.filter((r) => r.status === "MISMATCH");
    const sheetData = mismatchRecords.map((rec) => {
      const row: Record<string, string> = { VC_NUMBER: rec.key };
      if (rec.casName) row["CAS_NAME"] = rec.casName;
      if (comparisonMode.includes("A")) row["CAS_PRODUCTS (C)"] = (rec.aProducts || []).join(",");
      if (comparisonMode.includes("B")) row["SMS_PRODUCTS (B)"] = (rec.bProducts || []).join(",");
      if (comparisonMode.includes("C")) row["SMS_PRODUCTS (S)"] = (rec.cProducts || []).join(",");
      row["STATUS"] = "MISMATCH";
      if (comparisonMode.includes("A")) row["CAS_EXTRA_C"] = (rec.aExtra || []).join(",");
      if (comparisonMode.includes("B")) row["SMS_EXTRA_B"] = (rec.bExtra || []).join(",");
      if (comparisonMode.includes("C")) row["SMS_EXTRA_S"] = (rec.cExtra || []).join(",");
      return row;
    });

    const ws = XLSX.utils.json_to_sheet(sheetData, { raw: true } as any);
    ws["!cols"] = [
      { wch: 18 }, { wch: 18 }, { wch: 22 }, { wch: 22 }, { wch: 22 },
      { wch: 12 }, { wch: 22 }, { wch: 22 }, { wch: 22 }
    ];
    XLSX.utils.book_append_sheet(wb, ws, "MISMATCHES_ONLY");

  } else if (exportType === "ONLY_A") {
    const onlyARecords = records.filter((r) => {
      const hasA = (r.aProducts && r.aProducts.length > 0);
      const hasB = (r.bProducts && r.bProducts.length > 0);
      const hasC = (r.cProducts && r.cProducts.length > 0);
      if (comparisonMode === "A_B_C") return hasA && !hasB && !hasC;
      if (comparisonMode === "A_B") return hasA && !hasB;
      if (comparisonMode === "A_C") return hasA && !hasC;
      return hasA;
    });
    const sheetData = onlyARecords.map((rec) => {
      const row: Record<string, string> = { VC_NUMBER: rec.key };
      if (rec.casName) row["CAS_NAME"] = rec.casName;
      row["CAS_PRODUCTS (C)"] = (rec.aProducts || []).join(",");
      row["STATUS"] = "ONLY_IN_CAS";
      return row;
    });
    const ws = XLSX.utils.json_to_sheet(sheetData, { raw: true } as any);
    ws["!cols"] = [{ wch: 20 }, { wch: 18 }, { wch: 35 }, { wch: 15 }];
    XLSX.utils.book_append_sheet(wb, ws, "CAS_ONLY");

  } else if (exportType === "ONLY_B") {
    const onlyBRecords = records.filter((r) => {
      const hasA = (r.aProducts && r.aProducts.length > 0);
      const hasB = (r.bProducts && r.bProducts.length > 0);
      const hasC = (r.cProducts && r.cProducts.length > 0);
      if (comparisonMode === "A_B_C") return hasB && !hasA && !hasC;
      if (comparisonMode === "A_B") return hasB && !hasA;
      if (comparisonMode === "B_C") return hasB && !hasC;
      return hasB;
    });
    const sheetData = onlyBRecords.map((rec) => {
      const row: Record<string, string> = { VC_NUMBER: rec.key };
      if (rec.casName) row["CAS_NAME"] = rec.casName;
      row["SMS_PRODUCTS (B)"] = (rec.bProducts || []).join(",");
      row["STATUS"] = "ONLY_IN_SMS_B";
      return row;
    });
    const ws = XLSX.utils.json_to_sheet(sheetData, { raw: true } as any);
    ws["!cols"] = [{ wch: 20 }, { wch: 18 }, { wch: 35 }, { wch: 15 }];
    XLSX.utils.book_append_sheet(wb, ws, "SMS_B_ONLY");

  } else if (exportType === "ONLY_C") {
    const onlyCRecords = records.filter((r) => {
      const hasA = (r.aProducts && r.aProducts.length > 0);
      const hasB = (r.bProducts && r.bProducts.length > 0);
      const hasC = (r.cProducts && r.cProducts.length > 0);
      if (comparisonMode === "A_B_C") return hasC && !hasA && !hasB;
      if (comparisonMode === "B_C") return hasC && !hasB;
      if (comparisonMode === "A_C") return hasC && !hasA;
      return hasC;
    });
    const sheetData = onlyCRecords.map((rec) => {
      const row: Record<string, string> = { VC_NUMBER: rec.key };
      if (rec.casName) row["CAS_NAME"] = rec.casName;
      row["SMS_PRODUCTS (S)"] = (rec.cProducts || []).join(",");
      row["STATUS"] = "ONLY_IN_SMS_S";
      return row;
    });
    const ws = XLSX.utils.json_to_sheet(sheetData, { raw: true } as any);
    ws["!cols"] = [{ wch: 20 }, { wch: 18 }, { wch: 35 }, { wch: 15 }];
    XLSX.utils.book_append_sheet(wb, ws, "SMS_S_ONLY");

  } else if (exportType === "A_DATA") {
    const aRecords = records.filter((r) => r.aProducts && r.aProducts.length > 0);
    const sheetData = aRecords.map((rec) => ({
      VC_NUMBER: rec.key,
      CAS_NAME: rec.casName || "",
      CAS_PRODUCTS: (rec.aProducts || []).join(","),
    }));

    const ws = XLSX.utils.json_to_sheet(sheetData, { raw: true } as any);
    ws["!cols"] = [{ wch: 20 }, { wch: 18 }, { wch: 35 }];
    XLSX.utils.book_append_sheet(wb, ws, "CAS_DATA_C");

  } else if (exportType === "B_DATA") {
    const bRecords = records.filter((r) => r.bProducts && r.bProducts.length > 0);
    const sheetData = bRecords.map((rec) => ({
      VC_NUMBER: rec.key,
      CAS_NAME: rec.casName || "",
      SMS_PRODUCTS: (rec.bProducts || []).join(","),
    }));

    const ws = XLSX.utils.json_to_sheet(sheetData, { raw: true } as any);
    ws["!cols"] = [{ wch: 20 }, { wch: 18 }, { wch: 35 }];
    XLSX.utils.book_append_sheet(wb, ws, "SMS_DATA_B");

  } else if (exportType === "C_DATA") {
    const cRecords = records.filter((r) => r.cProducts && r.cProducts.length > 0);
    const sheetData = cRecords.map((rec) => ({
      VC_NUMBER: rec.key,
      CAS_NAME: rec.casName || "",
      SMS_PRODUCTS_S: (rec.cProducts || []).join(","),
    }));

    const ws = XLSX.utils.json_to_sheet(sheetData, { raw: true } as any);
    ws["!cols"] = [{ wch: 20 }, { wch: 18 }, { wch: 35 }];
    XLSX.utils.book_append_sheet(wb, ws, "SMS_DATA_S");
  }

  XLSX.writeFile(wb, fileName);
}

/**
 * Asynchronously generates high-performance CSV file parts.
 * Automatically splits at 1,000,000 rows per part to prevent Excel truncation issues when opening CSV files.
 * Filters strictly by selected CAS filter, uploaded CAS names, and export subset.
 */
export async function generateSeparateCSVAsync(
  exportType: "ALL" | "MATCH" | "MISMATCH" | "ONLY_A" | "ONLY_B" | "ONLY_C" | "A_DATA" | "B_DATA" | "C_DATA",
  comparisonMode: "A_B" | "B_C" | "A_C" | "A_B_C",
  onProgress: (percent: number) => void,
  casFilter?: string,
  cardToCasMap?: Map<string, string>,
  uploadedCasNames?: Set<string>
): Promise<{ blob: Blob; part: number }[]> {
  const total = getGlobalValidationRecordsCount();
  const headers: string[] = [];

  if (exportType === "ALL" || exportType === "MATCH" || exportType === "MISMATCH") {
    headers.push("VC_NUMBER");
    if (cardToCasMap) headers.push("CAS_NAME");
    if (comparisonMode.includes("A")) headers.push("CAS_PRODUCTS (C)");
    if (comparisonMode.includes("B")) headers.push("SMS_PRODUCTS (B)");
    if (comparisonMode.includes("C")) headers.push("SMS_PRODUCTS (S)");
    headers.push("STATUS");
    if (comparisonMode.includes("A")) headers.push("CAS_EXTRA_C");
    if (comparisonMode.includes("B")) headers.push("SMS_EXTRA_B");
    if (comparisonMode.includes("C")) headers.push("SMS_EXTRA_S");
  } else if (exportType === "ONLY_A") {
    headers.push("VC_NUMBER");
    if (cardToCasMap) headers.push("CAS_NAME");
    headers.push("CAS_PRODUCTS (C)", "STATUS");
  } else if (exportType === "ONLY_B") {
    headers.push("VC_NUMBER");
    if (cardToCasMap) headers.push("CAS_NAME");
    headers.push("SMS_PRODUCTS (B)", "STATUS");
  } else if (exportType === "ONLY_C") {
    headers.push("VC_NUMBER");
    if (cardToCasMap) headers.push("CAS_NAME");
    headers.push("SMS_PRODUCTS (S)", "STATUS");
  } else if (exportType === "A_DATA") {
    headers.push("VC_NUMBER");
    if (cardToCasMap) headers.push("CAS_NAME");
    headers.push("CAS_PRODUCTS");
  } else if (exportType === "B_DATA") {
    headers.push("VC_NUMBER");
    if (cardToCasMap) headers.push("CAS_NAME");
    headers.push("SMS_PRODUCTS");
  } else if (exportType === "C_DATA") {
    headers.push("VC_NUMBER");
    if (cardToCasMap) headers.push("CAS_NAME");
    headers.push("SMS_PRODUCTS_S");
  }

  const escapeCSV = (val: string | undefined | null) => {
    if (val === undefined || val === null) return "";
    let str = String(val).trim();
    if (/^\d+$/.test(str) && str.length >= 11) {
      str = "\t" + str;
    }
    if (str.includes(",") || str.includes('"') || str.includes("\n") || str.includes("\r")) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const CSV_ROW_LIMIT = 1000000; // Chunk at 1,000,000 rows for safe Excel compatibility
  const CHUNK_SIZE = 40000; // Process 40,000 records at a time
  let currentOffset = 0;

  const parts: { blob: Blob; part: number }[] = [];
  let currentPartLines: string[] = [headers.join(",")];
  let currentPartCount = 1;

  while (currentOffset < total) {
    const limit = Math.min(currentOffset + CHUNK_SIZE, total);

    for (let i = currentOffset; i < limit; i++) {
      const perfRec = getGlobalValidationRecordAt(i);
      if (!perfRec) continue;

      // 1. Uploaded CAS filter check
      if (cardToCasMap && uploadedCasNames && uploadedCasNames.size > 0) {
        const cardCas = cardToCasMap.get(perfRec.key) || "";
        if (!uploadedCasNames.has(cardCas.trim().toLowerCase())) {
          continue;
        }
      }

      // 2. Selected CAS Filter check
      const recordCas = cardToCasMap?.get(perfRec.key) || "";
      if (casFilter && casFilter !== "ALL" && cardToCasMap) {
        if (recordCas.toLowerCase() !== casFilter.toLowerCase()) {
          continue;
        }
      }
      
      const rec = getDisplayRecord(perfRec, comparisonMode, cardToCasMap);

      const hasA = (rec.aProducts && rec.aProducts.length > 0) || false;
      const hasB = (rec.bProducts && rec.bProducts.length > 0) || false;
      const hasC = (rec.cProducts && rec.cProducts.length > 0) || false;

      // Filtering logic depending on the export type
      if (exportType === "MATCH" && rec.status !== "MATCH") continue;
      if (exportType === "MISMATCH" && rec.status !== "MISMATCH") continue;
      if (exportType === "ONLY_A") {
        if (comparisonMode === "A_B_C") { if (!(hasA && !hasB && !hasC)) continue; }
        else if (comparisonMode === "A_B") { if (!(hasA && !hasB)) continue; }
        else if (comparisonMode === "A_C") { if (!(hasA && !hasC)) continue; }
        else continue;
      }
      if (exportType === "ONLY_B") {
        if (comparisonMode === "A_B_C") { if (!(hasB && !hasA && !hasC)) continue; }
        else if (comparisonMode === "A_B") { if (!(hasB && !hasA)) continue; }
        else if (comparisonMode === "B_C") { if (!(hasB && !hasC)) continue; }
        else continue;
      }
      if (exportType === "ONLY_C") {
        if (comparisonMode === "A_B_C") { if (!(hasC && !hasA && !hasB)) continue; }
        else if (comparisonMode === "B_C") { if (!(hasC && !hasB)) continue; }
        else if (comparisonMode === "A_C") { if (!(hasC && !hasA)) continue; }
        else continue;
      }
      if (exportType === "A_DATA" && !hasA) continue;
      if (exportType === "B_DATA" && !hasB) continue;
      if (exportType === "C_DATA" && !hasC) continue;

      const row: string[] = [];
      if (exportType === "ALL" || exportType === "MATCH" || exportType === "MISMATCH") {
        row.push(escapeCSV(rec.key));
        if (cardToCasMap) row.push(escapeCSV(recordCas));
        if (comparisonMode.includes("A")) row.push(escapeCSV((rec.aProducts || []).join(", ")));
        if (comparisonMode.includes("B")) row.push(escapeCSV((rec.bProducts || []).join(", ")));
        if (comparisonMode.includes("C")) row.push(escapeCSV((rec.cProducts || []).join(", ")));
        row.push(escapeCSV(rec.status));
        if (comparisonMode.includes("A")) row.push(escapeCSV((rec.aExtra || []).join(", ")));
        if (comparisonMode.includes("B")) row.push(escapeCSV((rec.bExtra || []).join(", ")));
        if (comparisonMode.includes("C")) row.push(escapeCSV((rec.cExtra || []).join(", ")));
      } else if (exportType === "ONLY_A") {
        row.push(escapeCSV(rec.key));
        if (cardToCasMap) row.push(escapeCSV(recordCas));
        row.push(escapeCSV((rec.aProducts || []).join(", ")));
        row.push(escapeCSV("ONLY_IN_CAS"));
      } else if (exportType === "ONLY_B") {
        row.push(escapeCSV(rec.key));
        if (cardToCasMap) row.push(escapeCSV(recordCas));
        row.push(escapeCSV((rec.bProducts || []).join(", ")));
        row.push(escapeCSV("ONLY_IN_SMS_B"));
      } else if (exportType === "ONLY_C") {
        row.push(escapeCSV(rec.key));
        if (cardToCasMap) row.push(escapeCSV(recordCas));
        row.push(escapeCSV((rec.cProducts || []).join(", ")));
        row.push(escapeCSV("ONLY_IN_SMS_S"));
      } else if (exportType === "A_DATA") {
        row.push(escapeCSV(rec.key));
        if (cardToCasMap) row.push(escapeCSV(recordCas));
        row.push(escapeCSV((rec.aProducts || []).join(", ")));
      } else if (exportType === "B_DATA") {
        row.push(escapeCSV(rec.key));
        if (cardToCasMap) row.push(escapeCSV(recordCas));
        row.push(escapeCSV((rec.bProducts || []).join(", ")));
      } else if (exportType === "C_DATA") {
        row.push(escapeCSV(rec.key));
        if (cardToCasMap) row.push(escapeCSV(recordCas));
        row.push(escapeCSV((rec.cProducts || []).join(", ")));
      }

      currentPartLines.push(row.join(","));

      if (currentPartLines.length >= CSV_ROW_LIMIT + 1) {
        parts.push({
          blob: new Blob([currentPartLines.join("\n")], { type: "text/csv;charset=utf-8;" }),
          part: currentPartCount
        });
        currentPartLines = [headers.join(",")];
        currentPartCount++;
      }
    }

    currentOffset = limit;
    const progress = Math.floor((currentOffset / total) * 100);
    onProgress(progress);

    // Yield back to browser to allow UI updates and prevent freezing
    await new Promise((resolve) => setTimeout(resolve, 15));
  }

  // Final remaining part
  if (currentPartLines.length > 1 || currentPartCount === 1) {
    parts.push({
      blob: new Blob([currentPartLines.join("\n")], { type: "text/csv;charset=utf-8;" }),
      part: currentPartCount
    });
  }

  return parts;
}

/**
 * Generates separate Excel sheets with safety cap to prevent Chrome/browser out-of-memory crashes.
 * Capped at 100,000 rows. Filters strictly by selected CAS.
 */
export function generateSeparateExcelCapped(
  exportType: "ALL" | "MATCH" | "MISMATCH" | "ONLY_A" | "ONLY_B" | "ONLY_C" | "A_DATA" | "B_DATA" | "C_DATA",
  fileName: string,
  comparisonMode: "A_B" | "B_C" | "A_C" | "A_B_C" = "A_C",
  maxRows: number = 100000,
  casFilter?: string,
  cardToCasMap?: Map<string, string>,
  uploadedCasNames?: Set<string>
): void {
  const total = getGlobalValidationRecordsCount();
  const cappedRecords: ValidationRecord[] = [];

  for (let i = 0; i < total; i++) {
    const perfRec = getGlobalValidationRecordAt(i);
    if (!perfRec) continue;

    // 1. Uploaded CAS filter check
    if (cardToCasMap && uploadedCasNames && uploadedCasNames.size > 0) {
      const cardCas = cardToCasMap.get(perfRec.key) || "";
      if (!uploadedCasNames.has(cardCas.trim().toLowerCase())) {
        continue;
      }
    }

    // 2. Selected CAS filter check
    const recordCas = cardToCasMap?.get(perfRec.key) || "";
    if (casFilter && casFilter !== "ALL" && cardToCasMap) {
      if (recordCas.toLowerCase() !== casFilter.toLowerCase()) {
        continue;
      }
    }
    
    const rec = getDisplayRecord(perfRec, comparisonMode, cardToCasMap);

    const hasA = (rec.aProducts && rec.aProducts.length > 0) || false;
    const hasB = (rec.bProducts && rec.bProducts.length > 0) || false;
    const hasC = (rec.cProducts && rec.cProducts.length > 0) || false;

    // Check filters
    if (exportType === "MATCH" && rec.status !== "MATCH") continue;
    if (exportType === "MISMATCH" && rec.status !== "MISMATCH") continue;
    if (exportType === "ONLY_A") {
      if (comparisonMode === "A_B_C") { if (!(hasA && !hasB && !hasC)) continue; }
      else if (comparisonMode === "A_B") { if (!(hasA && !hasB)) continue; }
      else if (comparisonMode === "A_C") { if (!(hasA && !hasC)) continue; }
      else continue;
    }
    if (exportType === "ONLY_B") {
      if (comparisonMode === "A_B_C") { if (!(hasB && !hasA && !hasC)) continue; }
      else if (comparisonMode === "A_B") { if (!(hasB && !hasA)) continue; }
      else if (comparisonMode === "B_C") { if (!(hasB && !hasC)) continue; }
      else continue;
    }
    if (exportType === "ONLY_C") {
      if (comparisonMode === "A_B_C") { if (!(hasC && !hasA && !hasB)) continue; }
      else if (comparisonMode === "B_C") { if (!(hasC && !hasB)) continue; }
      else if (comparisonMode === "A_C") { if (!(hasC && !hasA)) continue; }
      else continue;
    }
    if (exportType === "A_DATA" && !hasA) continue;
    if (exportType === "B_DATA" && !hasB) continue;
    if (exportType === "C_DATA" && !hasC) continue;

    cappedRecords.push(rec);

    if (cappedRecords.length >= maxRows) {
      break;
    }
  }

  // Use existing separate spreadsheet logic with the safely capped list
  generateSeparateExcel(cappedRecords, exportType, fileName, comparisonMode);
}

/**
 * Memory-optimized, non-blocking asynchronous Excel workbook generator.
 * Automatically splits sheets into parts of 1,000,000 rows each to prevent Excel grid truncation warnings.
 */
export async function generateSeparateExcelSplittedAsync(
  exportType: "ALL" | "MATCH" | "MISMATCH" | "ONLY_A" | "ONLY_B" | "ONLY_C" | "A_DATA" | "B_DATA" | "C_DATA",
  comparisonMode: "A_B" | "B_C" | "A_C" | "A_B_C",
  onProgress: (percent: number) => void,
  casFilter?: string,
  cardToCasMap?: Map<string, string>,
  uploadedCasNames?: Set<string>
): Promise<XLSX.WorkBook> {
  const total = getGlobalValidationRecordsCount();
  const wb = XLSX.utils.book_new();

  const SHEET_ROW_LIMIT = 1000000; // split at 1M rows for Excel grid compliance (max 1.048M)
  const CHUNK_SIZE = 40000;
  let currentOffset = 0;

  if (exportType === "ALL") {
    let rowsCas: any[] = [];
    let rowsSms: any[] = [];
    let rowsSmsS: any[] = [];
    let rowsVal: any[] = [];

    let partCas = 1;
    let partSms = 1;
    let partSmsS = 1;
    let partVal = 1;

    const colsCas = [{ wch: 20 }, { wch: 18 }, { wch: 30 }];
    const colsSms = [{ wch: 20 }, { wch: 18 }, { wch: 30 }];
    const colsSmsS = [{ wch: 20 }, { wch: 18 }, { wch: 30 }];
    const colsVal = [
      { wch: 18 }, { wch: 18 }, { wch: 22 }, { wch: 22 }, { wch: 22 },
      { wch: 12 }, { wch: 18 }, { wch: 22 }, { wch: 22 }, { wch: 22 }
    ];

    const appendSheetChunk = (rows: any[], baseName: string, part: number, cols: any[]) => {
      const ws = XLSX.utils.json_to_sheet(rows, { raw: true } as any);
      ws["!cols"] = cols;
      const sheetName = `${baseName}_P${part}`.slice(0, 31);
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    };

    while (currentOffset < total) {
      const limit = Math.min(currentOffset + CHUNK_SIZE, total);

      for (let i = currentOffset; i < limit; i++) {
        const perfRec = getGlobalValidationRecordAt(i);
        if (!perfRec) continue;

        if (cardToCasMap && uploadedCasNames && uploadedCasNames.size > 0) {
          const cardCas = cardToCasMap.get(perfRec.key) || "";
          if (!uploadedCasNames.has(cardCas.trim().toLowerCase())) {
            continue;
          }
        }

        const recordCas = cardToCasMap?.get(perfRec.key) || "";
        if (casFilter && casFilter !== "ALL" && cardToCasMap) {
          if (recordCas.toLowerCase() !== casFilter.toLowerCase()) {
            continue;
          }
        }

        const rec = getDisplayRecord(perfRec, comparisonMode, cardToCasMap);

        rowsCas.push({
          VC_NUMBER: rec.key,
          CAS_NAME: recordCas || rec.casName || "",
          CAS_PRODUCTS: (rec.aProducts || []).join(","),
        });
        if (rowsCas.length >= SHEET_ROW_LIMIT) {
          appendSheetChunk(rowsCas, "CAS_DATA", partCas, colsCas);
          rowsCas = [];
          partCas++;
        }

        rowsSms.push({
          VC_NUMBER: rec.key,
          CAS_NAME: recordCas || rec.casName || "",
          SMS_PRODUCTS: (rec.bProducts || []).join(","),
        });
        if (rowsSms.length >= SHEET_ROW_LIMIT) {
          appendSheetChunk(rowsSms, "SMS_DATA", partSms, colsSms);
          rowsSms = [];
          partSms++;
        }

        rowsSmsS.push({
          VC_NUMBER: rec.key,
          CAS_NAME: recordCas || rec.casName || "",
          SMS_PRODUCTS_S: (rec.cProducts || []).join(","),
        });
        if (rowsSmsS.length >= SHEET_ROW_LIMIT) {
          appendSheetChunk(rowsSmsS, "SMS_DATA_S", partSmsS, colsSmsS);
          rowsSmsS = [];
          partSmsS++;
        }

        rowsVal.push({
          VC_NUMBER: rec.key,
          CAS_NAME: recordCas || rec.casName || "",
          CAS_PRODUCTS_C: (rec.aProducts || []).join(","),
          SMS_PRODUCTS_B: (rec.bProducts || []).join(","),
          SMS_PRODUCTS_S: (rec.cProducts || []).join(","),
          STATUS: rec.status,
          COMPARISON_MODE: comparisonMode,
          CAS_EXTRA_C: (rec.aExtra || []).join(","),
          SMS_EXTRA_B: (rec.bExtra || []).join(","),
          SMS_EXTRA_S: (rec.cExtra || []).join(","),
        });
        if (rowsVal.length >= SHEET_ROW_LIMIT) {
          appendSheetChunk(rowsVal, "VALIDATION", partVal, colsVal);
          rowsVal = [];
          partVal++;
        }
      }

      currentOffset = limit;
      const progress = Math.floor((currentOffset / total) * 100);
      onProgress(progress);

      await new Promise((resolve) => setTimeout(resolve, 15));
    }

    if (rowsCas.length > 0 || partCas === 1) {
      const sheetName = partCas > 1 ? `CAS_DATA_P${partCas}`.slice(0, 31) : "CAS_DATA";
      const ws = XLSX.utils.json_to_sheet(rowsCas, { raw: true } as any);
      ws["!cols"] = colsCas;
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    }
    if (rowsSms.length > 0 || partSms === 1) {
      const sheetName = partSms > 1 ? `SMS_DATA_P${partSms}`.slice(0, 31) : "SMS_DATA";
      const ws = XLSX.utils.json_to_sheet(rowsSms, { raw: true } as any);
      ws["!cols"] = colsSms;
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    }
    if (rowsSmsS.length > 0 || partSmsS === 1) {
      const sheetName = partSmsS > 1 ? `SMS_DATA_S_P${partSmsS}`.slice(0, 31) : "SMS_DATA_S";
      const ws = XLSX.utils.json_to_sheet(rowsSmsS, { raw: true } as any);
      ws["!cols"] = colsSmsS;
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    }
    if (rowsVal.length > 0 || partVal === 1) {
      const sheetName = partVal > 1 ? `VALIDATION_P${partVal}`.slice(0, 31) : "VALIDATION";
      const ws = XLSX.utils.json_to_sheet(rowsVal, { raw: true } as any);
      ws["!cols"] = colsVal;
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    }

  } else {
    let currentSheetRows: any[] = [];
    let partNum = 1;
    let baseSheetName = "Report";
    let cols: any[] = [];

    if (exportType === "MATCH") {
      baseSheetName = "MATCHES_ONLY";
      cols = [{ wch: 20 }, { wch: 18 }, { wch: 25 }, { wch: 25 }, { wch: 25 }, { wch: 12 }];
    } else if (exportType === "MISMATCH") {
      baseSheetName = "MISMATCHES_ONLY";
      cols = [{ wch: 18 }, { wch: 18 }, { wch: 22 }, { wch: 22 }, { wch: 22 }, { wch: 12 }, { wch: 22 }, { wch: 22 }, { wch: 22 }];
    } else if (exportType === "ONLY_A") {
      baseSheetName = "CAS_ONLY";
      cols = [{ wch: 20 }, { wch: 18 }, { wch: 35 }, { wch: 15 }];
    } else if (exportType === "ONLY_B") {
      baseSheetName = "SMS_B_ONLY";
      cols = [{ wch: 20 }, { wch: 18 }, { wch: 35 }, { wch: 15 }];
    } else if (exportType === "ONLY_C") {
      baseSheetName = "SMS_S_ONLY";
      cols = [{ wch: 20 }, { wch: 18 }, { wch: 35 }, { wch: 15 }];
    } else if (exportType === "A_DATA") {
      baseSheetName = "CAS_DATA_C";
      cols = [{ wch: 20 }, { wch: 18 }, { wch: 35 }];
    } else if (exportType === "B_DATA") {
      baseSheetName = "SMS_DATA_B";
      cols = [{ wch: 20 }, { wch: 18 }, { wch: 35 }];
    } else if (exportType === "C_DATA") {
      baseSheetName = "SMS_DATA_S";
      cols = [{ wch: 20 }, { wch: 18 }, { wch: 35 }];
    }

    const appendSingleChunk = (rows: any[], base: string, part: number, c: any[]) => {
      const ws = XLSX.utils.json_to_sheet(rows, { raw: true } as any);
      ws["!cols"] = c;
      const name = `${base}_P${part}`.slice(0, 31);
      XLSX.utils.book_append_sheet(wb, ws, name);
    };

    while (currentOffset < total) {
      const limit = Math.min(currentOffset + CHUNK_SIZE, total);

      for (let i = currentOffset; i < limit; i++) {
        const perfRec = getGlobalValidationRecordAt(i);
        if (!perfRec) continue;

        if (cardToCasMap && uploadedCasNames && uploadedCasNames.size > 0) {
          const cardCas = cardToCasMap.get(perfRec.key) || "";
          if (!uploadedCasNames.has(cardCas.trim().toLowerCase())) {
            continue;
          }
        }

        const recordCas = cardToCasMap?.get(perfRec.key) || "";
        if (casFilter && casFilter !== "ALL" && cardToCasMap) {
          if (recordCas.toLowerCase() !== casFilter.toLowerCase()) {
            continue;
          }
        }

        const rec = getDisplayRecord(perfRec, comparisonMode, cardToCasMap);

        const hasA = (rec.aProducts && rec.aProducts.length > 0) || false;
        const hasB = (rec.bProducts && rec.bProducts.length > 0) || false;
        const hasC = (rec.cProducts && rec.cProducts.length > 0) || false;

        if (exportType === "MATCH" && rec.status !== "MATCH") continue;
        if (exportType === "MISMATCH" && rec.status !== "MISMATCH") continue;
        if (exportType === "ONLY_A") {
          if (comparisonMode === "A_B_C") { if (!(hasA && !hasB && !hasC)) continue; }
          else if (comparisonMode === "A_B") { if (!(hasA && !hasB)) continue; }
          else if (comparisonMode === "A_C") { if (!(hasA && !hasC)) continue; }
          else continue;
        }
        if (exportType === "ONLY_B") {
          if (comparisonMode === "A_B_C") { if (!(hasB && !hasA && !hasC)) continue; }
          else if (comparisonMode === "A_B") { if (!(hasB && !hasA)) continue; }
          else if (comparisonMode === "B_C") { if (!(hasB && !hasC)) continue; }
          else continue;
        }
        if (exportType === "ONLY_C") {
          if (comparisonMode === "A_B_C") { if (!(hasC && !hasA && !hasB)) continue; }
          else if (comparisonMode === "B_C") { if (!(hasC && !hasB)) continue; }
          else if (comparisonMode === "A_C") { if (!(hasC && !hasA)) continue; }
          else continue;
        }
        if (exportType === "A_DATA" && !hasA) continue;
        if (exportType === "B_DATA" && !hasB) continue;
        if (exportType === "C_DATA" && !hasC) continue;

        const rowObj: any = {};
        if (exportType === "MATCH" || exportType === "MISMATCH") {
          rowObj["VC_NUMBER"] = rec.key;
          if (cardToCasMap) rowObj["CAS_NAME"] = recordCas || rec.casName || "";
          if (comparisonMode.includes("A")) rowObj["CAS_PRODUCTS (C)"] = (rec.aProducts || []).join(",");
          if (comparisonMode.includes("B")) rowObj["SMS_PRODUCTS (B)"] = (rec.bProducts || []).join(",");
          if (comparisonMode.includes("C")) rowObj["SMS_PRODUCTS (S)"] = (rec.cProducts || []).join(",");
          rowObj["STATUS"] = rec.status;
          if (exportType === "MISMATCH") {
            if (comparisonMode.includes("A")) rowObj["CAS_EXTRA_C"] = (rec.aExtra || []).join(",");
            if (comparisonMode.includes("B")) rowObj["SMS_EXTRA_B"] = (rec.bExtra || []).join(",");
            if (comparisonMode.includes("C")) rowObj["SMS_EXTRA_S"] = (rec.cExtra || []).join(",");
          }
        } else if (exportType === "ONLY_A") {
          rowObj["VC_NUMBER"] = rec.key;
          if (cardToCasMap) rowObj["CAS_NAME"] = recordCas || rec.casName || "";
          rowObj["CAS_PRODUCTS (C)"] = (rec.aProducts || []).join(",");
          rowObj["STATUS"] = "ONLY_IN_CAS";
        } else if (exportType === "ONLY_B") {
          rowObj["VC_NUMBER"] = rec.key;
          if (cardToCasMap) rowObj["CAS_NAME"] = recordCas || rec.casName || "";
          rowObj["SMS_PRODUCTS (B)"] = (rec.bProducts || []).join(",");
          rowObj["STATUS"] = "ONLY_IN_SMS_B";
        } else if (exportType === "ONLY_C") {
          rowObj["VC_NUMBER"] = rec.key;
          if (cardToCasMap) rowObj["CAS_NAME"] = recordCas || rec.casName || "";
          rowObj["SMS_PRODUCTS (S)"] = (rec.cProducts || []).join(",");
          rowObj["STATUS"] = "ONLY_IN_SMS_S";
        } else if (exportType === "A_DATA") {
          rowObj["VC_NUMBER"] = rec.key;
          rowObj["CAS_NAME"] = recordCas || rec.casName || "";
          rowObj["CAS_PRODUCTS"] = (rec.aProducts || []).join(",");
        } else if (exportType === "B_DATA") {
          rowObj["VC_NUMBER"] = rec.key;
          rowObj["CAS_NAME"] = recordCas || rec.casName || "";
          rowObj["SMS_PRODUCTS"] = (rec.bProducts || []).join(",");
        } else if (exportType === "C_DATA") {
          rowObj["VC_NUMBER"] = rec.key;
          rowObj["CAS_NAME"] = recordCas || rec.casName || "";
          rowObj["SMS_PRODUCTS_S"] = (rec.cProducts || []).join(",");
        }

        currentSheetRows.push(rowObj);

        if (currentSheetRows.length >= SHEET_ROW_LIMIT) {
          appendSingleChunk(currentSheetRows, baseSheetName, partNum, cols);
          currentSheetRows = [];
          partNum++;
        }
      }

      currentOffset = limit;
      const progress = Math.floor((currentOffset / total) * 100);
      onProgress(progress);

      await new Promise((resolve) => setTimeout(resolve, 15));
    }

    if (currentSheetRows.length > 0 || partNum === 1) {
      const sheetName = partNum > 1 ? `${baseSheetName}_P${partNum}`.slice(0, 31) : baseSheetName;
      const ws = XLSX.utils.json_to_sheet(currentSheetRows, { raw: true } as any);
      ws["!cols"] = cols;
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    }
  }

  return wb;
}



