import * as XLSX from "xlsx";

// Memory cache to prevent redundant recalculation on repetitive product group items
const normalizationCache = new Map<string, string[]>();

/**
 * Normalizes lists of products into a sorted list of unique products with caching.
 * Mimics Python's normalize_products behavior precisely and executes at extreme speeds.
 */
export function normalizeProducts(productInput: any, role?: "CAS" | "SMS" | "APP"): string[] {
  if (productInput === null || productInput === undefined) return [];
  
  if (normalizationCache.size > 50000) {
    normalizationCache.clear();
  }

  const rawKey = String(productInput);
  const cacheKey = `${role || ""}_${rawKey}`;
  const cached = normalizationCache.get(cacheKey);
  if (cached) {
    return cached;
  }
  
  // Convert to string, clean quotes
  const productString = rawKey.replace(/'/g, "");
  
  // CAS files split by space and comma/colon/semicolon, while SMS/APP split ONLY by comma/colon/semicolon (preserving spaces in product name)
  let items: string[];
  if (role === "CAS") {
    items = productString.split(/[,\s:;]+/);
  } else if (role === "SMS" || role === "APP") {
    items = productString.split(/[,\r\n:;]+/);
  } else {
    // Default fallback to split on space as well to be backward compatible
    items = productString.split(/[,\s:;]+/);
  }

  const cleaned: string[] = [];
  for (let item of items) {
    const trimmed = item.trim();
    if (trimmed !== "") {
      cleaned.push(trimmed);
    }
  }
  
  // Remove duplicates
  const uniqueItems = Array.from(new Set(cleaned));
  
  // High-performance sorting using single-pass identification
  const annotated = uniqueItems.map(val => {
    const isNum = /^\d+$/.test(val);
    return {
      val,
      isNum,
      num: isNum ? parseInt(val, 10) : NaN
    };
  });

  annotated.sort((a, b) => {
    if (a.isNum && b.isNum) {
      return a.num - b.num;
    } else if (a.isNum) {
      return -1; // Numbers first
    } else if (b.isNum) {
      return 1;
    } else {
      return a.val.localeCompare(b.val);
    }
  });

  const sortedResult = annotated.map(x => x.val);
  normalizationCache.set(cacheKey, sortedResult);
  return sortedResult;
}

/**
 * Clean column name for comparison
 */
export function cleanColName(col: string): string {
  return col
    .toString()
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/_/g, "")
    .replace(/-/g, "")
    .replace(/\n/g, "")
    .replace(/\r/g, "");
}

/**
 * Auto-detect columns for File A (CAS Side)
 * Smart detection for Card ID / VC Number vs Product Number / Product ID
 */
export function detectColumnsA(columns: string[]): { keyCol: string; productCol: string } {
  let keyCol = "";
  let productCol = "";

  if (!columns || columns.length === 0) {
    return { keyCol: "", productCol: "" };
  }

  // 1. First search for productCol (product, productid, productnumber, prod, package, entitlement, service)
  const productKeywords = ["productnumber", "productcasid", "prodcasid", "productid", "product_id", "prod_id", "product", "prod", "package", "entitlement", "service", "offering"];
  for (const kw of productKeywords) {
    for (const col of columns) {
      const clean = cleanColName(col);
      if (clean === kw || clean.includes(kw)) {
        productCol = col;
        break;
      }
    }
    if (productCol) break;
  }

  // 2. Search for keyCol (cardid, vcnumber, vc, card, smartcard, stbid, serial, iccard, unitid, hardwareid)
  const keyKeywords = ["cardid", "card_id", "vcnumber", "vc_number", "vc", "card", "smartcard", "stbid", "stb", "serialnumber", "serial", "iccard", "unitid", "hardwareid", "chipid", "subscriberid", "customerid"];
  for (const kw of keyKeywords) {
    for (const col of columns) {
      if (col === productCol) continue;
      const clean = cleanColName(col);
      if (clean === kw || clean.includes(kw)) {
        keyCol = col;
        break;
      }
    }
    if (keyCol) break;
  }

  // 3. Fallbacks if keyCol or productCol is not found
  if (!keyCol) {
    const byNumOrId = columns.find(col => col !== productCol && (cleanColName(col).includes("number") || cleanColName(col).includes("no") || cleanColName(col).includes("id") || cleanColName(col).includes("code")));
    keyCol = byNumOrId || columns.find(col => col !== productCol) || columns[0] || "";
  }

  if (!productCol) {
    productCol = columns.find(col => col !== keyCol) || (columns[1] !== undefined ? columns[1] : columns[0]) || "";
  }

  return { keyCol, productCol };
}

/**
 * Auto-detect columns for File B (SMS Side)
 * Smart detection for VC Number vs Product CAS ID
 */
export function detectColumnsB(columns: string[]): { keyCol: string; productCol: string } {
  let keyCol = "";
  let productCol = "";

  if (!columns || columns.length === 0) {
    return { keyCol: "", productCol: "" };
  }

  // 1. Search for keyCol first for SMS files (vcnumber, vc, cardid, card, serial, etc.)
  const keyKeywords = ["vcnumber", "vc_number", "vc", "cardid", "card_id", "card", "smartcard", "stbid", "stb", "serialnumber", "serial", "iccard", "customerid", "subscriberid", "unitid"];
  for (const kw of keyKeywords) {
    for (const col of columns) {
      const clean = cleanColName(col);
      if (clean === kw || clean.includes(kw)) {
        keyCol = col;
        break;
      }
    }
    if (keyCol) break;
  }

  // 2. Search for productCol (productcasid, productcas, productid, product_id, productnumber, product, prod, package, entitlement, service)
  const productKeywords = ["productcasid", "productcas", "productid", "product_id", "productnumber", "product", "prod", "package", "entitlement", "service", "offering", "casid"];
  for (const kw of productKeywords) {
    for (const col of columns) {
      if (col === keyCol) continue;
      const clean = cleanColName(col);
      if (clean === kw || clean.includes(kw)) {
        productCol = col;
        break;
      }
    }
    if (productCol) break;
  }

  // Fallbacks:
  if (!keyCol) {
    const byNumOrId = columns.find(col => col !== productCol && (cleanColName(col).includes("number") || cleanColName(col).includes("no") || cleanColName(col).includes("id")));
    keyCol = byNumOrId || columns.find(col => col !== productCol) || columns[0] || "";
  }

  if (!productCol) {
    productCol = columns.find(col => col !== keyCol) || (columns[1] !== undefined ? columns[1] : columns[0]) || "";
  }

  return { keyCol, productCol };
}

/**
 * Automatically detects how many rows of metadata/decoration to skip
 * by scanning the beginning of the spreadsheet to find the header row.
 */
export function autoDetectSkipRows(grid: any[][], role: "CAS" | "SMS" | "APP"): number {
  if (!grid || grid.length === 0) return 0;
  
  const maxScan = Math.min(grid.length, 12);
  
  for (let r = 0; r < maxScan; r++) {
    const row = grid[r];
    if (!row || !Array.isArray(row)) continue;
    
    let matchCount = 0;
    for (const cell of row) {
      if (cell === null || cell === undefined) continue;
      const str = String(cell).toLowerCase().trim().replace(/_/g, "").replace(/\s+/g, "");
      
      if (role === "CAS") {
        if (str.includes("cardid") || str === "card" || str.includes("productnumber") || str.includes("prodnum") || str.includes("partnumber")) {
          matchCount += 2;
        }
        if (str.includes("product") || str === "id" || str === "number" || str === "no") {
          matchCount += 0.5;
        }
      } else {
        // SMS or APP
        if (str === "vcnumber" || str === "cardid" || str === "productcasid" || str === "prodcasid" || str === "serialnumber" || str === "customername" || str === "accountnumber" || str === "packagenames" || str === "package_names") {
          matchCount += 2;
        } else if (str.includes("vc") || str.includes("cardid") || str.includes("productcas") || str.includes("prodcas") || str.includes("serial") || str.includes("customer") || str.includes("account") || str.includes("package")) {
          matchCount += 1.5;
        }
        if (str.includes("product") || str === "id" || str === "number" || str === "no" || str.includes("mobile") || str.includes("location") || str.includes("activation")) {
          matchCount += 0.5;
        }
      }
    }
    
    if (matchCount >= 2) {
      return r;
    }
  }
  
  return role === "CAS" ? 0 : 1;
}

/**
 * Ultra-fast CSV parser handling quoted cells, escapes, and CRLF line breaks.
 */
export function fastParseCSV(text: string): any[][] {
  const lines: any[][] = [];
  const rawLines = text.split(/\r?\n/);
  const total = rawLines.length;
  
  for (let i = 0; i < total; i++) {
    const line = rawLines[i];
    if (!line || line.trim() === "") continue;

    if (line.indexOf('"') === -1) {
      const parts = line.split(",");
      let isAllEmpty = true;
      for (let p = 0; p < parts.length; p++) {
        parts[p] = parts[p].trim();
        if (parts[p] !== "") isAllEmpty = false;
      }
      if (!isAllEmpty) {
        lines.push(parts);
      }
      continue;
    }

    const row: string[] = [];
    let cell = "";
    let inQuotes = false;
    const lineLen = line.length;
    for (let j = 0; j < lineLen; j++) {
      const char = line[j];
      if (char === '"') {
        if (inQuotes && line[j + 1] === '"') {
          cell += '"';
          j++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === "," && !inQuotes) {
        row.push(cell.trim());
        cell = "";
      } else {
        cell += char;
      }
    }
    row.push(cell.trim());
    let isAllEmptyQuoted = true;
    for (let cIdx = 0; cIdx < row.length; cIdx++) {
      if (row[cIdx] !== "") {
        isAllEmptyQuoted = false;
        break;
      }
    }
    if (!isAllEmptyQuoted) {
      lines.push(row);
    }
  }
  return lines;
}

/**
 * Worker script code with safe error boundary
 */
const workerCode = `
  var isXlsxLoaded = false;
  try {
    importScripts('https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js');
    isXlsxLoaded = typeof XLSX !== 'undefined';
  } catch (e) {
    isXlsxLoaded = false;
  }

  function cleanColName(col) {
    if (!col) return "";
    return col.toString().toLowerCase().replace(/\\s+/g, "").replace(/_/g, "").replace(/-/g, "").replace(/\\n/g, "").replace(/\\r/g, "");
  }

  function detectColumnsA(columns) {
    if (!columns || columns.length === 0) return { keyCol: "", productCol: "" };
    var keyCol = "";
    var productCol = "";
    var productKeywords = ["productnumber", "productcasid", "prodcasid", "productid", "product_id", "prod_id", "product", "prod", "package", "entitlement", "service", "offering"];
    for (var i = 0; i < productKeywords.length; i++) {
      var kw = productKeywords[i];
      for (var j = 0; j < columns.length; j++) {
        var col = columns[j];
        var clean = cleanColName(col);
        if (clean === kw || clean.indexOf(kw) !== -1) {
          productCol = col;
          break;
        }
      }
      if (productCol) break;
    }

    var keyKeywords = ["cardid", "card_id", "vcnumber", "vc_number", "vc", "card", "smartcard", "stbid", "stb", "serialnumber", "serial", "iccard", "unitid", "hardwareid", "chipid", "subscriberid", "customerid"];
    for (var i = 0; i < keyKeywords.length; i++) {
      var kw = keyKeywords[i];
      for (var j = 0; j < columns.length; j++) {
        var col = columns[j];
        if (col === productCol) continue;
        var clean = cleanColName(col);
        if (clean === kw || clean.indexOf(kw) !== -1) {
          keyCol = col;
          break;
        }
      }
      if (keyCol) break;
    }

    if (!keyCol) {
      var byNumOrId = columns.find(function(c) {
        return c !== productCol && (cleanColName(c).indexOf("number") !== -1 || cleanColName(c).indexOf("no") !== -1 || cleanColName(c).indexOf("id") !== -1);
      });
      keyCol = byNumOrId || columns.find(function(c) { return c !== productCol; }) || columns[0] || "";
    }

    if (!productCol) {
      productCol = columns.find(function(c) { return c !== keyCol; }) || columns[1] || columns[0] || "";
    }

    return { keyCol: keyCol, productCol: productCol };
  }

  function detectColumnsB(columns) {
    if (!columns || columns.length === 0) return { keyCol: "", productCol: "" };
    var keyCol = "";
    var productCol = "";
    var keyKeywords = ["vcnumber", "vc_number", "vc", "cardid", "card_id", "card", "smartcard", "stbid", "stb", "serialnumber", "serial", "iccard", "customerid", "subscriberid", "unitid"];
    for (var i = 0; i < keyKeywords.length; i++) {
      var kw = keyKeywords[i];
      for (var j = 0; j < columns.length; j++) {
        var col = columns[j];
        var clean = cleanColName(col);
        if (clean === kw || clean.indexOf(kw) !== -1) {
          keyCol = col;
          break;
        }
      }
      if (keyCol) break;
    }

    var productKeywords = ["productcasid", "productcas", "productid", "product_id", "productnumber", "product", "prod", "package", "entitlement", "service", "offering", "casid"];
    for (var i = 0; i < productKeywords.length; i++) {
      var kw = productKeywords[i];
      for (var j = 0; j < columns.length; j++) {
        var col = columns[j];
        if (col === keyCol) continue;
        var clean = cleanColName(col);
        if (clean === kw || clean.indexOf(kw) !== -1) {
          productCol = col;
          break;
        }
      }
      if (productCol) break;
    }

    if (!keyCol) {
      var byNumOrId = columns.find(function(c) {
        return c !== productCol && (cleanColName(c).indexOf("number") !== -1 || cleanColName(c).indexOf("no") !== -1 || cleanColName(c).indexOf("id") !== -1);
      });
      keyCol = byNumOrId || columns.find(function(c) { return c !== productCol; }) || columns[0] || "";
    }

    if (!productCol) {
      productCol = columns.find(function(c) { return c !== keyCol; }) || columns[1] || columns[0] || "";
    }

    return { keyCol: keyCol, productCol: productCol };
  }

  function autoDetectSkipRows(grid, role) {
    if (!grid || grid.length === 0) return 0;
    var maxScan = Math.min(grid.length, 12);
    for (var r = 0; r < maxScan; r++) {
      var row = grid[r];
      if (!row || !Array.isArray(row)) continue;
      var matchCount = 0;
      for (var i = 0; i < row.length; i++) {
        var cell = row[i];
        if (cell === null || cell === undefined) continue;
        var str = String(cell).toLowerCase().trim().replace(/_/g, "").replace(/\\s+/g, "");
        if (role === "CAS") {
          if (str.includes("cardid") || str === "card" || str.includes("productnumber") || str.includes("prodnum") || str.includes("partnumber")) {
            matchCount += 2;
          }
          if (str.includes("product") || str === "id" || str === "number" || str === "no") {
            matchCount += 0.5;
          }
        } else {
          if (str === "vcnumber" || str === "cardid" || str === "productcasid" || str === "prodcasid" || str === "serialnumber" || str === "customername" || str === "accountnumber" || str === "packagenames" || str === "package_names") {
            matchCount += 2;
          } else if (str.includes("vc") || str.includes("cardid") || str.includes("productcas") || str.includes("prodcas") || str.includes("serial") || str.includes("customer") || str.includes("account") || str.includes("package")) {
            matchCount += 1.5;
          }
          if (str.includes("product") || str === "id" || str === "number" || str === "no" || str.includes("mobile") || str.includes("location") || str.includes("activation")) {
            matchCount += 0.5;
          }
        }
      }
      if (matchCount >= 2) {
        return r;
      }
    }
    return role === "CAS" ? 0 : 1;
  }

  function normalizeProducts(productInput, role) {
    if (productInput === null || productInput === undefined) return [];
    var productString = String(productInput).replace(/'/g, "");
    var items;
    if (role === "CAS") {
      items = productString.split(/[\\s,;:]+/);
    } else {
      items = productString.split(/[\\r\\n,;:]+/);
    }
    var cleaned = [];
    for (var i = 0; i < items.length; i++) {
      var trimmed = items[i].trim();
      if (trimmed !== "") {
        cleaned.push(trimmed);
      }
    }
    var uniqueItems = Array.from(new Set(cleaned));
    var annotated = uniqueItems.map(function(val) {
      var isNum = /^\\d+$/.test(val);
      return {
        val: val,
        isNum: isNum,
        num: isNum ? parseInt(val, 10) : NaN
      };
    });
    annotated.sort(function(a, b) {
      if (a.isNum && b.isNum) {
        return a.num - b.num;
      } else if (a.isNum) {
        return -1;
      } else if (b.isNum) {
        return 1;
      } else {
        return a.val.localeCompare(b.val);
      }
    });
    return annotated.map(function(x) { return x.val; });
  }

  function fastParseCSV(text) {
    var lines = [];
    var rawLines = text.split(/\\r?\\n/);
    var total = rawLines.length;
    for (var i = 0; i < total; i++) {
      var line = rawLines[i];
      if (!line || line.trim() === '') continue;

      if (line.indexOf('"') === -1) {
        var parts = line.split(',');
        var isAllEmpty = true;
        for (var p = 0; p < parts.length; p++) {
          parts[p] = parts[p].trim();
          if (parts[p] !== '') isAllEmpty = false;
        }
        if (!isAllEmpty) {
          lines.push(parts);
        }
        continue;
      }

      var row = [];
      var cell = '';
      var inQuotes = false;
      var lineLen = line.length;
      for (var j = 0; j < lineLen; j++) {
        var char = line[j];
        if (char === '"') {
          if (inQuotes && line[j + 1] === '"') {
            cell += '"';
            j++;
          } else {
            inQuotes = !inQuotes;
          }
        } else if (char === ',' && !inQuotes) {
          row.push(cell.trim());
          cell = '';
        } else {
          cell += char;
        }
      }
      row.push(cell.trim());
      var isAllEmptyQuoted = true;
      for (var cIdx = 0; cIdx < row.length; cIdx++) {
        if (row[cIdx] !== '') {
          isAllEmptyQuoted = false;
          break;
        }
      }
      if (!isAllEmptyQuoted) {
        lines.push(row);
      }
    }
    return lines;
  }

  self.onmessage = async function(e) {
    const { data: arrayBuffer, fileName, role, overrideSkipRows, overrideKeyCol, overrideProductCol, isContinuitySheet, overrideColumns, overrideCasCol } = e.data;
    try {
      self.postMessage({ type: 'progress', stage: 'Reading file stream...', percent: 10 });
      const isCSV = fileName && fileName.toLowerCase().endsWith(".csv");
      let rawSheets = [];

      if (isCSV) {
        self.postMessage({ type: 'progress', stage: 'Reading CSV text content...', percent: 25 });
        let text = new TextDecoder("utf-8").decode(arrayBuffer);
        text = text.replace(/'/g, "");
        self.postMessage({ type: 'progress', stage: 'Parsing records...', percent: 50 });
        const grid = fastParseCSV(text);
        text = ""; // Release decoded text string memory
        rawSheets.push({
          sheetName: fileName || "CSV_DATA",
          grid: grid
        });
      } else {
        if (!isXlsxLoaded) {
          throw new Error('FALLBACK_TO_MAIN_THREAD');
        }
        let workbook;
        const opts = { type: 'array', dense: true, cellFormula: false, cellHTML: false, cellText: false, cellDates: false, cellStyles: false };
        try {
          workbook = XLSX.read(arrayBuffer, opts);
        } catch (err) {
          let text = new TextDecoder("utf-8").decode(arrayBuffer);
          text = text.replace(/'/g, "");
          workbook = XLSX.read(text, { type: 'string', dense: true, cellFormula: false, cellHTML: false, cellText: false, cellDates: false, cellStyles: false });
          text = "";
        }
        const sheetNames = workbook.SheetNames;
        self.postMessage({ type: 'progress', stage: 'Decoding ' + sheetNames.length + ' sheet(s)...', percent: 35 });
        for (let i = 0; i < sheetNames.length; i++) {
          const sheetName = sheetNames[i];
          const worksheet = workbook.Sheets[sheetName];
          if (!worksheet) continue;
          self.postMessage({ 
            type: 'progress', 
            stage: 'Parsing cells for sheet [' + sheetName + ']...', 
            percent: Math.min(75, Math.round(35 + (i / sheetNames.length) * 40)) 
          });
          const grid = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: "" });
          delete workbook.Sheets[sheetName]; // Release worksheet memory immediately
          rawSheets.push({ sheetName, grid });
        }
      }

      self.postMessage({ type: 'progress', stage: 'Completing extraction logic...', percent: 80 });
      const sheetsResult = [];

      for (let i = 0; i < rawSheets.length; i++) {
        const { sheetName, grid } = rawSheets[i];
        if (grid.length === 0) continue;

        let skipRows, columns, keyCol, productCol, casCol, keyIdx, prodIdx, casIdx, dataRows;

        if (isContinuitySheet && overrideColumns) {
          skipRows = (overrideSkipRows !== undefined) ? overrideSkipRows : 0;
          columns = overrideColumns;
          keyCol = overrideKeyCol || (columns[0] || "");
          productCol = overrideProductCol || (columns[1] || columns[0] || "");
          casCol = overrideCasCol || "";
          keyIdx = columns.indexOf(keyCol);
          prodIdx = columns.indexOf(productCol);
          casIdx = casCol ? columns.indexOf(casCol) : -1;
          dataRows = grid.slice(skipRows);
        } else {
          skipRows = (overrideSkipRows !== undefined) ? overrideSkipRows : autoDetectSkipRows(grid, role);
          if (grid.length <= skipRows) continue;

          const remainingGrid = grid.slice(skipRows);
          if (remainingGrid.length === 0) continue;

          const rawHeaders = remainingGrid[0];
          columns = rawHeaders.map(function(h, colIdx) {
            const val = String(h !== null && h !== undefined ? h : "").trim();
            return val !== "" ? val : "Column_" + (colIdx + 1);
          });

          const detection = (role === "CAS") ? detectColumnsA(columns) : detectColumnsB(columns);
          keyCol = (overrideKeyCol && columns.indexOf(overrideKeyCol) !== -1) ? overrideKeyCol : (detection.keyCol || columns[0] || "");
          productCol = (overrideProductCol && columns.indexOf(overrideProductCol) !== -1) ? overrideProductCol : (detection.productCol || columns[1] || columns[0] || "");

          casCol = (overrideCasCol && columns.indexOf(overrideCasCol) !== -1) ? overrideCasCol : "";
          if (!casCol && (role === "APP" || role === "SMS")) {
            var foundCas = columns.find(function(c) {
              var clean = cleanColName(c);
              return (clean.includes("cas") || clean.includes("system") || clean.includes("casname") || clean.includes("casid")) && c !== keyCol && c !== productCol;
            });
            if (foundCas) {
              casCol = foundCas;
            }
          }

          keyIdx = columns.indexOf(keyCol);
          prodIdx = columns.indexOf(productCol);
          casIdx = casCol ? columns.indexOf(casCol) : -1;
          dataRows = remainingGrid.slice(1);
        }

        const parsedData = {};
        const parsedCasData = {};
        const uniqueCasSet = new Set();
        let validRowCount = 0;

        if (role === "CAS") {
          const grouped = {};
          for (let rIdx = 0; rIdx < dataRows.length; rIdx++) {
            const row = dataRows[rIdx];
            if (!row || row.length === 0) continue;
            let isRowEmpty = true;
            for (let c = 0; c < row.length; c++) {
              if (row[c] !== null && row[c] !== undefined && String(row[c]).trim() !== "") {
                isRowEmpty = false;
                break;
              }
            }
            if (isRowEmpty) continue;
            validRowCount++;

            const rawK = keyIdx !== -1 ? row[keyIdx] : undefined;
            if (rawK === undefined || rawK === null) continue;
            const k = String(rawK).replace(/'/g, "").trim();
            if (k === "") continue;

            const rawProd = prodIdx !== -1 ? row[prodIdx] : undefined;
            const prodStr = rawProd !== undefined && rawProd !== null ? String(rawProd).replace(/'/g, "").trim() : "";

            if (!grouped[k]) grouped[k] = [];
            if (prodStr !== "") grouped[k].push(prodStr);
          }

          const groupedKeys = Object.keys(grouped);
          for (let kIdx = 0; kIdx < groupedKeys.length; kIdx++) {
            const key = groupedKeys[kIdx];
            const joinedStr = grouped[key].join(",");
            parsedData[key] = normalizeProducts(joinedStr, "CAS");
          }
        } else {
          for (let rIdx = 0; rIdx < dataRows.length; rIdx++) {
            const row = dataRows[rIdx];
            if (!row || row.length === 0) continue;
            let isRowEmpty = true;
            for (let c = 0; c < row.length; c++) {
              if (row[c] !== null && row[c] !== undefined && String(row[c]).trim() !== "") {
                isRowEmpty = false;
                break;
              }
            }
            if (isRowEmpty) continue;
            validRowCount++;

            const rawK = keyIdx !== -1 ? row[keyIdx] : undefined;
            if (rawK === undefined || rawK === null) continue;
            const k = String(rawK).replace(/'/g, "").trim();
            if (k === "") continue;

            const rawProd = prodIdx !== -1 ? row[prodIdx] : undefined;
            const prodStr = rawProd !== undefined && rawProd !== null ? String(rawProd).replace(/'/g, "").trim() : "";

            const products = normalizeProducts(prodStr, role);
            if (!parsedData[k]) {
              parsedData[k] = products;
            } else {
              const existing = parsedData[k];
              for (let pIdx = 0; pIdx < products.length; pIdx++) {
                const pItem = products[pIdx];
                if (existing.indexOf(pItem) === -1) {
                  existing.push(pItem);
                }
              }
            }

            if (casIdx !== -1) {
              const rawCas = row[casIdx];
              const casVal = rawCas !== undefined && rawCas !== null ? String(rawCas).replace(/'/g, "").trim() : "";
              if (casVal !== "") {
                parsedCasData[k] = casVal;
                if (!casVal.includes("_")) {
                  uniqueCasSet.add(casVal);
                }
              }
            }
          }
        }

        const partialGrid = grid.slice(0, 15);
        rawSheets[i].grid = []; // Release grid memory immediately for large files

        sheetsResult.push({
          sheetName,
          columns,
          skipRows,
          rowCount: validRowCount,
          detectedKeyCol: keyCol,
          detectedProductCol: productCol,
          detectedCasCol: casCol,
          parsedData,
          parsedCasData,
          uniqueCasNames: Array.from(uniqueCasSet),
          partialGrid
        });
      }

      self.postMessage({ type: 'progress', stage: 'Finalizing structure...', percent: 100 });
      self.postMessage({ type: 'success', sheets: sheetsResult });
      rawSheets.length = 0;
    } catch (err) {
      self.postMessage({ type: 'error', error: err.message || String(err) });
    }
  };
`;

/**
 * Resilient, non-blocking spreadsheet processor running in main thread with cooperative multitasking
 */
export async function parseSheetsOnMainThread(
  arrayBuffer: ArrayBuffer,
  fileName: string,
  role: "CAS" | "SMS" | "APP",
  overrideSkipRows?: number,
  overrideKeyCol?: string,
  overrideProductCol?: string,
  onProgress?: (stage: string, percent: number) => void,
  isContinuitySheet?: boolean,
  overrideColumns?: string[],
  overrideCasCol?: string
): Promise<{ sheets: {
  sheetName: string;
  columns: string[];
  skipRows: number;
  rowCount: number;
  detectedKeyCol: string;
  detectedProductCol: string;
  detectedCasCol?: string;
  parsedData: Record<string, string[]>;
  parsedCasData?: Record<string, string>;
  uniqueCasNames?: string[];
  partialGrid: any[][];
}[] }> {
  if (onProgress) onProgress("Reading file structure...", 10);
  await new Promise(r => setTimeout(r, 0));

  const isCSV = fileName && fileName.toLowerCase().endsWith(".csv");
  const rawSheets: { sheetName: string; grid: any[][] }[] = [];

  if (isCSV) {
    if (onProgress) onProgress("Parsing CSV content...", 25);
    await new Promise(r => setTimeout(r, 0));
    let text = new TextDecoder("utf-8").decode(arrayBuffer);
    text = text.replace(/'/g, "");
    const grid = fastParseCSV(text);
    rawSheets.push({
      sheetName: fileName || "CSV_DATA",
      grid
    });
  } else {
    if (onProgress) onProgress("Decoding Excel workbook...", 20);
    await new Promise(r => setTimeout(r, 0));

    let workbook: XLSX.WorkBook;
    const readOpts = { type: "array" as const, dense: true, cellFormula: false, cellHTML: false, cellText: false, cellDates: false, cellStyles: false };
    try {
      workbook = XLSX.read(arrayBuffer, readOpts);
    } catch {
      let text = new TextDecoder("utf-8").decode(arrayBuffer).replace(/'/g, "");
      workbook = XLSX.read(text, { type: "string", dense: true, cellFormula: false, cellHTML: false, cellText: false, cellDates: false, cellStyles: false });
      text = "";
    }

    const sheetNames = workbook.SheetNames;
    for (let i = 0; i < sheetNames.length; i++) {
      const sheetName = sheetNames[i];
      const worksheet = workbook.Sheets[sheetName];
      if (!worksheet) continue;

      if (onProgress) {
        const pct = Math.min(65, Math.round(20 + (i / Math.max(1, sheetNames.length)) * 45));
        onProgress(`Extracting grid from [${sheetName}]...`, pct);
      }
      await new Promise(r => setTimeout(r, 0));

      const grid = XLSX.utils.sheet_to_json<any[]>(worksheet, { header: 1, defval: "" });
      delete workbook.Sheets[sheetName]; // Immediately release worksheet memory
      rawSheets.push({ sheetName, grid });
    }
  }

  if (onProgress) onProgress("Analyzing columns & records...", 70);
  await new Promise(r => setTimeout(r, 0));

  const sheetsResult: any[] = [];

  for (let i = 0; i < rawSheets.length; i++) {
    const { sheetName, grid } = rawSheets[i];
    if (grid.length === 0) continue;

    let skipRows: number;
    let columns: string[];
    let keyCol: string;
    let productCol: string;
    let casCol = "";
    let keyIdx: number;
    let prodIdx: number;
    let casIdx = -1;
    let dataRows: any[][];

    if (isContinuitySheet && overrideColumns) {
      skipRows = overrideSkipRows !== undefined ? overrideSkipRows : 0;
      columns = overrideColumns;
      keyCol = overrideKeyCol || columns[0] || "";
      productCol = overrideProductCol || columns[1] || columns[0] || "";
      casCol = overrideCasCol || "";
      keyIdx = columns.indexOf(keyCol);
      prodIdx = columns.indexOf(productCol);
      casIdx = casCol ? columns.indexOf(casCol) : -1;
      dataRows = grid.slice(skipRows);
    } else {
      skipRows = overrideSkipRows !== undefined ? overrideSkipRows : autoDetectSkipRows(grid, role);
      if (grid.length <= skipRows) continue;

      const remainingGrid = grid.slice(skipRows);
      if (remainingGrid.length === 0) continue;

      const rawHeaders = remainingGrid[0];
      columns = rawHeaders.map((h, colIdx) => {
        const val = String(h !== null && h !== undefined ? h : "").trim();
        return val !== "" ? val : `Column_${colIdx + 1}`;
      });

      const detection = role === "CAS" ? detectColumnsA(columns) : detectColumnsB(columns);
      keyCol = overrideKeyCol && columns.indexOf(overrideKeyCol) !== -1 ? overrideKeyCol : detection.keyCol || columns[0] || "";
      productCol = overrideProductCol && columns.indexOf(overrideProductCol) !== -1 ? overrideProductCol : detection.productCol || columns[1] || columns[0] || "";

      casCol = overrideCasCol && columns.indexOf(overrideCasCol) !== -1 ? overrideCasCol : "";
      if (!casCol && (role === "APP" || role === "SMS")) {
        const foundCas = columns.find(c => {
          const clean = cleanColName(c);
          return (clean.includes("cas") || clean.includes("system") || clean.includes("casname") || clean.includes("casid")) && c !== keyCol && c !== productCol;
        });
        if (foundCas) casCol = foundCas;
      }

      keyIdx = columns.indexOf(keyCol);
      prodIdx = columns.indexOf(productCol);
      casIdx = casCol ? columns.indexOf(casCol) : -1;
      dataRows = remainingGrid.slice(1);
    }

    const parsedData: Record<string, string[]> = {};
    const parsedCasData: Record<string, string> = {};
    const uniqueCasSet = new Set<string>();
    let validRowCount = 0;

    const CHUNK = 5000;
    const totalDataRows = dataRows.length;

    if (role === "CAS") {
      const grouped: Record<string, string[]> = {};
      for (let rIdx = 0; rIdx < totalDataRows; rIdx++) {
        if (rIdx > 0 && rIdx % CHUNK === 0) {
          if (onProgress) {
            const pct = Math.min(90, Math.round(70 + (rIdx / totalDataRows) * 20));
            onProgress(`Parsing CAS rows (${rIdx.toLocaleString()}/${totalDataRows.toLocaleString()})...`, pct);
          }
          await new Promise(r => setTimeout(r, 0));
        }

        const row = dataRows[rIdx];
        if (!row || row.length === 0) continue;
        let isRowEmpty = true;
        for (let c = 0; c < row.length; c++) {
          if (row[c] !== null && row[c] !== undefined && String(row[c]).trim() !== "") {
            isRowEmpty = false;
            break;
          }
        }
        if (isRowEmpty) continue;
        validRowCount++;

        const rawK = keyIdx !== -1 ? row[keyIdx] : undefined;
        if (rawK === undefined || rawK === null) continue;
        const k = String(rawK).replace(/'/g, "").trim();
        if (k === "") continue;

        const rawProd = prodIdx !== -1 ? row[prodIdx] : undefined;
        const prodStr = rawProd !== undefined && rawProd !== null ? String(rawProd).replace(/'/g, "").trim() : "";

        if (!grouped[k]) grouped[k] = [];
        if (prodStr !== "") grouped[k].push(prodStr);
      }

      const groupedKeys = Object.keys(grouped);
      for (let kIdx = 0; kIdx < groupedKeys.length; kIdx++) {
        const key = groupedKeys[kIdx];
        const joinedStr = grouped[key].join(",");
        parsedData[key] = normalizeProducts(joinedStr, "CAS");
      }
    } else {
      for (let rIdx = 0; rIdx < totalDataRows; rIdx++) {
        if (rIdx > 0 && rIdx % CHUNK === 0) {
          if (onProgress) {
            const pct = Math.min(90, Math.round(70 + (rIdx / totalDataRows) * 20));
            onProgress(`Parsing SMS rows (${rIdx.toLocaleString()}/${totalDataRows.toLocaleString()})...`, pct);
          }
          await new Promise(r => setTimeout(r, 0));
        }

        const row = dataRows[rIdx];
        if (!row || row.length === 0) continue;
        let isRowEmpty = true;
        for (let c = 0; c < row.length; c++) {
          if (row[c] !== null && row[c] !== undefined && String(row[c]).trim() !== "") {
            isRowEmpty = false;
            break;
          }
        }
        if (isRowEmpty) continue;
        validRowCount++;

        const rawK = keyIdx !== -1 ? row[keyIdx] : undefined;
        if (rawK === undefined || rawK === null) continue;
        const k = String(rawK).replace(/'/g, "").trim();
        if (k === "") continue;

        const rawProd = prodIdx !== -1 ? row[prodIdx] : undefined;
        const prodStr = rawProd !== undefined && rawProd !== null ? String(rawProd).replace(/'/g, "").trim() : "";

        const products = normalizeProducts(prodStr, role);
        if (!parsedData[k]) {
          parsedData[k] = products;
        } else {
          const existing = parsedData[k];
          for (let pIdx = 0; pIdx < products.length; pIdx++) {
            const pItem = products[pIdx];
            if (existing.indexOf(pItem) === -1) {
              existing.push(pItem);
            }
          }
        }

        if (casIdx !== -1) {
          const rawCas = row[casIdx];
          const casVal = rawCas !== undefined && rawCas !== null ? String(rawCas).replace(/'/g, "").trim() : "";
          if (casVal !== "") {
            parsedCasData[k] = casVal;
            if (!casVal.includes("_")) {
              uniqueCasSet.add(casVal);
            }
          }
        }
      }
    }

    const partialGrid = grid.slice(0, 50);

    sheetsResult.push({
      sheetName,
      columns,
      skipRows,
      rowCount: validRowCount,
      detectedKeyCol: keyCol,
      detectedProductCol: productCol,
      detectedCasCol: casCol,
      parsedData,
      parsedCasData,
      uniqueCasNames: Array.from(uniqueCasSet),
      partialGrid
    });
  }

  if (onProgress) onProgress("Finalizing data tables...", 100);
  return { sheets: sheetsResult };
}

/**
 * Parses all sheets of an Excel workbook using a background Web Worker with automatic fallback to fast main-thread parser.
 */
export async function parseExcelMultiSheet(
  file: File,
  role: "CAS" | "SMS" | "APP",
  overrideSkipRows?: number,
  overrideKeyCol?: string,
  overrideProductCol?: string,
  onProgress?: (stage: string, percent: number) => void,
  isContinuitySheet?: boolean,
  overrideColumns?: string[],
  overrideCasCol?: string
): Promise<{ sheets: { 
  sheetName: string; 
  columns: string[];
  skipRows: number;
  rowCount: number;
  detectedKeyCol: string;
  detectedProductCol: string;
  detectedCasCol?: string;
  parsedData: Record<string, string[]>;
  parsedCasData?: Record<string, string>;
  uniqueCasNames?: string[];
  partialGrid: any[][];
}[] }> {
  // Read array buffer
  const arrayBuffer = await new Promise<ArrayBuffer>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = e.target?.result as ArrayBuffer;
      if (!data) reject(new Error("Failed to read file contents."));
      else resolve(data);
    };
    reader.onerror = () => reject(new Error("Error reading file input."));
    reader.readAsArrayBuffer(file);
  });

  // Try Web Worker first for non-blocking background execution
  const tryWorker = (): Promise<{ sheets: any[] }> => {
    return new Promise((resolve, reject) => {
      try {
        const workerBlob = new Blob([workerCode], { type: "application/javascript" });
        const workerUrl = URL.createObjectURL(workerBlob);
        const worker = new Worker(workerUrl);

        worker.onmessage = (event) => {
          const msg = event.data;
          if (msg.type === "progress") {
            if (onProgress) onProgress(msg.stage, msg.percent);
          } else if (msg.type === "success") {
            worker.terminate();
            URL.revokeObjectURL(workerUrl);
            resolve({ sheets: msg.sheets });
          } else if (msg.type === "error") {
            worker.terminate();
            URL.revokeObjectURL(workerUrl);
            reject(new Error(msg.error));
          }
        };

        worker.onerror = (err) => {
          worker.terminate();
          URL.revokeObjectURL(workerUrl);
          reject(new Error(`Worker error: ${err.message}`));
        };

        // Clone buffer to worker
        worker.postMessage({ 
          data: arrayBuffer.slice(0), 
          fileName: file.name, 
          role, 
          overrideSkipRows, 
          overrideKeyCol, 
          overrideProductCol,
          isContinuitySheet,
          overrideColumns,
          overrideCasCol
        });
      } catch (workerErr) {
        reject(workerErr);
      }
    });
  };

  try {
    return await tryWorker();
  } catch (workerError) {
    // If worker fails (e.g. offline, CSP block, importScripts failure), smoothly fallback to fast main-thread parser
    return await parseSheetsOnMainThread(
      arrayBuffer,
      file.name,
      role,
      overrideSkipRows,
      overrideKeyCol,
      overrideProductCol,
      onProgress,
      isContinuitySheet,
      overrideColumns,
      overrideCasCol
    );
  }
}

/**
 * Parses Master Product file (Products & MSR workspaces) asynchronously with non-blocking chunks and progress
 */
export async function parseMasterProductFileAsync(
  file: File,
  onProgress?: (stage: string, percent: number) => void
): Promise<{
  columns: string[];
  rows: Record<string, any>[];
  suggestedMapping: {
    productIdCol: string;
    productNameCol: string;
    casCol: string;
    broadcasterCol: string;
  };
}> {
  if (onProgress) onProgress("Reading Master Product file...", 15);
  await new Promise(r => setTimeout(r, 0));

  const arrayBuffer = await new Promise<ArrayBuffer>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = e.target?.result as ArrayBuffer;
      if (!data) reject(new Error("Failed to read file contents."));
      else resolve(data);
    };
    reader.onerror = () => reject(new Error("Error reading master product file."));
    reader.readAsArrayBuffer(file);
  });

  const isCSV = file.name.toLowerCase().endsWith(".csv");
  let jsonGrid: any[][] = [];

  if (isCSV) {
    if (onProgress) onProgress("Tokenizing CSV product catalog...", 40);
    await new Promise(r => setTimeout(r, 0));
    const text = new TextDecoder("utf-8").decode(arrayBuffer);
    jsonGrid = fastParseCSV(text);
  } else {
    if (onProgress) onProgress("Reading Excel workbook...", 40);
    await new Promise(r => setTimeout(r, 0));

    let workbook: XLSX.WorkBook;
    const readOpts = { type: "array" as const, dense: true, cellFormula: false, cellHTML: false, cellText: false, cellDates: false, cellStyles: false };
    try {
      workbook = XLSX.read(arrayBuffer, readOpts);
    } catch {
      let text = new TextDecoder("utf-8").decode(arrayBuffer);
      workbook = XLSX.read(text, { type: "string", dense: true, cellFormula: false, cellHTML: false, cellText: false, cellDates: false, cellStyles: false });
      text = "";
    }

    if (workbook.SheetNames.length === 0) {
      throw new Error("Selected workbook contains no sheets.");
    }
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    jsonGrid = XLSX.utils.sheet_to_json<any[]>(worksheet, { header: 1, defval: "" });
    delete workbook.Sheets[workbook.SheetNames[0]]; // Free worksheet memory
  }

  if (jsonGrid.length === 0) {
    throw new Error("The selected sheet is empty.");
  }

  if (onProgress) onProgress("Analyzing headers & building records...", 70);
  await new Promise(r => setTimeout(r, 0));

  // Detect columns from row 0
  const rawHeaders = jsonGrid[0];
  const columns = rawHeaders.map((h: any, idx: number) => {
    const str = String(h !== null && h !== undefined ? h : "").trim();
    return str !== "" ? str : `Column_${idx + 1}`;
  });

  const total = jsonGrid.length - 1;
  const rows: Record<string, any>[] = [];
  const CHUNK = 4000;

  for (let i = 1; i < jsonGrid.length; i += CHUNK) {
    const end = Math.min(i + CHUNK, jsonGrid.length);
    for (let j = i; j < end; j++) {
      const rawRow = jsonGrid[j];
      if (!rawRow || rawRow.length === 0) continue;
      const obj: Record<string, any> = {};
      let hasData = false;
      for (let c = 0; c < columns.length; c++) {
        const val = rawRow[c] !== undefined && rawRow[c] !== null ? String(rawRow[c]).trim() : "";
        obj[columns[c]] = val;
        if (val !== "") hasData = true;
      }
      if (hasData) {
        rows.push(obj);
      }
    }

    if (onProgress) {
      const pct = Math.min(95, Math.round(70 + (i / Math.max(1, total)) * 25));
      onProgress(`Processing products (${rows.length.toLocaleString()}/${total.toLocaleString()})...`, pct);
    }
    await new Promise(r => setTimeout(r, 0));
  }

  // Auto-suggest matches for the 4 headers based on column names
  const cleanCols = columns.map(c => c.toLowerCase().replace(/[\s\-_]+/g, ""));
  let pId = "";
  let pName = "";
  let pCas = "";
  let pBroadcaster = "";

  cleanCols.forEach((colClean, idx) => {
    const original = columns[idx];
    if (colClean.includes("productid") || colClean.includes("prodid") || colClean === "id" || colClean === "code") {
      pId = original;
    } else if (colClean.includes("productname") || colClean.includes("prodname") || colClean === "name" || colClean === "product") {
      pName = original;
    } else if (colClean.includes("cas") || colClean.includes("system") || colClean === "casid") {
      pCas = original;
    } else if (colClean.includes("broadcaster") || colClean.includes("operator") || colClean === "channel") {
      pBroadcaster = original;
    }
  });

  const suggestedMapping = {
    productIdCol: pId || columns[0] || "",
    productNameCol: pName || columns[1] || columns[0] || "",
    casCol: pCas || columns[2] || columns[0] || "",
    broadcasterCol: pBroadcaster || columns[3] || columns[0] || ""
  };

  if (onProgress) onProgress("Master catalog ready!", 100);
  return { columns, rows, suggestedMapping };
}

/**
 * Parses an Excel file (legacy/backward compatibility placeholder)
 */
export async function parseExcel(
  file: File,
  _skipRows: number = 0,
  _onProgress?: (stage: string, percent: number) => void
): Promise<{ columns: string[]; rawRows: any[] }> {
  return { columns: [], rawRows: [] };
}

/**
 * Takes a raw cells grid and decodes it into clean columns and row objects based on a skipRows count.
 */
export function extractSheetData(
  grid: any[][],
  skipRows: number
): { columns: string[]; rawRows: any[] } {
  if (grid.length <= skipRows) {
    return { columns: [], rawRows: [] };
  }
  
  const remainingGrid = grid.slice(skipRows);
  if (remainingGrid.length === 0) {
    return { columns: [], rawRows: [] };
  }
  
  const rawHeaders = remainingGrid[0];
  const columns = rawHeaders.map((h, i) => {
    const val = String(h !== null && h !== undefined ? h : "").trim();
    return val !== "" ? val : `Column_${i + 1}`;
  });

  const rawRows: any[] = [];
  const dataRows = remainingGrid.slice(1);
  
  for (const row of dataRows) {
    const isRowEmpty = row.every((cell: any) => String(cell !== null && cell !== undefined ? cell : "").trim() === "");
    if (isRowEmpty) continue;

    const rowObj: Record<string, any> = {};
    columns.forEach((col, idx) => {
      rowObj[col] = row[idx] !== undefined ? row[idx] : "";
    });
    rawRows.push(rowObj);
  }

  return { columns, rawRows };
}

/**
 * Groups and processes File A data: Group card_id as list, group products, joined by comma and normalized
 */
export function processFileA(
  rawRows: any[],
  keyCol: string,
  productCol: string
): Record<string, string[]> {
  const groupedProducts: Record<string, string[]> = {};

  for (const row of rawRows) {
    const rawKey = row[keyCol];
    if (rawKey === undefined || rawKey === null) continue;
    
    const key = String(rawKey).replace(/'/g, "").trim();
    if (key === "") continue;

    const rawProduct = row[productCol];
    const productStr = rawProduct !== undefined && rawProduct !== null ? String(rawProduct).replace(/'/g, "").trim() : "";

    if (!groupedProducts[key]) {
      groupedProducts[key] = [];
    }
    if (productStr !== "") {
      groupedProducts[key].push(productStr);
    }
  }

  const processedData: Record<string, string[]> = {};
  for (const key of Object.keys(groupedProducts)) {
    const joinedStr = groupedProducts[key].join(",");
    processedData[key] = normalizeProducts(joinedStr, "CAS");
  }

  return processedData;
}

/**
 * Processes File B data row by row, normalizing the product cas id
 */
export function processFileB(
  rawRows: any[],
  keyCol: string,
  productCol: string
): Record<string, string[]> {
  const processedData: Record<string, string[]> = {};

  for (const row of rawRows) {
    const rawKey = row[keyCol];
    if (rawKey === undefined || rawKey === null) continue;
    
    const key = String(rawKey).replace(/'/g, "").trim();
    if (key === "") continue;

    const rawProduct = row[productCol];
    const cleanProductVal = rawProduct !== undefined && rawProduct !== null ? String(rawProduct).replace(/'/g, "").trim() : "";

    const products = normalizeProducts(cleanProductVal, "SMS");
    processedData[key] = products;
  }

  return processedData;
}

/**
 * Groups and processes File A data asynchronously in non-blocking batches.
 */
export async function processFileAAsync(
  rawRows: any[],
  keyCol: string,
  productCol: string,
  onProgress?: (stage: string, percent: number) => void
): Promise<Record<string, string[]>> {
  const groupedProducts: Record<string, string[]> = {};
  const total = rawRows.length;
  const chunkSize = 2500;

  for (let i = 0; i < total; i += chunkSize) {
    const chunk = rawRows.slice(i, i + chunkSize);
    for (const row of chunk) {
      const rawKey = row[keyCol];
      if (rawKey === undefined || rawKey === null) continue;
      
      const key = String(rawKey).replace(/'/g, "").trim();
      if (key === "") continue;

      const rawProduct = row[productCol];
      const productStr = rawProduct !== undefined && rawProduct !== null 
        ? String(rawProduct).replace(/'/g, "").trim() 
        : "";

      if (!groupedProducts[key]) {
        groupedProducts[key] = [];
      }
      if (productStr !== "") {
        groupedProducts[key].push(productStr);
      }
    }
    
    if (onProgress) {
      const pct = Math.min(45, Math.round((i / total) * 45));
      onProgress("Mapping & sorting product distributions...", pct);
    }
    await new Promise((r) => setTimeout(r, 4));
  }

  const processedData: Record<string, string[]> = {};
  const keys = Object.keys(groupedProducts);
  const totalKeys = keys.length;
  const keyChunkSize = 1500;

  for (let i = 0; i < totalKeys; i += keyChunkSize) {
    const chunkKeys = keys.slice(i, i + keyChunkSize);
    for (const key of chunkKeys) {
      const joinedStr = groupedProducts[key].join(",");
      processedData[key] = normalizeProducts(joinedStr, "CAS");
    }
    
    if (onProgress) {
      const pct = Math.min(100, Math.round(45 + (i / totalKeys) * 55));
      onProgress("Sanitizing and deduplicating clusters...", pct);
    }
    await new Promise((r) => setTimeout(r, 4));
  }

  return processedData;
}

/**
 * Processes File B data asynchronously in non-blocking batches.
 */
export async function processFileBAsync(
  rawRows: any[],
  keyCol: string,
  productCol: string,
  onProgress?: (stage: string, percent: number) => void
): Promise<Record<string, string[]>> {
  const processedData: Record<string, string[]> = {};
  const total = rawRows.length;
  const chunkSize = 2500;

  for (let i = 0; i < total; i += chunkSize) {
    const chunk = rawRows.slice(i, i + chunkSize);
    for (const row of chunk) {
      const rawKey = row[keyCol];
      if (rawKey === undefined || rawKey === null) continue;
      
      const key = String(rawKey).replace(/'/g, "").trim();
      if (key === "") continue;

      const rawProduct = row[productCol];
      const cleanProductVal = rawProduct !== undefined && rawProduct !== null 
        ? String(rawProduct).replace(/'/g, "").trim() 
        : "";

      processedData[key] = normalizeProducts(cleanProductVal, "SMS");
    }
    
    if (onProgress) {
      const pct = Math.min(100, Math.round((i / total) * 100));
      onProgress("Cleansing and mapping elements...", pct);
    }
    await new Promise((r) => setTimeout(r, 4));
  }

  return processedData;
}

