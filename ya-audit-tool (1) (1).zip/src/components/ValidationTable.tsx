import React, { useState, useMemo } from "react";
import { Search, Filter, ArrowUpDown, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, CheckCircle2, XCircle, Info, ExternalLink } from "lucide-react";
import { ValidationRecord, ValidationSummary, SheetState, IgnoreDigitRule } from "../types";
import { queryValidationRecords } from "../utils/validationCache";
import { getAllUniqueCasNames } from "../utils/casNames";

interface ValidationTableProps {
  records: ValidationRecord[];
  onDownloadExcel: (
    type: "ALL" | "MATCH" | "MISMATCH" | "ONLY_A" | "ONLY_B" | "ONLY_C" | "A_DATA" | "B_DATA" | "C_DATA",
    format: "CSV" | "EXCEL",
    casFilter?: string
  ) => void;
  comparisonMode?: "A_B" | "B_C" | "A_C" | "A_B_C";
  summaryStats?: ValidationSummary | null;
  sheets: SheetState[];
  selectedCasFilter: string;
  onCasFilterChange: (cas: string) => void;
  ignoreDigitEnabled?: boolean;
  ignoreDigitRules?: IgnoreDigitRule[];
  ignoreZeroProductEnabled?: boolean;
  onIgnoreZeroProductToggle?: (enabled: boolean) => void;
}

type FilterStatus = "ALL" | "MATCH" | "MISMATCH" | "ONLY_A" | "ONLY_B" | "ONLY_C";
type SortField = "key" | "status" | "aLength" | "bLength" | "cLength";
type SortOrder = "asc" | "desc";

export default function ValidationTable({ 
  records, 
  onDownloadExcel, 
  comparisonMode = "A_C",
  summaryStats = null,
  sheets,
  selectedCasFilter,
  onCasFilterChange,
  ignoreDigitEnabled = false,
  ignoreDigitRules = [],
  ignoreZeroProductEnabled = false,
  onIgnoreZeroProductToggle,
}: ValidationTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<FilterStatus>("ALL");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  
  const [sortField, setSortField] = useState<SortField>("key");
  const [sortOrder, setSortOrder] = useState<SortOrder>("asc");
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [exportFormat, setExportFormat] = useState<"CSV" | "EXCEL">("CSV");

  // Get map of Card ID -> CAS name from APP sheets and active CAS sheets
  const cardToCasMap = useMemo(() => {
    const map = new Map<string, string>();
    sheets.forEach(sheet => {
      if ((sheet.role === "APP" || sheet.role === "SMS") && sheet.parsedCasData) {
        const casData = sheet.parsedCasData;
        for (const key in casData) {
          const val = casData[key];
          if (val && val.trim() !== "") {
            if (!key.includes("_")) {
              map.set(key, val.trim());
            }
          }
        }
      }
    });
    // Fallback: Populate from CAS sheets for keys not present in APP sheets
    sheets.forEach(sheet => {
      if (sheet.role === "CAS" && sheet.associatedCasName) {
        const associatedCas = sheet.associatedCasName.trim();
        if (associatedCas && sheet.parsedData) {
          const parsedData = sheet.parsedData;
          for (const key in parsedData) {
            if (!map.has(key)) {
              map.set(key, associatedCas);
            }
          }
        }
      }
    });

    // Expand the map with normalized keys if Ignore Digit is active
    if (ignoreDigitEnabled && ignoreDigitRules.length > 0) {
      const allRule = ignoreDigitRules.find(r => r.cas === "ALL");
      const rulesByCas = new Map<string, IgnoreDigitRule>();
      ignoreDigitRules.forEach(r => {
        if (r.cas && r.cas !== "ALL") {
          rulesByCas.set(r.cas.toLowerCase(), r);
        }
      });

      const keysToAdd: [string, string][] = [];
      map.forEach((casName, originalKey) => {
        const rule = (casName ? rulesByCas.get(casName.toLowerCase()) : undefined) || allRule;
        if (rule && originalKey.length > rule.length) {
          const normalizedKey = rule.direction === "BACKWARD"
            ? originalKey.slice(0, Math.max(0, originalKey.length - rule.count))
            : originalKey.slice(rule.count);
          if (normalizedKey && normalizedKey !== originalKey && !map.has(normalizedKey)) {
            keysToAdd.push([normalizedKey, casName]);
          }
        }
      });
      for (let i = 0; i < keysToAdd.length; i++) {
        map.set(keysToAdd[i][0], keysToAdd[i][1]);
      }
    }

    return map;
  }, [sheets, ignoreDigitEnabled, ignoreDigitRules]);

  // Extract unique CAS name list from sheets using cached aggregated utility
  const uniqueCasList = useMemo<string[]>(() => {
    return getAllUniqueCasNames(sheets);
  }, [sheets]);

  // Set of lowercase active/uploaded CAS names
  const uploadedCasNames = useMemo<Set<string>>(() => {
    const names = new Set<string>();
    sheets.forEach(sheet => {
      if (sheet.role === "CAS" && sheet.associatedCasName) {
        const cleanName = sheet.associatedCasName.trim().toLowerCase();
        if (cleanName) {
          names.add(cleanName);
        }
      }
    });
    return names;
  }, [sheets]);

  const handleCasChange = (cas: string) => {
    onCasFilterChange(cas);
    setCurrentPage(1);
  };

  // Reset pagination on filter or search edits
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  const handleStatusChange = (status: FilterStatus) => {
    setStatusFilter(status);
    setCurrentPage(1);
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
    setCurrentPage(1);
  };

  // Determine which columns are active in current comparison mode
  const showA = comparisonMode === "A_B" || comparisonMode === "A_C" || comparisonMode === "A_B_C";
  const showB = comparisonMode === "A_B" || comparisonMode === "B_C" || comparisonMode === "A_B_C";
  const showC = comparisonMode === "B_C" || comparisonMode === "A_C" || comparisonMode === "A_B_C";

  // Calculate dynamic colspan for the empty row
  let colSpanCount = 2; // VC_NUMBER + STATUS
  if (showA) colSpanCount += 2; // Products + Extras
  if (showB) colSpanCount += 2;
  if (showC) colSpanCount += 2;

  // 1. Filter, sort, and paginate using our optimized global validation cache
  const { records: paginatedRecords, totalRecords, activePage } = useMemo(() => {
    const { records: displayRecords, totalFiltered } = queryValidationRecords({
      searchTerm,
      statusFilter,
      comparisonMode,
      sortField,
      sortOrder,
      page: currentPage,
      pageSize,
      casFilter: selectedCasFilter,
      cardToCasMap,
      uploadedCasNames,
    });

    const pages = Math.ceil(totalFiltered / pageSize) || 1;
    const guardedPage = Math.min(Math.max(1, currentPage), pages);

    return {
      records: displayRecords,
      totalRecords: totalFiltered,
      activePage: guardedPage,
    };
  }, [searchTerm, statusFilter, comparisonMode, sortField, sortOrder, currentPage, pageSize, selectedCasFilter, cardToCasMap, uploadedCasNames]);

  const totalPages = Math.ceil(totalRecords / pageSize) || 1;
  const startRecordIdx = totalRecords === 0 ? 0 : (activePage - 1) * pageSize + 1;
  const endRecordIdx = Math.min(activePage * pageSize, totalRecords);

  // Available filters depending on roles present
  const filtersToRender: FilterStatus[] = ["ALL", "MATCH", "MISMATCH"];
  if (showA) filtersToRender.push("ONLY_A");
  if (showB) filtersToRender.push("ONLY_B");
  if (showC) filtersToRender.push("ONLY_C");

  return (
    <div className="bg-slate-900/40 backdrop-blur-md rounded-2xl border border-slate-700/80 shadow-xl overflow-hidden flex flex-col h-full lg:flex-1 min-h-0">
      
      {/* Search, Filter Toolbar & Export Buttons */}
      <div className="p-4 border-b border-slate-800/60 space-y-3.5 shrink-0">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex flex-col md:flex-row md:items-start lg:items-center gap-3 lg:gap-6 flex-1">
            <div>
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <span>Validation Results</span>
                <span className="text-[10px] uppercase font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/30 px-2 py-0.5 rounded-full">
                  Mode: {comparisonMode === "A_C" ? "C vs S" : comparisonMode === "A_B_C" ? "C vs B vs S" : comparisonMode === "A_B" ? "C vs B" : "B vs S"}
                </span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Live interactive sheet matching and highlighting key product differences.
              </p>
            </div>

            {/* Maked Area CAS Dropdown */}
            {uniqueCasList.length > 0 && (
              <div className="flex items-center gap-2.5 bg-slate-950/40 px-3.5 py-1.5 rounded-xl border border-slate-800/60 shrink-0">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 select-none">
                  CAS Filter:
                </span>
                <div className="relative">
                  <select
                    id="validation-cas-filter"
                    value={selectedCasFilter}
                    onChange={(e) => handleCasChange(e.target.value)}
                    className="appearance-none bg-slate-900 hover:bg-slate-850 border border-slate-750 text-slate-200 rounded-lg pl-3 pr-8 py-1 text-[11px] focus:outline-none focus:border-indigo-500/80 cursor-pointer font-bold select-none h-[28px] transition"
                  >
                    <option value="ALL">All CAS Systems</option>
                    {uniqueCasList.map(casName => (
                      <option key={casName} value={casName}>{casName}</option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-400">
                    <svg className="fill-current h-3.5 w-3.5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                      <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                    </svg>
                  </div>
                </div>
              </div>
            )}

            {/* Zero Product Checkbox */}
            <label className="flex items-center gap-2 bg-slate-950/40 hover:bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800/60 shrink-0 text-xs font-bold text-amber-300 cursor-pointer transition select-none h-[38px] my-auto">
              <input
                type="checkbox"
                id="validation-zero-product-checkbox"
                checked={ignoreZeroProductEnabled}
                onChange={(e) => onIgnoreZeroProductToggle && onIgnoreZeroProductToggle(e.target.checked)}
                className="accent-amber-500 rounded cursor-pointer w-3.5 h-3.5 bg-slate-900 border border-slate-700"
              />
              <span className="whitespace-nowrap">Exclude '0' Product</span>
            </label>
          </div>
          <div className="relative">
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-750 text-white font-semibold rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-emerald-950/20 hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer select-none"
            >
              <ExternalLink size={14} />
              <span>EXPORT DATA</span>
              <span className="text-[9px] opacity-75">▼</span>
            </button>
            
            {showExportMenu && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowExportMenu(false)}
                />
                <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                  
                  {/* High Performance Selector */}
                  <div className="px-3 py-2.5 bg-slate-950/60 rounded-xl border border-slate-800 mb-3">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-[10.5px] font-bold text-slate-300">Format Option</span>
                      <span className="text-[9.5px] font-semibold text-slate-400">
                        {exportFormat === "CSV" ? "⚡️ Direct CSV / ZIP (10L+)" : "📊 Multi-Sheet (10L sheets)"}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
                      <button
                        onClick={() => setExportFormat("CSV")}
                        className={`py-1.5 rounded-md text-[10px] font-bold tracking-wide transition-all cursor-pointer select-none ${
                          exportFormat === "CSV"
                            ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/45"
                            : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/10"
                        }`}
                      >
                        CSV (Auto-ZIP)
                      </button>
                      <button
                        onClick={() => setExportFormat("EXCEL")}
                        className={`py-1.5 rounded-md text-[10px] font-bold tracking-wide transition-all cursor-pointer select-none ${
                          exportFormat === "EXCEL"
                            ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/45"
                            : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/10"
                        }`}
                      >
                        Excel (Multi-Sheet)
                      </button>
                    </div>
                    <div className="mt-2 text-[9px] text-slate-400 leading-normal text-center">
                      {exportFormat === "CSV" ? (
                        <span>Single file downloads as direct CSV. When dataset exceeds 1,000,000 rows (10 Lakhs), parts are automatically packaged into a single ZIP file.</span>
                      ) : (
                        <span>Will download a single Excel workbook containing multiple sheets of 1,000,000 rows (10 Lakhs) each, matching Excel grid limit.</span>
                      )}
                    </div>
                  </div>

                  {/* Active CAS Target Indicator */}
                  <div className="px-3 py-1.5 bg-slate-950/80 rounded-lg border border-slate-800 flex items-center justify-between text-[11px] mb-2 font-medium">
                    <span className="text-slate-400">Target CAS:</span>
                    <span className="font-bold text-indigo-400 truncate max-w-[140px]" title={selectedCasFilter === "ALL" ? "All CAS Systems" : selectedCasFilter}>
                      {selectedCasFilter === "ALL" ? "All CAS Systems" : selectedCasFilter}
                    </span>
                  </div>

                  <div className="px-3 py-1.5 border-b border-slate-800/80 mb-1.5 flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                      Validation Matrices
                    </span>
                    {selectedCasFilter !== "ALL" && (
                      <span className="text-[9px] px-1.5 py-0.2 bg-indigo-500/20 text-indigo-300 rounded font-semibold">
                        Filtered
                      </span>
                    )}
                  </div>
                  <div className="space-y-1">
                    <button
                      onClick={() => {
                        onDownloadExcel("ALL", exportFormat, selectedCasFilter);
                        setShowExportMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 bg-slate-850 hover:bg-slate-80 border border-transparent hover:border-slate-705 text-slate-200 hover:text-white rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                    >
                      <div className="flex flex-col">
                        <span className="font-semibold">ALL DATA ({selectedCasFilter === "ALL" ? "Complete matrix" : selectedCasFilter})</span>
                        <span className="text-[10px] text-slate-500">
                          Export as .{exportFormat.toLowerCase()} structure
                        </span>
                      </div>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 bg-slate-800 rounded font-bold text-slate-400">
                        {exportFormat === "EXCEL" && (summaryStats?.totalKeys ?? 0) > 100000 
                          ? "100k" 
                          : (summaryStats?.totalKeys ?? 0)}
                      </span>
                    </button>

                    <button
                      onClick={() => {
                        onDownloadExcel("MATCH", exportFormat, selectedCasFilter);
                        setShowExportMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 bg-emerald-600/5 hover:bg-emerald-600/15 border border-transparent hover:border-emerald-500/25 text-emerald-300 hover:text-emerald-200 rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                    >
                      <div className="flex flex-col">
                        <span className="font-semibold">MATCH Only</span>
                        <span className="text-[10px] text-emerald-500/80 font-normal">
                          Export matching as .{exportFormat.toLowerCase()}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 bg-emerald-500/10 rounded font-bold text-emerald-400">
                        {exportFormat === "EXCEL" && (summaryStats?.matchCount ?? 0) > 100000 
                          ? "100k" 
                          : (summaryStats?.matchCount ?? 0)}
                      </span>
                    </button>

                    <button
                      onClick={() => {
                        onDownloadExcel("MISMATCH", exportFormat, selectedCasFilter);
                        setShowExportMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 bg-rose-600/5 hover:bg-rose-600/15 border border-transparent hover:border-rose-500/25 text-rose-300 hover:text-rose-200 rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                    >
                      <div className="flex flex-col">
                        <span className="font-semibold">MISMATCH Only</span>
                        <span className="text-[10px] text-rose-500/80 font-normal font-sans">
                          Export mismatches as .{exportFormat.toLowerCase()}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 bg-rose-500/10 rounded font-bold text-rose-400">
                        {exportFormat === "EXCEL" && (summaryStats?.mismatchCount ?? 0) > 100000 
                          ? "100k" 
                          : (summaryStats?.mismatchCount ?? 0)}
                      </span>
                    </button>
                  </div>

                  {/* Presence Subsets (Single System Only) */}
                  {(showA || showB || showC) && (
                    <>
                      <div className="px-3 py-1.5 border-t border-b border-slate-800/80 my-2">
                        <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                          Presence Subsets
                        </span>
                      </div>
                      <div className="space-y-1">
                        {showA && (
                          <button
                            onClick={() => {
                              onDownloadExcel("ONLY_A", exportFormat, selectedCasFilter);
                              setShowExportMenu(false);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-emerald-500/10 text-emerald-300 hover:text-emerald-200 rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                          >
                            <div className="flex items-center space-x-2">
                              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              <span className="font-medium text-[11px]">In CAS(C) Only</span>
                            </div>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 bg-emerald-500/10 rounded font-bold text-emerald-400">
                              {summaryStats?.onlyInA ?? 0}
                            </span>
                          </button>
                        )}
                        {showB && (
                          <button
                            onClick={() => {
                              onDownloadExcel("ONLY_B", exportFormat, selectedCasFilter);
                              setShowExportMenu(false);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-sky-500/10 text-sky-300 hover:text-sky-200 rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                          >
                            <div className="flex items-center space-x-2">
                              <div className="w-1.5 h-1.5 rounded-full bg-sky-500" />
                              <span className="font-medium text-[11px]">In SMS(B) Only</span>
                            </div>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 bg-sky-500/10 rounded font-bold text-sky-400">
                              {summaryStats?.onlyInB ?? 0}
                            </span>
                          </button>
                        )}
                        {showC && (
                          <button
                            onClick={() => {
                              onDownloadExcel("ONLY_C", exportFormat, selectedCasFilter);
                              setShowExportMenu(false);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-violet-500/10 text-violet-300 hover:text-violet-200 rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                          >
                            <div className="flex items-center space-x-2">
                              <div className="w-1.5 h-1.5 rounded-full bg-violet-500" />
                              <span className="font-medium text-[11px]">In SMS(S) Only</span>
                            </div>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 bg-violet-500/10 rounded font-bold text-violet-400">
                              {summaryStats?.onlyInC ?? 0}
                            </span>
                          </button>
                        )}
                      </div>
                    </>
                  )}

                  <div className="px-3 py-1.5 border-t border-b border-slate-800/80 my-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                      Separate Spreadsheet Sources
                    </span>
                  </div>

                  <div className="grid grid-cols-1 gap-1">
                    {showA && (
                      <button
                        onClick={() => {
                          onDownloadExcel("A_DATA", exportFormat, selectedCasFilter);
                          setShowExportMenu(false);
                        }}
                        className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                      >
                        <div className="flex items-center space-x-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          <span className="font-medium text-[11px]">CAS DATA (C Only)</span>
                        </div>
                        <span className="text-[9px] text-slate-500 font-medium">.{exportFormat.toLowerCase()}</span>
                      </button>
                    )}

                    {showB && (
                      <button
                        onClick={() => {
                          onDownloadExcel("B_DATA", exportFormat, selectedCasFilter);
                          setShowExportMenu(false);
                        }}
                        className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                      >
                        <div className="flex items-center space-x-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-sky-500" />
                          <span className="font-medium text-[11px]">SMS DATA (B Only)</span>
                        </div>
                        <span className="text-[9px] text-slate-500 font-medium">.{exportFormat.toLowerCase()}</span>
                      </button>
                    )}

                    {showC && (
                      <button
                        onClick={() => {
                          onDownloadExcel("C_DATA", exportFormat, selectedCasFilter);
                          setShowExportMenu(false);
                        }}
                        className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg text-xs flex items-center justify-between transition cursor-pointer"
                      >
                        <div className="flex items-center space-x-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-violet-500" />
                          <span className="font-medium text-[11px]">SMS DATA (S Only)</span>
                        </div>
                        <span className="text-[9px] text-slate-500 font-medium">.{exportFormat.toLowerCase()}</span>
                      </button>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Inputs */}
        <div className="flex flex-col lg:flex-row gap-3 pt-2">
          {/* Searching input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-2.5 text-slate-500" size={16} />
            <input
              type="text"
              placeholder="Search by VC_NUMBER, product keys, extra products..."
              value={searchTerm}
              onChange={handleSearchChange}
              className="w-full pl-10 pr-4 py-2 text-xs bg-slate-800/50 hover:bg-slate-800 border border-slate-700/80 focus:border-indigo-550 rounded-xl focus:outline-none transition-all placeholder:text-slate-500 text-slate-100"
            />
          </div>

          {/* Filtering buttons */}
          <div className="flex flex-wrap gap-1.5 items-center">
            {filtersToRender.map((status) => {
              const isActive = statusFilter === status;
              const labels: Record<FilterStatus, string> = {
                ALL: "All",
                MATCH: "Matches",
                MISMATCH: "Mismatches",
                ONLY_A: "In CAS(C) Only",
                ONLY_B: "In SMS(B) Only",
                ONLY_C: "In SMS(S) Only",
              };

              const activeColors: Record<FilterStatus, string> = {
                ALL: "bg-slate-200 text-slate-950 border-white/10",
                MATCH: "bg-emerald-500/25 text-emerald-300 border-emerald-500/30",
                MISMATCH: "bg-rose-500/25 text-rose-300 border-rose-500/30",
                ONLY_A: "bg-emerald-500/10 text-emerald-300 border-emerald-500/15",
                ONLY_B: "bg-sky-500/10 text-sky-300 border-sky-500/15",
                ONLY_C: "bg-violet-500/10 text-violet-300 border-violet-500/15",
              };

              const inactiveColor = "bg-slate-800/40 hover:bg-slate-800 text-slate-400 border border-slate-700/80";

              return (
                <button
                  key={status}
                  onClick={() => handleStatusChange(status)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold transition border border-transparent cursor-pointer ${
                    isActive ? activeColors[status] : inactiveColor
                  }`}
                >
                  {labels[status]}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Grid table */}
      <div className="flex-1 min-h-[220px] lg:min-h-0 overflow-y-auto overflow-x-auto w-full scrollbar-thin scrollbar-thumb-slate-850 scrollbar-track-transparent relative">
        <table className="w-full border-collapse text-left text-xs text-slate-350">
          <thead className="sticky top-0 z-20 bg-[#0a101d] bg-opacity-95 shadow-[0_1px_0_0_rgba(51,65,85,0.5)]">
            <tr className="text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px] select-none font-bold">
              <th
                onClick={() => handleSort("key")}
                className="py-3 px-6 cursor-pointer hover:bg-slate-800/60 hover:text-slate-250 transition"
              >
                <div className="flex items-center space-x-1.5 font-mono">
                  <span>VC_NUMBER</span>
                  <ArrowUpDown size={11} className="text-slate-500" />
                </div>
              </th>
              
              {showA && <th className="py-3 px-4 text-slate-400 font-bold shrink-0">CAS_PRODUCTS (C)</th>}
              {showB && <th className="py-3 px-4 text-slate-400 font-bold shrink-0">SMS_PRODUCTS (B)</th>}
              {showC && <th className="py-3 px-4 text-slate-400 font-bold shrink-0">SMS_PRODUCTS (S)</th>}
              
              <th
                onClick={() => handleSort("status")}
                className="py-3 px-4 cursor-pointer hover:bg-slate-800/60 hover:text-slate-250 transition"
              >
                <div className="flex items-center space-x-1.5">
                  <span>STATUS</span>
                  <ArrowUpDown size={11} className="text-slate-500" />
                </div>
              </th>

              {showA && <th className="py-3 px-4 text-slate-450 font-semibold">CAS_EXTRA_PRODUCTS</th>}
              {showB && <th className="py-3 px-4 text-slate-450 font-semibold">SMS_EXTRA_PRODUCTS</th>}
              {showC && <th className="py-3 px-4 text-slate-450 font-semibold">SMS_EXTRA_PRODUCTS</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {paginatedRecords.length === 0 ? (
              <tr>
                <td colSpan={colSpanCount} className="py-12 text-center text-slate-500">
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <Info size={24} className="text-slate-600" />
                    <p className="text-sm font-semibold text-slate-400">No records found</p>
                    <p className="text-xs text-slate-500 max-w-sm leading-relaxed">
                      Try resetting filters, modifying search keywords, or adjusting your uploaded datasets.
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              paginatedRecords.map((rec, idx) => {
                const isMatch = rec.status === "MATCH";
                
                return (
                  <tr
                    key={`${rec.key}-${idx}`}
                    className={`hover:bg-slate-800/30 transition-colors ${
                      !isMatch ? "bg-rose-500/[0.02]" : ""
                    }`}
                  >
                    {/* VC_NUMBER */}
                    <td className="py-2 px-6 font-semibold text-slate-200 font-mono whitespace-nowrap">
                      {rec.key}
                    </td>

                    {/* A PRODUCTS */}
                    {showA && (
                      <td className="py-2 px-4 font-mono max-w-[180px] truncate text-slate-350 whitespace-nowrap" title={(rec.aProducts || []).join(", ")}>
                        {rec.aProducts && rec.aProducts.length > 0 ? (
                          <span>{rec.aProducts.join(", ")}</span>
                        ) : (
                          <span className="text-rose-400/80 italic text-[11px]">No products</span>
                        )}
                      </td>
                    )}

                    {/* B PRODUCTS */}
                    {showB && (
                      <td className="py-2 px-4 font-mono max-w-[180px] truncate text-slate-350 whitespace-nowrap" title={(rec.bProducts || []).join(", ")}>
                        {rec.bProducts && rec.bProducts.length > 0 ? (
                          <span>{rec.bProducts.join(", ")}</span>
                        ) : (
                          <span className="text-rose-400/80 italic text-[11px]">No products</span>
                        )}
                      </td>
                    )}

                    {/* C PRODUCTS */}
                    {showC && (
                      <td className="py-2 px-4 font-mono max-w-[180px] truncate text-slate-350 whitespace-nowrap" title={(rec.cProducts || []).join(", ")}>
                        {rec.cProducts && rec.cProducts.length > 0 ? (
                          <span>{rec.cProducts.join(", ")}</span>
                        ) : (
                          <span className="text-rose-400/80 italic text-[11px]">No products</span>
                        )}
                      </td>
                    )}

                    {/* STATUS */}
                    <td className="py-2 px-4 whitespace-nowrap">
                      {isMatch ? (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          <CheckCircle2 size={11} />
                          <span>MATCH</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                          <XCircle size={11} />
                          <span>MISMATCH</span>
                        </span>
                      )}
                    </td>

                    {/* EXTRA IN A */}
                    {showA && (
                      <td className="py-2 px-4 whitespace-nowrap">
                        {rec.aExtra && rec.aExtra.length > 0 ? (
                          <span className="inline-block px-2 py-0.5 rounded font-mono text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 overflow-hidden max-w-[160px] truncate" title={rec.aExtra.join(",")}>
                            {rec.aExtra.join(", ")}
                          </span>
                        ) : (
                          <span className="text-slate-600 font-mono">—</span>
                        )}
                      </td>
                    )}

                    {/* EXTRA IN B */}
                    {showB && (
                      <td className="py-2 px-4 whitespace-nowrap">
                        {rec.bExtra && rec.bExtra.length > 0 ? (
                          <span className="inline-block px-2 py-0.5 rounded font-mono text-sky-300 bg-sky-500/10 border border-sky-500/20 overflow-hidden max-w-[160px] truncate" title={rec.bExtra.join(",")}>
                            {rec.bExtra.join(", ")}
                          </span>
                        ) : (
                          <span className="text-slate-600 font-mono">—</span>
                        )}
                      </td>
                    )}

                    {/* EXTRA IN C */}
                    {showC && (
                      <td className="py-2 px-4 whitespace-nowrap">
                        {rec.cExtra && rec.cExtra.length > 0 ? (
                          <span className="inline-block px-2 py-0.5 rounded font-mono text-violet-350 bg-violet-500/10 border border-violet-500/20 overflow-hidden max-w-[160px] truncate" title={rec.cExtra.join(",")}>
                            {rec.cExtra.join(", ")}
                          </span>
                        ) : (
                          <span className="text-slate-600 font-mono">—</span>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination controls */}
      {totalRecords > 0 && (
        <div className="p-3 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs bg-slate-900/40 text-slate-400 shrink-0">
          <div className="flex items-center space-x-2">
            <span>Show:</span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(parseInt(e.target.value, 10));
                setCurrentPage(1);
              }}
              className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-slate-200 focus:outline-indigo-550 focus:bg-slate-950 font-sans cursor-pointer"
            >
              {[15, 30, 50, 100].map((size) => (
                <option key={size} value={size}>
                  {size} rows
                </option>
              ))}
            </select>
            <span>
              of <strong className="font-semibold text-slate-200">{totalRecords}</strong> records
              {searchTerm && <span className="text-slate-500"> (filtered)</span>}
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-slate-400">
              Page <strong className="font-semibold text-slate-200">{activePage}</strong> of {totalPages}
            </span>

            <div className="flex items-center space-x-1">
              {/* First */}
              <button
                disabled={activePage === 1}
                onClick={() => setCurrentPage(1)}
                className="p-1.5 rounded-lg border border-slate-700 bg-slate-800/20 hover:bg-slate-800 text-slate-200 disabled:opacity-20 disabled:hover:bg-transparent cursor-pointer disabled:cursor-not-allowed"
                title="First Page"
              >
                <ChevronsLeft size={14} />
              </button>
              {/* Previous */}
              <button
                disabled={activePage === 1}
                onClick={() => setCurrentPage(activePage - 1)}
                className="p-1.5 rounded-lg border border-slate-700 bg-slate-800/20 hover:bg-slate-800 text-slate-200 disabled:opacity-20 disabled:hover:bg-transparent cursor-pointer disabled:cursor-not-allowed"
                title="Previous"
              >
                <ChevronLeft size={14} />
              </button>
              {/* Next */}
              <button
                disabled={activePage === totalPages}
                onClick={() => setCurrentPage(activePage + 1)}
                className="p-1.5 rounded-lg border border-slate-700 bg-slate-800/20 hover:bg-slate-800 text-slate-200 disabled:opacity-20 disabled:hover:bg-transparent cursor-pointer disabled:cursor-not-allowed"
                title="Next"
              >
                <ChevronRight size={14} />
              </button>
              {/* Last */}
              <button
                disabled={activePage === totalPages}
                onClick={() => setCurrentPage(totalPages)}
                className="p-1.5 rounded-lg border border-slate-700 bg-slate-800/20 hover:bg-slate-800 text-slate-200 disabled:opacity-20 disabled:hover:bg-transparent cursor-pointer disabled:cursor-not-allowed"
                title="Last Page"
              >
                <ChevronsRight size={14} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
