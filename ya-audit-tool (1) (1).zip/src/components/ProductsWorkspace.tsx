import React, { useState, useRef, useMemo, useEffect, useCallback } from "react";
import { createPortal } from "react-dom";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { 
  Upload, 
  FileSpreadsheet, 
  Trash2, 
  Settings, 
  CheckCircle2, 
  AlertTriangle, 
  Database, 
  ShoppingBag, 
  Search, 
  ChevronDown, 
  ChevronUp, 
  Download, 
  RefreshCw, 
  RotateCcw,
  Sliders, 
  Check, 
  FileCheck2,
  FileCheck,
  ListFilter,
  Eye,
  Info,
  X,
  ChevronsLeft,
  ChevronsRight,
  ChevronLeft,
  ChevronRight,
  XCircle,
  PieChart,
  Layers
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { MasterProduct, MasterMapping, SheetState, UploadedFile, IgnoreDigitRule } from "../types";
import { parseExcelMultiSheet, parseMasterProductFileAsync } from "../utils/parser";
import { loadStoredReferenceFiles } from "../utils/referenceStorage";
import { getSheetUniqueCasNames } from "../utils/casNames";

// Module-level cache to keep large files in memory during tab-switching and prevent localStorage quota errors
interface InMemoryMasterCache {
  rows: any[];
  name: string;
  size: number;
  cols: string[];
}
let globalProductsMasterCache: InMemoryMasterCache | null = null;
let globalProductsFilesCache: UploadedFile[] = [];
let globalProductsSheetsCache: SheetState[] = [];
let globalProductsContinuitySheetsCache: boolean = false;
let globalProductsUploadPanelCollapsedCache: boolean = false;
let globalProductsLogicPanelCollapsedCache: boolean = false;
let globalReportRecordsCache: any[] = [];
let globalIsReportGeneratedCache: boolean = false;
let globalActiveSubTabCache: "REPORT" | "SUMMARY" = "REPORT";
let globalSelectedCasCache: string = "ALL";
let globalUseUniqueOnlyCache: boolean = true;
let globalBothNoValueCache: boolean = true;

interface CasWiseCategoryBoxProps {
  title: string;
  badgeCount: number;
  badgeBg: string;
  badgeText: string;
  borderColor: string;
  icon: React.ReactNode;
  products: Array<{ productId: string; productName: string; casCount: number; appCount: number; broadcaster: string }>;
  type: "matched" | "casUnique" | "smsUnique" | "casOnly" | "smsOnly";
}

const CasWiseCategoryBox: React.FC<CasWiseCategoryBoxProps> = ({
  title,
  badgeCount,
  badgeBg,
  badgeText,
  borderColor,
  icon,
  products,
  type
}) => {
  const [catSearch, setCatSearch] = useState("");
  const [isExpanded, setIsExpanded] = useState(true);

  const filteredProducts = useMemo(() => {
    if (!catSearch.trim()) return products;
    const term = catSearch.toLowerCase().trim();
    return products.filter(p =>
      p.productId.toLowerCase().includes(term) ||
      p.productName.toLowerCase().includes(term) ||
      p.broadcaster.toLowerCase().includes(term)
    );
  }, [products, catSearch]);

  return (
    <div className={`bg-slate-950/80 border ${borderColor} rounded-2xl p-3.5 flex flex-col h-full min-h-[240px] shadow-lg`}>
      {/* Category Header */}
      <div className="flex items-center justify-between pb-2.5 border-b border-slate-800/80 mb-2.5">
        <div className="flex items-center space-x-2 min-w-0">
          <div className="shrink-0">{icon}</div>
          <h4 className="text-xs font-extrabold text-slate-100 truncate">{title}</h4>
        </div>
        <div className="flex items-center space-x-1.5 shrink-0">
          <span className={`px-2 py-0.5 text-[10px] font-black rounded-lg ${badgeBg} ${badgeText} border border-current/20 font-mono`}>
            {badgeCount} Prods
          </span>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 text-slate-500 hover:text-slate-300 rounded hover:bg-slate-800/60 transition cursor-pointer"
            title={isExpanded ? "Collapse" : "Expand"}
          >
            {isExpanded ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="flex-1 flex flex-col space-y-2 min-h-0">
          {/* Quick Filter Input if products > 3 */}
          {products.length > 3 && (
            <div className="relative shrink-0">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-600" size={10} />
              <input
                type="text"
                value={catSearch}
                onChange={e => setCatSearch(e.target.value)}
                placeholder="Filter category products..."
                className="w-full bg-slate-900 border border-slate-800 text-slate-300 placeholder-slate-600 rounded-lg pl-7 pr-2 py-1 text-[10px] focus:outline-none focus:border-indigo-500"
              />
            </div>
          )}

          {/* Scrollable Product List */}
          <div className="flex-1 overflow-y-auto max-h-72 pr-1 space-y-1.5 font-mono text-[11px]">
            {filteredProducts.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-[11px] italic">
                {products.length === 0 ? "No products in this category" : "No matching products found"}
              </div>
            ) : (
              filteredProducts.map((p, idx) => (
                <div
                  key={`${p.productId}-${idx}`}
                  className="p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800/80 transition flex flex-col space-y-1"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-extrabold text-indigo-300 break-all select-all font-mono">
                      {p.productId}
                    </span>
                    <div className="text-[10px] font-mono shrink-0 font-bold">
                      {type === "matched" && (
                        <span className="text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/40">
                          C: {p.casCount} | S: {p.appCount}
                        </span>
                      )}
                      {type === "casUnique" && (
                        <span className="text-teal-400 bg-teal-950/60 px-1.5 py-0.5 rounded border border-teal-800/40">
                          C: {p.casCount}
                        </span>
                      )}
                      {type === "smsUnique" && (
                        <span className="text-violet-400 bg-violet-950/60 px-1.5 py-0.5 rounded border border-violet-800/40">
                          S: {p.appCount}
                        </span>
                      )}
                      {type === "casOnly" && (
                        <span className="text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/40">
                          C: {p.casCount}
                        </span>
                      )}
                      {type === "smsOnly" && (
                        <span className="text-rose-400 bg-rose-950/60 px-1.5 py-0.5 rounded border border-rose-800/40">
                          S: {p.appCount}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-[11px] text-slate-200 font-sans font-semibold line-clamp-2">
                    {p.productName}
                  </div>
                  {p.broadcaster && p.broadcaster !== "Other / Unmapped" && (
                    <div className="text-[9.5px] text-slate-400 font-sans italic flex items-center justify-between">
                      <span>{p.broadcaster}</span>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export interface ProductsWorkspaceProps {
  files?: UploadedFile[];
  setFiles?: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  sheets?: SheetState[];
  setSheets?: React.Dispatch<React.SetStateAction<SheetState[]>>;
  continuitySheets?: boolean;
  setContinuitySheets?: React.Dispatch<React.SetStateAction<boolean>>;
  globalReferenceEnabled?: boolean;
  setGlobalReferenceEnabled?: React.Dispatch<React.SetStateAction<boolean>>;
  globalReferenceMappings?: any[];
  setGlobalReferenceMappings?: React.Dispatch<React.SetStateAction<any[]>>;
  ignoreDigitEnabled?: boolean;
  setIgnoreDigitEnabled?: (val: boolean) => void;
  ignoreDigitRules?: IgnoreDigitRule[];
  setIgnoreDigitRules?: (val: IgnoreDigitRule[]) => void;
  ignoreZeroProductEnabled?: boolean;
  setIgnoreZeroProductEnabled?: (val: boolean) => void;
  onNavigateToTab?: (tab: "DATA_UPLOAD" | "ACTIVE_COUNT" | "PRODUCTS" | "PRODUCT_MASTER" | "WORKSPACE" | "SETTINGS") => void;
}

export default function ProductsWorkspace({
  files: propFiles,
  setFiles: propSetFiles,
  sheets: propSheets,
  setSheets: propSetSheets,
  continuitySheets: propContinuitySheets,
  setContinuitySheets: propSetContinuitySheets,
  globalReferenceEnabled: propGlobalReferenceEnabled,
  setGlobalReferenceEnabled: propSetGlobalReferenceEnabled,
  globalReferenceMappings: propGlobalReferenceMappings,
  setGlobalReferenceMappings: propSetGlobalReferenceMappings,
  ignoreDigitEnabled: propIgnoreDigitEnabled,
  setIgnoreDigitEnabled: propSetIgnoreDigitEnabled,
  ignoreDigitRules: propIgnoreDigitRules,
  setIgnoreDigitRules: propSetIgnoreDigitRules,
  ignoreZeroProductEnabled: propIgnoreZeroProductEnabled,
  setIgnoreZeroProductEnabled: propSetIgnoreZeroProductEnabled,
  onNavigateToTab,
}: ProductsWorkspaceProps = {}) {
  // Sub-tabs within Products workspace
  const [activeSubTab, setActiveSubTab] = useState<"REPORT" | "SUMMARY">(
    () => (globalActiveSubTabCache === "REPORT" || globalActiveSubTabCache === "SUMMARY") ? globalActiveSubTabCache : "REPORT"
  );

  // Sync activeSubTab to global cache
  useEffect(() => {
    globalActiveSubTabCache = activeSubTab;
  }, [activeSubTab]);

  // --- STEP 1: MASTER DATA STATE ---

  const [useUniqueOnly, setUseUniqueOnly] = useState<boolean>(
    () => globalUseUniqueOnlyCache
  );

  useEffect(() => {
    globalUseUniqueOnlyCache = useUniqueOnly;
  }, [useUniqueOnly]);

  const [bothNoValue, setBothNoValue] = useState<boolean>(
    () => globalBothNoValueCache
  );

  useEffect(() => {
    globalBothNoValueCache = bothNoValue;
  }, [bothNoValue]);

  const [internalIgnoreZeroProductEnabled, setInternalIgnoreZeroProductEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("ya_ignore_zero_product_enabled");
    return saved !== "false";
  });

  const ignoreZeroProductEnabled = propIgnoreZeroProductEnabled !== undefined ? propIgnoreZeroProductEnabled : internalIgnoreZeroProductEnabled;
  const setIgnoreZeroProductEnabled = (val: boolean) => {
    if (propSetIgnoreZeroProductEnabled) propSetIgnoreZeroProductEnabled(val);
    else setInternalIgnoreZeroProductEnabled(val);
  };

  useEffect(() => {
    localStorage.setItem("ya_ignore_zero_product_enabled", ignoreZeroProductEnabled ? "true" : "false");
  }, [ignoreZeroProductEnabled]);

  const [printData, setPrintData] = useState<{ broadcasterName: string; list: any[] } | null>(null);
  const [masterFileName, setMasterFileName] = useState<string>("");
  const [masterFileSize, setMasterFileSize] = useState<number>(0);
  const [masterColumns, setMasterColumns] = useState<string[]>([]);
  const [masterRawRows, setMasterRawRows] = useState<any[]>([]);
  const [masterMapping, setMasterMapping] = useState<MasterMapping>(() => {
    const saved = localStorage.getItem("products_master_mapping");
    return saved ? JSON.parse(saved) : {
      productIdCol: "",
      productNameCol: "",
      casCol: "",
      broadcasterCol: ""
    };
  });
  const [isMasterMappingSaved, setIsMasterMappingSaved] = useState<boolean>(false);
  const [isMasterDragging, setIsMasterDragging] = useState<boolean>(false);
  const [masterSearch, setMasterSearch] = useState<string>("");
  const [isMasterParsing, setIsMasterParsing] = useState<boolean>(false);
  const [masterParseProgress, setMasterParseProgress] = useState<{ stage: string; percent: number } | null>(null);

  const fileInputMasterRef = useRef<HTMLInputElement>(null);

  // Load master data from localStorage or in-memory global cache if exists to persist across views
  useEffect(() => {
    if (globalProductsMasterCache) {
      setMasterRawRows(globalProductsMasterCache.rows);
      setMasterFileName(globalProductsMasterCache.name);
      setMasterFileSize(globalProductsMasterCache.size);
      setMasterColumns(globalProductsMasterCache.cols);
      setIsMasterMappingSaved(true);
      return;
    }

    const savedRows = localStorage.getItem("products_master_rows");
    const savedName = localStorage.getItem("products_master_name");
    const savedSize = localStorage.getItem("products_master_size");
    const savedCols = localStorage.getItem("products_master_cols");

    if (savedRows && savedName) {
      try {
        const rows = JSON.parse(savedRows);
        const cols = JSON.parse(savedCols || "[]");
        const size = parseInt(savedSize || "0", 10);
        
        setMasterRawRows(rows);
        setMasterFileName(savedName);
        setMasterFileSize(size);
        setMasterColumns(cols);
        setIsMasterMappingSaved(true);

        // Seed global cache
        globalProductsMasterCache = {
          rows,
          name: savedName,
          size,
          cols
        };
      } catch (e) {
        console.error("Failed to restore master data from cache", e);
      }
    }
  }, []);

  // Listen for live updates from PRODUCT MASTER DATA workspace tab
  useEffect(() => {
    const handleMasterUpdate = () => {
      const savedRows = localStorage.getItem("products_master_rows");
      const savedName = localStorage.getItem("products_master_name");
      const savedSize = localStorage.getItem("products_master_size");
      const savedCols = localStorage.getItem("products_master_cols");
      const savedMapping = localStorage.getItem("products_master_mapping");

      if (savedRows && savedName) {
        try {
          const rows = JSON.parse(savedRows);
          const cols = JSON.parse(savedCols || "[]");
          const size = parseInt(savedSize || "0", 10);
          setMasterRawRows(rows);
          setMasterFileName(savedName);
          setMasterFileSize(size);
          setMasterColumns(cols);
          setIsMasterMappingSaved(true);
        } catch (e) {
          console.error("Failed to load updated master data:", e);
        }
      } else {
        setMasterRawRows([]);
        setMasterFileName("");
        setMasterFileSize(0);
        setMasterColumns([]);
        setIsMasterMappingSaved(false);
      }

      if (savedMapping) {
        try {
          setMasterMapping(JSON.parse(savedMapping));
        } catch (e) {}
      }
    };

    window.addEventListener("products_master_updated", handleMasterUpdate);
    return () => window.removeEventListener("products_master_updated", handleMasterUpdate);
  }, []);

  // Save mapping selection to local storage on change
  useEffect(() => {
    try {
      localStorage.setItem("products_master_mapping", JSON.stringify(masterMapping));
    } catch (e) {
      console.error(e);
    }
  }, [masterMapping]);

  // Derive mapped master products
  const masterProducts = useMemo<MasterProduct[]>(() => {
    if (!masterMapping.productIdCol || masterRawRows.length === 0) return [];

    return masterRawRows.map((row, index) => {
      // Ignore single quotes (') in Product ID and Product Names
      const id = String(row[masterMapping.productIdCol] || "").trim().replace(/'/g, "");
      const name = masterMapping.productNameCol 
        ? String(row[masterMapping.productNameCol] || "").trim().replace(/'/g, "") 
        : "N/A";
      const cas = masterMapping.casCol ? String(row[masterMapping.casCol] || "").trim() : "N/A";
      const broadcaster = masterMapping.broadcasterCol ? String(row[masterMapping.broadcasterCol] || "").trim() : "Other / Unmapped";

      return {
        id,
        name: name || `Product ${id}`,
        cas: cas || "N/A",
        broadcaster: broadcaster || "Other / Unmapped"
      };
    }).filter(p => p.id !== "");
  }, [masterRawRows, masterMapping]);

  // Handle Master Data file upload
  const handleMasterFileSelect = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    setMasterFileName(file.name);
    setMasterFileSize(file.size);
    setIsMasterParsing(true);
    setMasterParseProgress({ stage: "Opening master product catalog...", percent: 5 });

    try {
      const { columns, rows, suggestedMapping } = await parseMasterProductFileAsync(file, (stage, percent) => {
        setMasterParseProgress({ stage, percent });
      });

      setMasterColumns(columns);
      setMasterRawRows(rows);
      setMasterMapping(suggestedMapping);
      setIsMasterMappingSaved(false); // require save confirmation

      // Cache in memory
      globalProductsMasterCache = {
        rows,
        name: file.name,
        size: file.size,
        cols: columns
      };

      // Attempt cache in localStorage with graceful QuotaExceeded fallback protection
      try {
        localStorage.setItem("products_master_rows", JSON.stringify(rows));
        localStorage.setItem("products_master_name", file.name);
        localStorage.setItem("products_master_size", String(file.size));
        localStorage.setItem("products_master_cols", JSON.stringify(columns));
      } catch (storageError) {
        console.warn("Local storage quota exceeded. Master product rows cached in-memory only.", storageError);
        try {
          localStorage.removeItem("products_master_rows");
        } catch (e) {}
      }
    } catch (err) {
      console.error(err);
      alert("Failed to parse master data sheet: " + String(err));
    } finally {
      setIsMasterParsing(false);
      setMasterParseProgress(null);
    }
  };

  const handleSaveMasterMapping = () => {
    if (!masterMapping.productIdCol) {
      alert("Product ID Column is required for mapping!");
      return;
    }
    setIsMasterMappingSaved(true);
    setActiveSubTab("REPORT");
  };

  const handleClearMaster = () => {
    setMasterFileName("");
    setMasterFileSize(0);
    setMasterColumns([]);
    setMasterRawRows([]);
    setMasterMapping({
      productIdCol: "",
      productNameCol: "",
      casCol: "",
      broadcasterCol: ""
    });
    setIsMasterMappingSaved(false);

    // Clear memory-level cache too
    globalProductsMasterCache = null;

    try {
      localStorage.removeItem("products_master_rows");
      localStorage.removeItem("products_master_name");
      localStorage.removeItem("products_master_size");
      localStorage.removeItem("products_master_cols");
    } catch (e) {}
  };


  // --- STEP 2: TRANSACTION FILES (CAS & APP) STATE ---
  const [internalFiles, setInternalFiles] = useState<UploadedFile[]>(
    () => globalProductsFilesCache
  );
  const files = propFiles !== undefined ? propFiles : internalFiles;
  const setFiles = propSetFiles !== undefined ? propSetFiles : setInternalFiles;

  const [internalSheets, setInternalSheets] = useState<SheetState[]>(
    () => globalProductsSheetsCache
  );
  const sheets = propSheets !== undefined ? propSheets : internalSheets;
  const setSheets = propSetSheets !== undefined ? propSetSheets : setInternalSheets;

  const [internalContinuitySheets, setInternalContinuitySheets] = useState<boolean>(
    () => globalProductsContinuitySheetsCache
  );
  const continuitySheets = propContinuitySheets !== undefined ? propContinuitySheets : internalContinuitySheets;
  const setContinuitySheets = propSetContinuitySheets !== undefined ? propSetContinuitySheets : setInternalContinuitySheets;

  const [isUploadPanelCollapsed, setIsUploadPanelCollapsed] = useState<boolean>(
    () => globalProductsUploadPanelCollapsedCache
  );
  const [isLogicPanelCollapsed, setIsLogicPanelCollapsed] = useState<boolean>(
    () => globalProductsLogicPanelCollapsedCache
  );

  const [internalGlobalReferenceEnabled, setInternalGlobalReferenceEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("products_global_reference_enabled");
    return saved === "true";
  });
  const globalReferenceEnabled = propGlobalReferenceEnabled !== undefined ? propGlobalReferenceEnabled : internalGlobalReferenceEnabled;
  const setGlobalReferenceEnabled = propSetGlobalReferenceEnabled !== undefined ? propSetGlobalReferenceEnabled : setInternalGlobalReferenceEnabled;

  const [internalGlobalReferenceMappings, setInternalGlobalReferenceMappings] = useState<any[]>(() => {
    const saved = localStorage.getItem("products_global_reference_mappings");
    return saved ? JSON.parse(saved) : [{ id: "init-prod", referenceFileId: "", casName: "" }];
  });
  const globalReferenceMappings = propGlobalReferenceMappings !== undefined ? propGlobalReferenceMappings : internalGlobalReferenceMappings;
  const setGlobalReferenceMappings = propSetGlobalReferenceMappings !== undefined ? propSetGlobalReferenceMappings : setInternalGlobalReferenceMappings;

  useEffect(() => {
    localStorage.setItem("products_global_reference_enabled", String(globalReferenceEnabled));
  }, [globalReferenceEnabled]);

  useEffect(() => {
    localStorage.setItem("products_global_reference_mappings", JSON.stringify(globalReferenceMappings));
  }, [globalReferenceMappings]);

  const [internalIgnoreDigitEnabled, setInternalIgnoreDigitEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("products_ignore_digit_enabled") 
      || localStorage.getItem("ya_ignore_digit_enabled");
    return saved === "true";
  });
  const ignoreDigitEnabled = propIgnoreDigitEnabled !== undefined ? propIgnoreDigitEnabled : internalIgnoreDigitEnabled;
  const setIgnoreDigitEnabled = (val: boolean) => {
    if (propSetIgnoreDigitEnabled) propSetIgnoreDigitEnabled(val);
    else setInternalIgnoreDigitEnabled(val);
  };

  const [internalIgnoreDigitRules, setInternalIgnoreDigitRules] = useState<IgnoreDigitRule[]>(() => {
    const saved = localStorage.getItem("products_ignore_digit_rules")
      || localStorage.getItem("ya_ignore_digit_rules");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback
      }
    }
    return [{
      id: "default",
      cas: "ALL",
      length: 10,
      direction: "BACKWARD",
      count: 1
    }];
  });
  const ignoreDigitRules = propIgnoreDigitRules !== undefined ? propIgnoreDigitRules : internalIgnoreDigitRules;
  const setIgnoreDigitRules = (val: IgnoreDigitRule[]) => {
    if (propSetIgnoreDigitRules) propSetIgnoreDigitRules(val);
    else setInternalIgnoreDigitRules(val);
  };

  useEffect(() => {
    localStorage.setItem("products_ignore_digit_enabled", String(ignoreDigitEnabled));
  }, [ignoreDigitEnabled]);

  useEffect(() => {
    localStorage.setItem("products_ignore_digit_rules", JSON.stringify(ignoreDigitRules));
  }, [ignoreDigitRules]);

  useEffect(() => {
    globalProductsFilesCache = files;
  }, [files]);

  useEffect(() => {
    globalProductsSheetsCache = sheets;
  }, [sheets]);

  useEffect(() => {
    globalProductsContinuitySheetsCache = continuitySheets;
  }, [continuitySheets]);

  useEffect(() => {
    globalProductsUploadPanelCollapsedCache = isUploadPanelCollapsed;
  }, [isUploadPanelCollapsed]);

  useEffect(() => {
    globalProductsLogicPanelCollapsedCache = isLogicPanelCollapsed;
  }, [isLogicPanelCollapsed]);

  // Derive list of CAS systems found in the APP Source files' mapped CAS column
  const appCasSystems = useMemo<Set<string>>(() => {
    const systems = new Set<string>();
    const activeAppSheets = sheets.filter(s => s.role === "APP" || s.role === "SMS");
    activeAppSheets.forEach(sheet => {
      const names = getSheetUniqueCasNames(sheet);
      names.forEach(n => {
        const clean = n.trim().toLowerCase();
        if (clean) systems.add(clean);
      });
    });
    return systems;
  }, [sheets]);


  // --- STEP 3: REPORT VALIDATION GENERATION STATE ---
  const [reportRecords, setReportRecords] = useState<any[]>(
    () => globalReportRecordsCache
  );
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [validationProgress, setValidationProgress] = useState<number>(0);
  const [isReportGenerated, setIsReportGenerated] = useState<boolean>(
    () => globalIsReportGeneratedCache
  );

  useEffect(() => {
    globalReportRecordsCache = reportRecords;
  }, [reportRecords]);

  useEffect(() => {
    globalIsReportGeneratedCache = isReportGenerated;
  }, [isReportGenerated]);

  const handleReset = useCallback(() => {
    // 1. Reset validation report records
    setReportRecords([]);
    setIsReportGenerated(false);
    globalReportRecordsCache = [];
    globalIsReportGeneratedCache = false;

    // 2. Reset filters and search
    setSelectedCasFilter("ALL");
    setMasterSearch("");
    setReportSearch("");
    setReportFilter("ALL");
    setActiveSubTab("REPORT");

    // 3. Navigate back to DATA UPLOAD tab
    if (onNavigateToTab) {
      onNavigateToTab("DATA_UPLOAD");
    }
  }, [onNavigateToTab]);

  // Accordion toggle map for Broadcasters
  const [expandedBroadcasters, setExpandedBroadcasters] = useState<Record<string, boolean>>({});
  const [reportSearch, setReportSearch] = useState<string>("");
  const [reportFilter, setReportFilter] = useState<"ALL" | "ALIGNED" | "MISMATCH">("ALL");

  const [selectedCasFilter, setSelectedCasFilter] = useState<string>(
    () => globalSelectedCasCache
  );

  useEffect(() => {
    globalSelectedCasCache = selectedCasFilter;
  }, [selectedCasFilter]);

  // Shared lookups for Card ID -> CAS system (O(1) Map without expanding redundant normalized entries)
  const { cardProductToCasMap, cardToCasMap } = useMemo(() => {
    const productMap = new Map<string, string>();
    const generalMap = new Map<string, string>();

    const activeAppAndSmsSheets = sheets.filter(s => s.role === "APP" || s.role === "SMS");
    activeAppAndSmsSheets.forEach(sheet => {
      if (sheet.parsedCasData) {
        const casData = sheet.parsedCasData;
        for (const key in casData) {
          const val = casData[key];
          const cleanVal = String(val).trim();
          if (cleanVal) {
            if (key.includes("_")) {
              productMap.set(key, cleanVal);
            } else {
              generalMap.set(key, cleanVal);
            }
          }
        }
      }
    });

    return { cardProductToCasMap: productMap, cardToCasMap: generalMap };
  }, [sheets]);

  const getNormalizedKey = useCallback((k: string): string => {
    if (!ignoreDigitEnabled || ignoreDigitRules.length === 0) return k;
    const cardCasName = cardToCasMap.get(k) || "";
    const allRule = ignoreDigitRules.find(r => r.cas === "ALL");
    const rule = (cardCasName ? ignoreDigitRules.find(r => r.cas !== "ALL" && r.cas.toLowerCase() === cardCasName.toLowerCase()) : undefined) || allRule;
    if (rule && k.length > rule.length) {
      if (rule.direction === "BACKWARD") {
        return k.slice(0, Math.max(0, k.length - rule.count));
      } else {
        return k.slice(rule.count);
      }
    }
    return k;
  }, [ignoreDigitEnabled, ignoreDigitRules, cardToCasMap]);

  const getCardCas = useCallback((cardId: string, prodId: string): string => {
    const directKey = `${cardId}_${prodId}`;
    if (cardProductToCasMap.has(directKey)) {
      return cardProductToCasMap.get(directKey)!;
    }
    const normCardId = getNormalizedKey(cardId);
    if (normCardId !== cardId) {
      const normKey = `${normCardId}_${prodId}`;
      if (cardProductToCasMap.has(normKey)) {
        return cardProductToCasMap.get(normKey)!;
      }
    }
    return cardToCasMap.get(normCardId) || cardToCasMap.get(cardId) || "";
  }, [cardProductToCasMap, cardToCasMap, getNormalizedKey]);

  const defaultCasFromUploaded = useMemo(() => {
    const uploadedCasMap = new Map<string, string>();
    sheets
      .filter(s => s.role === "CAS" && s.associatedCasName)
      .forEach(s => {
        const trimmed = s.associatedCasName!.trim();
        if (trimmed) {
          uploadedCasMap.set(trimmed.toLowerCase(), trimmed);
        }
      });
    return uploadedCasMap.size === 1 ? Array.from(uploadedCasMap.values())[0] : "";
  }, [sheets]);

  const uniqueCasList = useMemo<string[]>(() => {
    const map = new Map<string, string>();
    reportRecords.forEach(r => {
      if (r.cas && r.cas !== "N/A" && r.cas !== "n/a" && r.cas.trim() !== "") {
        const trimmed = r.cas.trim();
        const key = trimmed.toLowerCase();
        if (!map.has(key)) {
          map.set(key, trimmed);
        } else {
          const existing = map.get(key)!;
          if (existing === existing.toUpperCase() && trimmed !== trimmed.toUpperCase()) {
            map.set(key, trimmed);
          }
        }
      }
    });
    return Array.from(map.values()).sort((a, b) => a.localeCompare(b));
  }, [reportRecords]);

  // --- SELECTED PRODUCT CARD KEYS DETAIL MODAL STATE ---
  const [selectedProductDetails, setSelectedProductDetails] = useState<{
    productId: string;
    productName: string;
    cas: string;
    broadcaster: string;
    diff: number;
    casCount: number;
    appCount: number;
  } | null>(null);

  const [modalSearch, setModalSearch] = useState<string>("");
  const [modalFilter, setModalFilter] = useState<"ALL" | "MISMATCH" | "ONLY_CAS" | "ONLY_APP" | "MATCH">("ALL");
  const [modalPage, setModalPage] = useState<number>(1);
  const [modalPageSize, setModalPageSize] = useState<number>(15);

  // Find card keys/VC_NUMBERs for the selected product and calculate their status
  const selectedProductKeys = useMemo(() => {
    if (!selectedProductDetails) return [];

    const targetProductId = selectedProductDetails.productId;
    const masterId = targetProductId.includes(" / ") ? targetProductId.split(" / ")[0].trim() : targetProductId;
    const refId = targetProductId.includes(" / ") ? targetProductId.split(" / ")[1].trim() : targetProductId;

    const masterIdClean = masterId.trim().replace(/'/g, "").toLowerCase();
    const refIdClean = refId.trim().replace(/'/g, "").toLowerCase();
    const prodCas = selectedProductDetails.cas ? selectedProductDetails.cas.trim().toLowerCase() : "";

    const checkCasMatch = (rowCas: string) => {
      const cleanR = rowCas ? rowCas.trim().toLowerCase() : "";
      if (!cleanR || cleanR === "n/a" || cleanR === "all" || !prodCas || prodCas === "n/a" || prodCas === "all") return true;
      return cleanR === prodCas || cleanR.includes(prodCas) || prodCas.includes(cleanR);
    };

    const keyMap = new Map<string, {
      key: string;
      inCas: boolean;
      casSheets: string[];
      inApp: boolean;
      appSheets: string[];
    }>();

    sheets.forEach(sheet => {
      if (sheet.role !== "CAS" && sheet.role !== "APP" && sheet.role !== "SMS") return;

      const sheetCasName = sheet.associatedCasName ? sheet.associatedCasName.trim() : "";

      Object.entries(sheet.parsedData).forEach(([key, productsList]) => {
        const hasProduct = Array.isArray(productsList) && (productsList as any[]).some(prodId => {
          const cleanProdId = String(prodId).trim().replace(/'/g, "").toLowerCase();
          return cleanProdId === masterIdClean || cleanProdId === refIdClean;
        });

        if (hasProduct) {
          const normKey = getNormalizedKey(key);
          const rowCas = sheetCasName || getCardCas(normKey, masterIdClean) || getCardCas(normKey, refIdClean) || defaultCasFromUploaded;

          if (!checkCasMatch(rowCas)) {
            return; // Strict match on CAS!
          }

          const existing = keyMap.get(normKey) || {
            key: normKey,
            inCas: false,
            casSheets: [],
            inApp: false,
            appSheets: []
          };

          if (sheet.role === "CAS") {
            existing.inCas = true;
            if (!existing.casSheets.includes(sheet.fileName)) {
              existing.casSheets.push(sheet.fileName);
            }
          } else if (sheet.role === "APP" || sheet.role === "SMS") {
            existing.inApp = true;
            if (!existing.appSheets.includes(sheet.fileName)) {
              existing.appSheets.push(sheet.fileName);
            }
          }

          keyMap.set(normKey, existing);
        }
      });
    });

    return Array.from(keyMap.values()).map(item => {
      let status: "MATCH" | "ONLY_CAS" | "ONLY_APP" = "MATCH";
      if (item.inCas && !item.inApp) status = "ONLY_CAS";
      else if (!item.inCas && item.inApp) status = "ONLY_APP";

      return {
        ...item,
        status
      };
    });
  }, [selectedProductDetails, sheets, getNormalizedKey, getCardCas, defaultCasFromUploaded, ignoreDigitEnabled, ignoreDigitRules]);

  // Filter and paginate the keys in the modal
  const processedModalKeys = useMemo(() => {
    const term = modalSearch.trim().toLowerCase();
    
    return selectedProductKeys.filter(k => {
      // Search matching VC_NUMBER/key
      if (term && !k.key.toLowerCase().includes(term)) {
        return false;
      }

      // Filter matching
      if (modalFilter === "MISMATCH") return k.status !== "MATCH";
      if (modalFilter === "ONLY_CAS") return k.status === "ONLY_CAS";
      if (modalFilter === "ONLY_APP") return k.status === "ONLY_APP";
      if (modalFilter === "MATCH") return k.status === "MATCH";

      return true;
    });
  }, [selectedProductKeys, modalSearch, modalFilter]);

  const totalModalRecords = processedModalKeys.length;
  const totalModalPages = Math.ceil(totalModalRecords / modalPageSize) || 1;
  const activeModalPage = Math.min(Math.max(1, modalPage), totalModalPages);
  const startModalIdx = (activeModalPage - 1) * modalPageSize;
  const paginatedModalKeys = processedModalKeys.slice(startModalIdx, startModalIdx + modalPageSize);

  const startModalRecordIdx = totalModalRecords === 0 ? 0 : startModalIdx + 1;
  const endModalRecordIdx = Math.min(activeModalPage * modalPageSize, totalModalRecords);

  const exportProductKeysCSV = () => {
    if (!selectedProductDetails) return;
    const headers = ["VC_NUMBER", "STATUS", "IN_CAS", "CAS_FILES", "IN_SMS", "SMS_FILES"];
    const rows = processedModalKeys.map(k => [
      k.key,
      k.status,
      k.inCas ? "YES" : "NO",
      k.casSheets.join("; "),
      k.inApp ? "YES" : "NO",
      k.appSheets.join("; ")
    ]);
    
    const csvString = [headers.join(","), ...rows.map(e => e.map(val => `"${String(val).replace(/'/g, '""').replace(/"/g, '""')}"`).join(","))].join("\n");
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    const filterSuffix = modalFilter !== "ALL" ? `_${modalFilter.toLowerCase()}` : "";
    link.setAttribute("download", `Product_${selectedProductDetails.productId}_Card_Keys_Audit${filterSuffix}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const runReportsValidation = () => {
    if (masterProducts.length === 0) {
      alert("Please upload and map Master Products Data in Step 1 before validating!");
      return;
    }
    const activeCasSheets = sheets.filter(s => s.role === "CAS");
    const activeAppSheets = sheets.filter(s => s.role === "APP" || s.role === "SMS");
    if (activeCasSheets.length === 0 && activeAppSheets.length === 0) {
      alert("Please upload at least one CAS (C) or SMS (S) transaction file in Step 2 before validating!");
      return;
    }

    setIsValidating(true);
    setValidationProgress(10);

    setTimeout(() => {
      setValidationProgress(35);

      // Load stored reference files
      let storedReferences: any[] = [];
      try {
        storedReferences = loadStoredReferenceFiles();
      } catch (err) {
        console.error("Error loading stored references for validation:", err);
      }

      // Pre-index stored reference files by mapping
      const refByCasLower = new Map<string, any>();
      let defaultRefFile: any = null;
      if (globalReferenceEnabled) {
        globalReferenceMappings.forEach((m: any) => {
          if (!m.referenceFileId) return;
          const ref = storedReferences.find((r: any) => r.id === m.referenceFileId);
          if (!ref) return;
          if (!m.casName || m.casName === "" || m.casName.toUpperCase() === "ALL") {
            if (!defaultRefFile) defaultRefFile = ref;
          } else {
            refByCasLower.set(m.casName.toLowerCase(), ref);
          }
        });
      }

      // Helper to get mapped reference file for CAS
      const getRefFileForCas = (casName: string) => {
        if (!globalReferenceEnabled) return null;
        if (casName && refByCasLower.has(casName.toLowerCase())) {
          return refByCasLower.get(casName.toLowerCase());
        }
        return defaultRefFile;
      };

      const uploadedCasMap = new Map<string, string>();
      sheets
        .filter(s => s.role === "CAS" && s.associatedCasName)
        .forEach(s => {
          const trimmed = s.associatedCasName!.trim();
          if (trimmed) {
            uploadedCasMap.set(trimmed.toLowerCase(), trimmed);
          }
        });

      const uploadedCasLower = new Set(uploadedCasMap.keys());
      const defaultCasFromUploaded = uploadedCasMap.size === 1 ? Array.from(uploadedCasMap.values())[0] : "";

      // High-performance indexed product structures
      interface ProdIndexEntry {
        counts: Record<string, number>;
        cardKeys: Record<string, Set<string>>;
        casList: string[];
      }
      const casProductIndex = new Map<string, ProdIndexEntry>();
      const appProductIndex = new Map<string, ProdIndexEntry>();

      const addToIndex = (index: Map<string, ProdIndexEntry>, prodId: string, normCardId: string, cleanRowCas: string) => {
        const cleanId = String(prodId).trim().replace(/'/g, "").toLowerCase();
        if (!cleanId || (ignoreZeroProductEnabled && (cleanId === "0" || cleanId === "00"))) return;
        const casKey = cleanRowCas || "N/A";
        let entry = index.get(cleanId);
        if (!entry) {
          entry = { counts: {}, cardKeys: {}, casList: [] };
          index.set(cleanId, entry);
        }
        if (entry.counts[casKey] === undefined) {
          entry.counts[casKey] = 0;
          entry.cardKeys[casKey] = new Set();
          entry.casList.push(casKey);
        }
        entry.counts[casKey] += 1;
        entry.cardKeys[casKey].add(normCardId);
      };

      // 1. Accumulate CAS product counts
      activeCasSheets.forEach(sheet => {
        const sheetCasName = sheet.associatedCasName ? sheet.associatedCasName.trim() : "";
        const parsedData = sheet.parsedData || {};
        for (const cardId in parsedData) {
          const productsList = parsedData[cardId] as string[];
          if (!productsList) continue;
          const normCardId = getNormalizedKey(cardId);
          for (let pIdx = 0; pIdx < productsList.length; pIdx++) {
            const prodId = productsList[pIdx];
            if (!prodId) continue;
            const cleanRowCas = sheetCasName || getCardCas(normCardId, String(prodId).trim().replace(/'/g, "")) || defaultCasFromUploaded;
            addToIndex(casProductIndex, prodId, normCardId, cleanRowCas);
          }
        }
      });

      setValidationProgress(60);

      // 2. Accumulate APP product counts
      activeAppSheets.forEach(sheet => {
        const sheetCasName = sheet.associatedCasName ? sheet.associatedCasName.trim() : "";
        const parsedData = sheet.parsedData || {};
        for (const cardId in parsedData) {
          const productsList = parsedData[cardId] as string[];
          if (!productsList) continue;
          const normCardId = getNormalizedKey(cardId);
          for (let pIdx = 0; pIdx < productsList.length; pIdx++) {
            const prodId = productsList[pIdx];
            if (!prodId) continue;
            const cleanRowCas = sheetCasName || getCardCas(normCardId, String(prodId).trim().replace(/'/g, "")) || defaultCasFromUploaded;
            addToIndex(appProductIndex, prodId, normCardId, cleanRowCas);
          }
        }
      });

      // Local helper to check CAS matching
      const isCasMatch = (casVal: string, kCas: string) => {
        const cleanCas = casVal ? casVal.trim().toLowerCase() : "";
        const cleanKCas = kCas ? kCas.trim().toLowerCase() : "";
        if (!cleanCas || cleanCas === "n/a" || cleanCas === "all" || !cleanKCas || cleanKCas === "n/a" || cleanKCas === "all") {
          return true;
        }
        return (
          cleanKCas === cleanCas ||
          cleanKCas.includes(cleanCas) ||
          cleanCas.includes(cleanKCas)
        );
      };

      // Local helper to aggregate counts matching a product's CAS using O(1) index
      const getCountsForProduct = (
        prodId: string, 
        casVal: string, 
        index: Map<string, ProdIndexEntry>
      ) => {
        const cleanId = prodId.trim().replace(/'/g, "").toLowerCase();
        const entry = index.get(cleanId);
        if (!entry) return 0;

        if (useUniqueOnly) {
          const unionSet = new Set<string>();
          for (let i = 0; i < entry.casList.length; i++) {
            const kCas = entry.casList[i];
            if (isCasMatch(casVal, kCas)) {
              entry.cardKeys[kCas].forEach(cardKey => unionSet.add(cardKey));
            }
          }
          return unionSet.size;
        }

        let total = 0;
        for (let i = 0; i < entry.casList.length; i++) {
          const kCas = entry.casList[i];
          if (isCasMatch(casVal, kCas)) {
            total += entry.counts[kCas];
          }
        }
        return total;
      };

      const getCountsForProductOnly = (
        prodId1: string,
        prodId2: string,
        casVal: string, 
        indexSelf: Map<string, ProdIndexEntry>,
        indexOther: Map<string, ProdIndexEntry>
      ) => {
        const cleanId1 = prodId1 ? prodId1.trim().replace(/'/g, "").toLowerCase() : "";
        const cleanId2 = prodId2 ? prodId2.trim().replace(/'/g, "").toLowerCase() : "";

        const setSelf = new Set<string>();
        const addFromIndex = (cleanId: string, setTarget: Set<string>, idxMap: Map<string, ProdIndexEntry>) => {
          if (!cleanId) return;
          const entry = idxMap.get(cleanId);
          if (!entry) return;
          for (let i = 0; i < entry.casList.length; i++) {
            const kCas = entry.casList[i];
            if (isCasMatch(casVal, kCas)) {
              entry.cardKeys[kCas].forEach(cardKey => setTarget.add(cardKey));
            }
          }
        };

        addFromIndex(cleanId1, setSelf, indexSelf);
        if (cleanId2 && cleanId2 !== cleanId1) {
          addFromIndex(cleanId2, setSelf, indexSelf);
        }
        if (setSelf.size === 0) return 0;

        const setOther = new Set<string>();
        addFromIndex(cleanId1, setOther, indexOther);
        if (cleanId2 && cleanId2 !== cleanId1) {
          addFromIndex(cleanId2, setOther, indexOther);
        }

        let onlyCount = 0;
        setSelf.forEach(k => {
          if (!setOther.has(k)) {
            onlyCount++;
          }
        });

        return onlyCount;
      };

      setValidationProgress(85);

      // 3. Build combined records matching Master Data
      const filteredMaster = masterProducts.filter(p => {
        const cleanPCas = p.cas ? p.cas.trim().toLowerCase() : "";

        // If master product is assigned to a specific CAS system,
        // keep master product ONLY if its CAS system was uploaded (or if its CAS system is ALL / N/A / blank)
        if (uploadedCasLower.size > 0 && cleanPCas && cleanPCas !== "n/a" && cleanPCas !== "all") {
          if (!uploadedCasLower.has(cleanPCas)) return false;
        }

        return true;
      });

      const recordsList: any[] = [];
      const processedProductCasKeys = new Set<string>();

      // A. Mapped master products
      filteredMaster.forEach(prod => {
        const cleanPId = prod.id ? prod.id.trim().replace(/'/g, "").toLowerCase() : "";
        if (!cleanPId || (ignoreZeroProductEnabled && (cleanPId === "0" || cleanPId === "00"))) return;

        let refVal = "";
        const refFile = getRefFileForCas(prod.cas || "");
        if (refFile && refFile.lookupMap) {
          refVal = refFile.lookupMap[prod.id] || "";
        }

        let activeCasFromTx = "";
        const directCasEntry = casProductIndex.get(cleanPId);
        if (directCasEntry && directCasEntry.casList.length > 0) {
          activeCasFromTx = directCasEntry.casList.find(c => c && c !== "n/a") || directCasEntry.casList[0];
        } else if (refVal) {
          const refCasEntry = casProductIndex.get(refVal.trim().replace(/'/g, "").toLowerCase());
          if (refCasEntry && refCasEntry.casList.length > 0) {
            activeCasFromTx = refCasEntry.casList.find(c => c && c !== "n/a") || refCasEntry.casList[0];
          }
        }

        const effectiveCasName = (prod.cas && prod.cas !== "N/A" && prod.cas !== "ALL" && prod.cas.trim() !== "")
          ? prod.cas
          : (activeCasFromTx ? activeCasFromTx : (defaultCasFromUploaded ? defaultCasFromUploaded : "N/A"));

        const effectiveCasClean = effectiveCasName.trim().toLowerCase();

        processedProductCasKeys.add(`${cleanPId}|||${effectiveCasClean}`);
        if (refVal) {
          processedProductCasKeys.add(`${refVal.trim().replace(/'/g, "").toLowerCase()}|||${effectiveCasClean}`);
        }

        const cCount = refVal
          ? Math.max(
              getCountsForProduct(refVal, effectiveCasName, casProductIndex),
              getCountsForProduct(prod.id, effectiveCasName, casProductIndex)
            )
          : getCountsForProduct(prod.id, effectiveCasName, casProductIndex);

        const aCount = refVal
          ? Math.max(
              getCountsForProduct(refVal, effectiveCasName, appProductIndex),
              getCountsForProduct(prod.id, effectiveCasName, appProductIndex)
            )
          : getCountsForProduct(prod.id, effectiveCasName, appProductIndex);

        const casOnlyCount = getCountsForProductOnly(
          prod.id,
          refVal,
          effectiveCasName,
          casProductIndex,
          appProductIndex
        );

        const appOnlyCount = getCountsForProductOnly(
          prod.id,
          refVal,
          effectiveCasName,
          appProductIndex,
          casProductIndex
        );

        const isAligned = cCount === aCount && casOnlyCount === 0 && appOnlyCount === 0;

        recordsList.push({
          productId: refVal ? `${prod.id} / ${refVal}` : prod.id,
          productName: prod.name,
          cas: effectiveCasName,
          broadcaster: prod.broadcaster,
          casCount: cCount,
          appCount: aCount,
          diff: cCount - aCount,
          isAligned,
          isUnmapped: false,
          casOnlyCount,
          appOnlyCount
        });
      });

      // B. Unmapped active product IDs found in transaction files but missing from Master Data for that CAS
      const unmappedGroups = new Map<string, {
        masterId: string;
        refVal: string;
        cas: string;
      }>();

      const processUnmappedFromIndex = (index: Map<string, ProdIndexEntry>) => {
        index.forEach((entry, activeId) => {
          if (!activeId || (ignoreZeroProductEnabled && (activeId === "0" || activeId === "00"))) return;
          for (let i = 0; i < entry.casList.length; i++) {
            const rawCas = entry.casList[i];
            let effectiveCas = rawCas ? rawCas.trim() : "";
            if (!effectiveCas && defaultCasFromUploaded) {
              effectiveCas = defaultCasFromUploaded;
            }
            const cleanActiveCas = effectiveCas.toLowerCase();
            if (processedProductCasKeys.has(`${activeId}|||${cleanActiveCas}`)) continue;

            const refFile = getRefFileForCas(effectiveCas || "");
            let masterId = activeId;
            let refVal = "";

            if (refFile && refFile.lookupMap) {
              if (refFile.lookupMap[activeId]) {
                masterId = activeId;
                refVal = refFile.lookupMap[activeId];
              } else {
                if (!(refFile as any).reverseLookupMap) {
                  const revMap = new Map<string, string>();
                  for (const k in refFile.lookupMap) {
                    revMap.set(String(refFile.lookupMap[k]).trim().toLowerCase(), k);
                  }
                  (refFile as any).reverseLookupMap = revMap;
                }
                const revMatch = (refFile as any).reverseLookupMap.get(activeId);
                if (revMatch) {
                  masterId = revMatch;
                  refVal = refFile.lookupMap[revMatch];
                }
              }
            }

            const groupKey = `${masterId}|||${cleanActiveCas}`;
            if (!unmappedGroups.has(groupKey)) {
              unmappedGroups.set(groupKey, {
                masterId,
                refVal,
                cas: effectiveCas
              });
            }
          }
        });
      };

      processUnmappedFromIndex(casProductIndex);
      processUnmappedFromIndex(appProductIndex);

      unmappedGroups.forEach(group => {
        const cCount = group.refVal
          ? Math.max(
              getCountsForProduct(group.refVal, group.cas, casProductIndex),
              getCountsForProduct(group.masterId, group.cas, casProductIndex)
            )
          : getCountsForProduct(group.masterId, group.cas, casProductIndex);

        const aCount = group.refVal
          ? Math.max(
              getCountsForProduct(group.refVal, group.cas, appProductIndex),
              getCountsForProduct(group.masterId, group.cas, appProductIndex)
            )
          : getCountsForProduct(group.masterId, group.cas, appProductIndex);

        const casOnlyCount = getCountsForProductOnly(
          group.masterId,
          group.refVal,
          group.cas,
          casProductIndex,
          appProductIndex
        );

        const appOnlyCount = getCountsForProductOnly(
          group.masterId,
          group.refVal,
          group.cas,
          appProductIndex,
          casProductIndex
        );

        const isAligned = cCount === aCount && casOnlyCount === 0 && appOnlyCount === 0;

        recordsList.push({
          productId: group.refVal ? `${group.masterId} / ${group.refVal}` : group.masterId,
          productName: "N/A (Missing in Master)",
          cas: group.cas ? group.cas : (defaultCasFromUploaded ? defaultCasFromUploaded : "N/A"),
          broadcaster: "Unmapped Products (Not in Master Data)",
          casCount: cCount,
          appCount: aCount,
          diff: cCount - aCount,
          isAligned,
          isUnmapped: true,
          casOnlyCount,
          appOnlyCount
        });
      });

      // Deduplicate by Product ID within each CAS only (Not across different CASs) if Unique IDs Only is enabled
      let finalRecords = recordsList;
      if (useUniqueOnly) {
        const seenKeys = new Set<string>();
        const deduplicatedRecords: any[] = [];
        recordsList.forEach(r => {
          const key = `${r.productId}|||${(r.cas || "").trim().toLowerCase()}`;
          if (!seenKeys.has(key)) {
            seenKeys.add(key);
            deduplicatedRecords.push(r);
          }
        });
        finalRecords = deduplicatedRecords;
      }

      setValidationProgress(100);

      setTimeout(() => {
        setReportRecords(finalRecords);
        setIsReportGenerated(true);
        setIsValidating(false);

        // Auto-expand all broadcasters
        const accordions: Record<string, boolean> = {};
        finalRecords.forEach(r => {
          accordions[r.broadcaster] = true;
        });
        setExpandedBroadcasters(accordions);

        // Move to Validation Report Tab automatically
        setActiveSubTab("REPORT");
      }, 100);

    }, 150);
  };

  // Automatically re-run validation if sheets, useUniqueOnly, or reference configurations change and a report was already generated (debounced to avoid UI freeze)
  useEffect(() => {
    if (isReportGenerated && (sheets.filter(s => s.role === "CAS").length > 0 || sheets.filter(s => s.role === "APP" || s.role === "SMS").length > 0) && masterProducts.length > 0) {
      const timer = setTimeout(() => {
        runReportsValidation();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [sheets, useUniqueOnly, ignoreZeroProductEnabled, globalReferenceEnabled, globalReferenceMappings]);

  // Process and filter report records based on "Both No Value" checkbox and CAS system (Product Name Ascending Order)
  const processedRecords = useMemo(() => {
    const list = reportRecords.filter(r => {
      if (bothNoValue && r.casCount === 0 && r.appCount === 0) {
        return false;
      }
      if (ignoreZeroProductEnabled) {
        const cleanPId = (r.productId || "").split("/")[0].trim();
        if (cleanPId === "0" || cleanPId === "00") {
          return false;
        }
      }
      if (selectedCasFilter !== "ALL") {
        const rCasClean = (r.cas || "").trim().toLowerCase();
        const selCasClean = selectedCasFilter.trim().toLowerCase();
        const matchesCas = 
          rCasClean === selCasClean ||
          rCasClean.includes(selCasClean) ||
          selCasClean.includes(rCasClean) ||
          rCasClean === "n/a" ||
          rCasClean === "";

        if (!matchesCas) {
          return false;
        }
      }
      return true;
    });

    return list.sort((a, b) => {
      const nameA = (a.productName || "").trim();
      const nameB = (b.productName || "").trim();
      const comp = nameA.localeCompare(nameB, undefined, { numeric: true, sensitivity: 'base' });
      if (comp !== 0) return comp;
      return (a.productId || "").localeCompare(b.productId || "", undefined, { numeric: true, sensitivity: 'base' });
    });
  }, [reportRecords, bothNoValue, selectedCasFilter]);

  // Group report records by broadcaster
  const groupedReport = useMemo(() => {
    const groups: Record<string, any[]> = {};
    
    // Filter records
    const filtered = processedRecords.filter(r => {
      const term = reportSearch.toLowerCase().trim();
      if (term === "") {
        if (reportFilter === "ALIGNED") return r.isAligned;
        if (reportFilter === "MISMATCH") return !r.isAligned;
        return true;
      }

      const cleanTerm = term.replace(/'/g, "");
      const cleanProdId = (r.productId || "").replace(/'/g, "").toLowerCase();

      const matchesSearch = 
        cleanProdId.includes(cleanTerm) ||
        r.productId.toLowerCase().includes(term) || 
        r.productName.toLowerCase().includes(term) || 
        r.cas.toLowerCase().includes(term) || 
        r.broadcaster.toLowerCase().includes(term) ||
        String(r.casCount) === term ||
        String(r.appCount) === term;

      if (!matchesSearch) return false;

      if (reportFilter === "ALIGNED") return r.isAligned;
      if (reportFilter === "MISMATCH") return !r.isAligned;

      return true;
    });

    // Group them
    filtered.forEach(r => {
      if (!groups[r.broadcaster]) {
        groups[r.broadcaster] = [];
      }
      groups[r.broadcaster].push(r);
    });

    return groups;
  }, [processedRecords, reportSearch, reportFilter]);

  // Overall statistics for validation
  const stats = useMemo(() => {
    let total = processedRecords.length;
    let aligned = processedRecords.filter(r => r.isAligned).length;
    let mismatched = total - aligned;
    let rate = total > 0 ? Math.round((aligned / total) * 100) : 0;
    
    let totalCasActive = processedRecords.reduce((sum, r) => sum + r.casCount, 0);
    let totalAppActive = processedRecords.reduce((sum, r) => sum + r.appCount, 0);

    return { total, aligned, mismatched, rate, totalCasActive, totalAppActive };
  }, [processedRecords]);

  const [reportViewMode, setReportViewMode] = useState<"CAS_SUMMARY" | "BROADCASTER">("CAS_SUMMARY");

  // Derive CAS-Wise Summary Report Data
  const casWiseSummary = useMemo(() => {
    if (!reportRecords || reportRecords.length === 0) return [];

    const casGroupMap = new Map<string, any[]>();

    processedRecords.forEach(record => {
      const casName = record.cas && record.cas.trim() !== "" ? record.cas.trim() : "N/A / Unspecified";
      if (!casGroupMap.has(casName)) {
        casGroupMap.set(casName, []);
      }
      casGroupMap.get(casName)!.push(record);
    });

    const result: Array<{
      casName: string;
      totalProductsCount: number;
      matched: Array<{ productId: string; productName: string; casCount: number; appCount: number; broadcaster: string }>;
      casUnique: Array<{ productId: string; productName: string; casCount: number; appCount: number; broadcaster: string }>;
      smsUnique: Array<{ productId: string; productName: string; casCount: number; appCount: number; broadcaster: string }>;
      casOnly: Array<{ productId: string; productName: string; casCount: number; appCount: number; broadcaster: string }>;
      smsOnly: Array<{ productId: string; productName: string; casCount: number; appCount: number; broadcaster: string }>;
    }> = [];

    casGroupMap.forEach((records, casName) => {
      // 1. CAS & SMS Matched Products: present in both CAS and SMS files (casCount > 0 && appCount > 0)
      const matched = records
        .filter(r => r.casCount > 0 && r.appCount > 0)
        .map(r => ({
          productId: r.productId,
          productName: r.productName,
          casCount: r.casCount,
          appCount: r.appCount,
          broadcaster: r.broadcaster
        }));

      // 2. CAS File Unique Products: products present in CAS File (casCount > 0)
      const casUnique = records
        .filter(r => r.casCount > 0)
        .map(r => ({
          productId: r.productId,
          productName: r.productName,
          casCount: r.casCount,
          appCount: r.appCount,
          broadcaster: r.broadcaster
        }));

      // 3. SMS File Unique Products: products present in SMS File (appCount > 0)
      const smsUnique = records
        .filter(r => r.appCount > 0)
        .map(r => ({
          productId: r.productId,
          productName: r.productName,
          casCount: r.casCount,
          appCount: r.appCount,
          broadcaster: r.broadcaster
        }));

      // 4. CAS Only Products: present in CAS file but NOT in SMS file (casCount > 0 && appCount === 0)
      const casOnly = records
        .filter(r => r.casCount > 0 && r.appCount === 0)
        .map(r => ({
          productId: r.productId,
          productName: r.productName,
          casCount: r.casCount,
          appCount: r.appCount,
          broadcaster: r.broadcaster
        }));

      // 5. SMS Only Products: present in SMS file but NOT in CAS file (appCount > 0 && casCount === 0)
      const smsOnly = records
        .filter(r => r.appCount > 0 && r.casCount === 0)
        .map(r => ({
          productId: r.productId,
          productName: r.productName,
          casCount: r.casCount,
          appCount: r.appCount,
          broadcaster: r.broadcaster
        }));

      result.push({
        casName,
        totalProductsCount: records.length,
        matched,
        casUnique,
        smsUnique,
        casOnly,
        smsOnly
      });
    });

    return result.sort((a, b) => a.casName.localeCompare(b.casName));
  }, [processedRecords, reportRecords]);

  // Filtered CAS-Wise Summary based on selected CAS filter and global report search
  const filteredCasWiseSummary = useMemo(() => {
    let list = casWiseSummary;
    if (selectedCasFilter !== "ALL") {
      list = list.filter(c => c.casName === selectedCasFilter);
    }

    if (!reportSearch.trim()) return list;

    const term = reportSearch.toLowerCase().trim();

    return list.map(c => {
      const filterFn = (p: any) =>
        p.productId.toLowerCase().includes(term) ||
        p.productName.toLowerCase().includes(term) ||
        p.broadcaster.toLowerCase().includes(term);

      return {
        ...c,
        matched: c.matched.filter(filterFn),
        casUnique: c.casUnique.filter(filterFn),
        smsUnique: c.smsUnique.filter(filterFn),
        casOnly: c.casOnly.filter(filterFn),
        smsOnly: c.smsOnly.filter(filterFn)
      };
    });
  }, [casWiseSummary, selectedCasFilter, reportSearch]);

  // Export Single CAS Summary to Excel with Individual Sheets for each category
  const handleExportSingleCasSummaryExcel = (casItem: any) => {
    const wb = XLSX.utils.book_new();
    const usedSheetNames = new Set<string>();

    const makeSheetName = (name: string) => {
      let clean = `${casItem.casName} - ${name}`.replace(/[:\\/?*\[\]]/g, "").trim();
      if (clean.length > 31) clean = clean.substring(0, 31).trim();
      let finalName = clean;
      let c = 1;
      while (usedSheetNames.has(finalName.toLowerCase())) {
        const suffix = `_${c}`;
        finalName = `${clean.substring(0, 31 - suffix.length)}${suffix}`;
        c++;
      }
      usedSheetNames.add(finalName.toLowerCase());
      return finalName;
    };

    // Sheet 1: Summary Overview
    const overviewRows: any[] = [];
    overviewRows.push(["CAS SYSTEM RECONCILIATION SUMMARY", casItem.casName]);
    overviewRows.push(["Total Products Analyzed", casItem.totalProductsCount]);
    overviewRows.push([]);
    overviewRows.push(["Category", "Total Products Count"]);
    overviewRows.push(["1. CAS & SMS Matched Products", casItem.matched.length]);
    overviewRows.push(["2. CAS File Unique Products", casItem.casUnique.length]);
    overviewRows.push(["3. SMS File Unique Products", casItem.smsUnique.length]);
    overviewRows.push(["4. CAS Only Products", casItem.casOnly.length]);
    overviewRows.push(["5. SMS Only Products", casItem.smsOnly.length]);

    const wsOverview = XLSX.utils.aoa_to_sheet(overviewRows);
    wsOverview["!cols"] = [{ wch: 35 }, { wch: 25 }];
    XLSX.utils.book_append_sheet(wb, wsOverview, makeSheetName("Overview"));

    // Sheet 2: CAS & SMS Matched Products
    const matchedRows: any[] = [
      ["Product ID / Code", "Product Name", "CAS Count", "SMS Count", "Broadcaster Network"]
    ];
    casItem.matched.forEach((p: any) => {
      matchedRows.push([p.productId, p.productName, p.casCount, p.appCount, p.broadcaster]);
    });
    const wsMatched = XLSX.utils.aoa_to_sheet(matchedRows);
    wsMatched["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
    XLSX.utils.book_append_sheet(wb, wsMatched, makeSheetName("Matched"));

    // Sheet 3: CAS File Unique Products
    const casUniqueRows: any[] = [
      ["Product ID / Code", "Product Name", "CAS Count", "SMS Count", "Broadcaster Network"]
    ];
    casItem.casUnique.forEach((p: any) => {
      casUniqueRows.push([p.productId, p.productName, p.casCount, p.appCount, p.broadcaster]);
    });
    const wsCasUnique = XLSX.utils.aoa_to_sheet(casUniqueRows);
    wsCasUnique["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
    XLSX.utils.book_append_sheet(wb, wsCasUnique, makeSheetName("CAS Unique"));

    // Sheet 4: SMS File Unique Products
    const smsUniqueRows: any[] = [
      ["Product ID / Code", "Product Name", "SMS Count", "CAS Count", "Broadcaster Network"]
    ];
    casItem.smsUnique.forEach((p: any) => {
      smsUniqueRows.push([p.productId, p.productName, p.appCount, p.casCount, p.broadcaster]);
    });
    const wsSmsUnique = XLSX.utils.aoa_to_sheet(smsUniqueRows);
    wsSmsUnique["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
    XLSX.utils.book_append_sheet(wb, wsSmsUnique, makeSheetName("SMS Unique"));

    // Sheet 5: CAS Only Products
    const casOnlyRows: any[] = [
      ["Product ID / Code", "Product Name", "CAS Count", "Broadcaster Network"]
    ];
    casItem.casOnly.forEach((p: any) => {
      casOnlyRows.push([p.productId, p.productName, p.casCount, p.broadcaster]);
    });
    const wsCasOnly = XLSX.utils.aoa_to_sheet(casOnlyRows);
    wsCasOnly["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 28 }];
    XLSX.utils.book_append_sheet(wb, wsCasOnly, makeSheetName("CAS Only"));

    // Sheet 6: SMS Only Products
    const smsOnlyRows: any[] = [
      ["Product ID / Code", "Product Name", "SMS Count", "Broadcaster Network"]
    ];
    casItem.smsOnly.forEach((p: any) => {
      smsOnlyRows.push([p.productId, p.productName, p.appCount, p.broadcaster]);
    });
    const wsSmsOnly = XLSX.utils.aoa_to_sheet(smsOnlyRows);
    wsSmsOnly["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 28 }];
    XLSX.utils.book_append_sheet(wb, wsSmsOnly, makeSheetName("SMS Only"));

    XLSX.writeFile(wb, `${casItem.casName}_Product_Summary_Report_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Export All CAS Summaries to Excel with Individual Sheets for each category & system
  const handleExportAllCasSummariesExcel = () => {
    if (casWiseSummary.length === 0) return;
    const wb = XLSX.utils.book_new();
    const usedSheetNames = new Set<string>();

    const getSheetName = (baseName: string) => {
      let clean = baseName.replace(/[:\\/?*\[\]]/g, "").trim();
      if (clean.length > 31) clean = clean.substring(0, 31).trim();
      let finalName = clean;
      let c = 1;
      while (usedSheetNames.has(finalName.toLowerCase())) {
        const suffix = `_${c}`;
        finalName = `${clean.substring(0, 31 - suffix.length)}${suffix}`;
        c++;
      }
      usedSheetNames.add(finalName.toLowerCase());
      return finalName;
    };

    // Sheet 1: Master Summary Overview
    const overviewRows: any[] = [
      ["CAS System Name", "Total Products Analyzed", "CAS & SMS Matched", "CAS File Unique", "SMS File Unique", "CAS Only", "SMS Only"]
    ];

    casWiseSummary.forEach(c => {
      overviewRows.push([
        c.casName,
        c.totalProductsCount,
        c.matched.length,
        c.casUnique.length,
        c.smsUnique.length,
        c.casOnly.length,
        c.smsOnly.length
      ]);
    });

    const wsOverview = XLSX.utils.aoa_to_sheet(overviewRows);
    wsOverview["!cols"] = [
      { wch: 25 },
      { wch: 22 },
      { wch: 20 },
      { wch: 18 },
      { wch: 18 },
      { wch: 15 },
      { wch: 15 }
    ];
    XLSX.utils.book_append_sheet(wb, wsOverview, getSheetName("CAS Summary Overview"));

    // Individual Category Sheets per CAS system
    casWiseSummary.forEach(casItem => {
      // 1. Matched Sheet
      const matchedRows: any[] = [
        ["Product ID / Code", "Product Name", "CAS Count", "SMS Count", "Broadcaster Network"]
      ];
      casItem.matched.forEach((p: any) => {
        matchedRows.push([p.productId, p.productName, p.casCount, p.appCount, p.broadcaster]);
      });
      const wsMatched = XLSX.utils.aoa_to_sheet(matchedRows);
      wsMatched["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsMatched, getSheetName(`${casItem.casName}-Matched`));

      // 2. CAS Unique Sheet
      const casUniqueRows: any[] = [
        ["Product ID / Code", "Product Name", "CAS Count", "SMS Count", "Broadcaster Network"]
      ];
      casItem.casUnique.forEach((p: any) => {
        casUniqueRows.push([p.productId, p.productName, p.casCount, p.appCount, p.broadcaster]);
      });
      const wsCasUnique = XLSX.utils.aoa_to_sheet(casUniqueRows);
      wsCasUnique["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsCasUnique, getSheetName(`${casItem.casName}-CAS Unique`));

      // 3. SMS Unique Sheet
      const smsUniqueRows: any[] = [
        ["Product ID / Code", "Product Name", "SMS Count", "CAS Count", "Broadcaster Network"]
      ];
      casItem.smsUnique.forEach((p: any) => {
        smsUniqueRows.push([p.productId, p.productName, p.appCount, p.casCount, p.broadcaster]);
      });
      const wsSmsUnique = XLSX.utils.aoa_to_sheet(smsUniqueRows);
      wsSmsUnique["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsSmsUnique, getSheetName(`${casItem.casName}-SMS Unique`));

      // 4. CAS Only Sheet
      const casOnlyRows: any[] = [
        ["Product ID / Code", "Product Name", "CAS Count", "Broadcaster Network"]
      ];
      casItem.casOnly.forEach((p: any) => {
        casOnlyRows.push([p.productId, p.productName, p.casCount, p.broadcaster]);
      });
      const wsCasOnly = XLSX.utils.aoa_to_sheet(casOnlyRows);
      wsCasOnly["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsCasOnly, getSheetName(`${casItem.casName}-CAS Only`));

      // 5. SMS Only Sheet
      const smsOnlyRows: any[] = [
        ["Product ID / Code", "Product Name", "SMS Count", "Broadcaster Network"]
      ];
      casItem.smsOnly.forEach((p: any) => {
        smsOnlyRows.push([p.productId, p.productName, p.appCount, p.broadcaster]);
      });
      const wsSmsOnly = XLSX.utils.aoa_to_sheet(smsOnlyRows);
      wsSmsOnly["!cols"] = [{ wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsSmsOnly, getSheetName(`${casItem.casName}-SMS Only`));
    });

    // Consolidated All CAS Category Sheets when multiple CAS systems exist
    if (casWiseSummary.length > 1) {
      // All Matched
      const allMatchedRows: any[] = [
        ["CAS System", "Product ID / Code", "Product Name", "CAS Count", "SMS Count", "Broadcaster Network"]
      ];
      casWiseSummary.forEach(c => {
        c.matched.forEach((p: any) => {
          allMatchedRows.push([c.casName, p.productId, p.productName, p.casCount, p.appCount, p.broadcaster]);
        });
      });
      const wsAllMatched = XLSX.utils.aoa_to_sheet(allMatchedRows);
      wsAllMatched["!cols"] = [{ wch: 22 }, { wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsAllMatched, getSheetName("All Matched Products"));

      // All CAS Unique
      const allCasUniqueRows: any[] = [
        ["CAS System", "Product ID / Code", "Product Name", "CAS Count", "SMS Count", "Broadcaster Network"]
      ];
      casWiseSummary.forEach(c => {
        c.casUnique.forEach((p: any) => {
          allCasUniqueRows.push([c.casName, p.productId, p.productName, p.casCount, p.appCount, p.broadcaster]);
        });
      });
      const wsAllCasUnique = XLSX.utils.aoa_to_sheet(allCasUniqueRows);
      wsAllCasUnique["!cols"] = [{ wch: 22 }, { wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsAllCasUnique, getSheetName("All CAS Unique"));

      // All SMS Unique
      const allSmsUniqueRows: any[] = [
        ["CAS System", "Product ID / Code", "Product Name", "SMS Count", "CAS Count", "Broadcaster Network"]
      ];
      casWiseSummary.forEach(c => {
        c.smsUnique.forEach((p: any) => {
          allSmsUniqueRows.push([c.casName, p.productId, p.productName, p.appCount, p.casCount, p.broadcaster]);
        });
      });
      const wsAllSmsUnique = XLSX.utils.aoa_to_sheet(allSmsUniqueRows);
      wsAllSmsUnique["!cols"] = [{ wch: 22 }, { wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsAllSmsUnique, getSheetName("All SMS Unique"));

      // All CAS Only
      const allCasOnlyRows: any[] = [
        ["CAS System", "Product ID / Code", "Product Name", "CAS Count", "Broadcaster Network"]
      ];
      casWiseSummary.forEach(c => {
        c.casOnly.forEach((p: any) => {
          allCasOnlyRows.push([c.casName, p.productId, p.productName, p.casCount, p.broadcaster]);
        });
      });
      const wsAllCasOnly = XLSX.utils.aoa_to_sheet(allCasOnlyRows);
      wsAllCasOnly["!cols"] = [{ wch: 22 }, { wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsAllCasOnly, getSheetName("All CAS Only"));

      // All SMS Only
      const allSmsOnlyRows: any[] = [
        ["CAS System", "Product ID / Code", "Product Name", "SMS Count", "Broadcaster Network"]
      ];
      casWiseSummary.forEach(c => {
        c.smsOnly.forEach((p: any) => {
          allSmsOnlyRows.push([c.casName, p.productId, p.productName, p.appCount, p.broadcaster]);
        });
      });
      const wsAllSmsOnly = XLSX.utils.aoa_to_sheet(allSmsOnlyRows);
      wsAllSmsOnly["!cols"] = [{ wch: 22 }, { wch: 20 }, { wch: 35 }, { wch: 14 }, { wch: 28 }];
      XLSX.utils.book_append_sheet(wb, wsAllSmsOnly, getSheetName("All SMS Only"));
    }

    XLSX.writeFile(wb, `All_CAS_Wise_Product_Summary_Report_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Helper to attach header to all PDF pages
  const addPdfHeader = (doc: jsPDF, broadcasterName?: string) => {
    const pageCount = (doc as any).internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(7);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(100, 116, 139);
      if (broadcasterName) {
        doc.text(`BROADCASTER : ${broadcasterName.toUpperCase()}`, 14, 9, { align: "left" });
      }
      doc.text("Generated By : YA AUDIT TOOL( YA ENTERPRISE TECHNOLOGY PRIVATE LIMITED)", 282, 9, { align: "right" });
    }
  };

  const getActiveCasSystemsString = (recordsList?: any[]) => {
    const list = recordsList && recordsList.length > 0 ? recordsList : processedRecords;
    const casSet = new Set<string>();
    list.forEach(r => {
      if (r.cas && r.cas.trim() && r.cas.trim() !== "N/A" && r.cas.trim() !== "N/A / Unspecified") {
        casSet.add(r.cas.trim());
      }
    });
    if (casSet.size === 0 && sheets.length > 0) {
      sheets.filter(s => s.role === "CAS").forEach(s => {
        const name = s.associatedCasName || s.referenceName || s.fileName || s.sheetName;
        if (name && name.trim()) casSet.add(name.trim());
      });
    }
    const arr = Array.from(casSet);
    return arr.length > 0 ? arr.join(", ") : "N/A";
  };

  // Export Single CAS Summary to PDF
  const handleExportSingleCasSummaryPDF = (casItem: any) => {
    if (!casItem) return;

    const doc = new jsPDF({ orientation: "landscape" });

    doc.setFontSize(15);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 41, 59);
    doc.text(`CAS SYSTEM RECONCILIATION SUMMARY: ${casItem.casName}`, 14, 15);

    doc.setFontSize(8.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    const stamp = new Date().toLocaleString();
    doc.text(`Generated: ${stamp} | Total Products Analyzed: ${casItem.totalProductsCount}`, 14, 20);
    doc.setFont("helvetica", "bold");
    doc.text(`ACTIVE CAS SYSTEMS : ${casItem.casName}`, 14, 25);

    // Summary table
    const overview = [
      ["Category", "Products Count"],
      ["1. CAS & SMS Matched Products", casItem.matched.length.toString()],
      ["2. CAS File Unique Products", casItem.casUnique.length.toString()],
      ["3. SMS File Unique Products", casItem.smsUnique.length.toString()],
      ["4. CAS Only Products", casItem.casOnly.length.toString()],
      ["5. SMS Only Products", casItem.smsOnly.length.toString()]
    ];

    autoTable(doc, {
      startY: 29,
      head: [overview[0]],
      body: overview.slice(1),
      theme: "plain",
      headStyles: { fillColor: [241, 245, 249], textColor: 30, fontStyle: "bold", fontSize: 9 },
      bodyStyles: { fontSize: 8.5 }
    });

    let currentY = (doc as any).lastAutoTable.finalY + 10;

    const renderCatTable = (title: string, products: any[], isFourCols = false) => {
      if (currentY > 170) {
        doc.addPage();
        currentY = 15;
      }

      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text(`${title} (${products.length})`, 14, currentY);

      const head = isFourCols
        ? [["Product ID / Code", "Product Name", "Count", "Broadcaster Network"]]
        : [["Product ID / Code", "Product Name", "CAS Count", "SMS Count", "Broadcaster Network"]];

      const body = products.map(p => isFourCols
        ? [p.productId || "-", p.productName || "-", (p.casCount || p.appCount || 0).toString(), p.broadcaster || "-"]
        : [p.productId || "-", p.productName || "-", (p.casCount || 0).toString(), (p.appCount || 0).toString(), p.broadcaster || "-"]
      );

      autoTable(doc, {
        startY: currentY + 4,
        head: head,
        body: body,
        theme: "striped",
        headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: "bold", fontSize: 8 },
        bodyStyles: { fontSize: 7.5 },
        alternateRowStyles: { fillColor: [248, 250, 252] }
      });

      currentY = (doc as any).lastAutoTable.finalY + 10;
    };

    renderCatTable("1. CAS & SMS Matched Products", casItem.matched, false);
    renderCatTable("2. CAS File Unique Products", casItem.casUnique, false);
    renderCatTable("3. SMS File Unique Products", casItem.smsUnique, false);
    renderCatTable("4. CAS Only Products", casItem.casOnly, true);
    renderCatTable("5. SMS Only Products", casItem.smsOnly, true);

    addPdfHeader(doc);
    const cleanName = casItem.casName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    doc.save(`${cleanName}_Product_Summary_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  // Export All CAS Summaries to PDF
  const handleExportAllCasSummariesPDF = () => {
    if (casWiseSummary.length === 0) return;

    const doc = new jsPDF({ orientation: "landscape" });

    doc.setFontSize(15);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 41, 59);
    doc.text("ALL CAS SYSTEMS RECONCILIATION SUMMARY REPORT", 14, 15);

    doc.setFontSize(8.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    const allCasStr = casWiseSummary.map(c => c.casName).join(", ") || "N/A";
    doc.text(`Generated: ${new Date().toLocaleString()} | Total CAS Systems: ${casWiseSummary.length}`, 14, 20);
    doc.setFont("helvetica", "bold");
    doc.text(`ACTIVE CAS SYSTEMS : ${allCasStr}`, 14, 25);

    const overviewHead = [["CAS System Name", "Total Products Analyzed", "CAS & SMS Matched", "CAS File Unique", "SMS File Unique", "CAS Only", "SMS Only"]];
    const overviewBody = casWiseSummary.map(c => [
      c.casName,
      c.totalProductsCount.toString(),
      c.matched.length.toString(),
      c.casUnique.length.toString(),
      c.smsUnique.length.toString(),
      c.casOnly.length.toString(),
      c.smsOnly.length.toString()
    ]);

    autoTable(doc, {
      startY: 29,
      head: overviewHead,
      body: overviewBody,
      theme: "grid",
      headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: "bold", fontSize: 8.5 },
      bodyStyles: { fontSize: 8 }
    });

    casWiseSummary.forEach(casItem => {
      doc.addPage();
      let y = 15;

      doc.setFontSize(13);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text(`CAS SYSTEM: ${casItem.casName}`, 14, y);

      doc.setFontSize(8.5);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100, 116, 139);
      doc.text(`Products Analyzed: ${casItem.totalProductsCount} | Matched: ${casItem.matched.length} | CAS Unique: ${casItem.casUnique.length} | SMS Unique: ${casItem.smsUnique.length} | CAS Only: ${casItem.casOnly.length} | SMS Only: ${casItem.smsOnly.length}`, 14, y + 5);

      y += 11;

      const renderCatTable = (title: string, products: any[], isFourCols = false) => {
        if (y > 170) {
          doc.addPage();
          y = 15;
        }

        doc.setFontSize(10);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(30, 41, 59);
        doc.text(`${title} (${products.length})`, 14, y);

        const head = isFourCols
          ? [["Product ID / Code", "Product Name", "Count", "Broadcaster Network"]]
          : [["Product ID / Code", "Product Name", "CAS Count", "SMS Count", "Broadcaster Network"]];

        const body = products.map(p => isFourCols
          ? [p.productId || "-", p.productName || "-", (p.casCount || p.appCount || 0).toString(), p.broadcaster || "-"]
          : [p.productId || "-", p.productName || "-", (p.casCount || 0).toString(), (p.appCount || 0).toString(), p.broadcaster || "-"]
        );

        autoTable(doc, {
          startY: y + 3,
          head: head,
          body: body,
          theme: "striped",
          headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: "bold", fontSize: 8 },
          bodyStyles: { fontSize: 7.5 }
        });

        y = (doc as any).lastAutoTable.finalY + 8;
      };

      renderCatTable("1. CAS & SMS Matched Products", casItem.matched, false);
      renderCatTable("2. CAS File Unique Products", casItem.casUnique, false);
      renderCatTable("3. SMS File Unique Products", casItem.smsUnique, false);
      renderCatTable("4. CAS Only Products", casItem.casOnly, true);
      renderCatTable("5. SMS Only Products", casItem.smsOnly, true);
    });

    addPdfHeader(doc);
    doc.save(`All_CAS_Wise_Product_Summary_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  // Export full Validation Report to PDF
  const handleExportPDF = () => {
    if (processedRecords.length === 0) return;

    const doc = new jsPDF({ orientation: "landscape" });

    doc.setFontSize(15);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 41, 59);
    doc.text("BROADCASTER WISE VALIDATION REPORT", 148.5, 15, { align: "center" });

    doc.setFontSize(8.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    const stamp = new Date().toLocaleString();
    const activeCasStr = getActiveCasSystemsString(processedRecords);
    doc.text(`Generated: ${stamp} | Total Products: ${stats.total} | Aligned: ${stats.aligned} | Discrepancies: ${stats.mismatched} | Alignment Rate: ${stats.rate}%`, 14, 20);
    doc.setFont("helvetica", "bold");
    doc.text(`ACTIVE CAS SYSTEMS : ${activeCasStr}`, 14, 25);

    const head = [
      [
        "Broadcaster",
        "Product ID",
        "Product Name",
        "CAS System",
        "CAS Count",
        "SMS Count",
        "Diff",
        "CAS Only",
        "SMS Only",
        "Status"
      ]
    ];

    const body = processedRecords.map(r => [
      r.broadcaster || "N/A",
      r.productId || "-",
      r.productName || "-",
      r.cas || "-",
      (r.casCount || 0).toLocaleString(),
      (r.appCount || 0).toLocaleString(),
      (r.diff || 0) > 0 ? `+${r.diff}` : (r.diff || 0).toString(),
      (r.casOnlyCount || 0).toLocaleString(),
      (r.appOnlyCount || 0).toLocaleString(),
      r.isAligned ? "ALIGNED" : "DISCREPANCY"
    ]);

    autoTable(doc, {
      startY: 29,
      head: head,
      body: body,
      theme: "striped",
      headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: "bold", fontSize: 8 },
      bodyStyles: { fontSize: 7, fontStyle: "bold", textColor: 30, overflow: "ellipsize" },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      columnStyles: {
        0: { cellWidth: 32 },
        1: { cellWidth: 60, overflow: "ellipsize" }, // Product ID (expanded for full ID)
        2: { cellWidth: 48, overflow: "ellipsize" }, // Product Name (neat single line without huge gap)
        3: { cellWidth: 34 },
        4: { cellWidth: 18, halign: "center" },
        5: { cellWidth: 18, halign: "center" },
        6: { cellWidth: 18, halign: "center" },
        7: { cellWidth: 15, halign: "center" },
        8: { cellWidth: 15, halign: "center" },
        9: { cellWidth: 21, halign: "center" }
      },
      didParseCell: (data) => {
        if (data.section === "body") {
          data.cell.styles.fontStyle = "bold";

          // Diff column highlight (Index 6)
          if (data.column.index === 6) {
            const raw = String(data.cell.raw || "");
            const val = parseFloat(raw.replace("+", ""));
            if (!isNaN(val)) {
              if (val > 0) {
                data.cell.styles.textColor = [16, 185, 129]; // GREEN
              } else if (val < 0) {
                data.cell.styles.textColor = [239, 68, 68]; // RED
              }
            }
          }

          // Status column highlight (Index 9)
          if (data.column.index === 9) {
            if (data.cell.raw === "ALIGNED") {
              data.cell.styles.textColor = [16, 185, 129];
            } else {
              data.cell.styles.textColor = [239, 68, 68];
            }
          }
        }
      }
    });

    addPdfHeader(doc);
    const fileStamp = new Date().toISOString().slice(0, 10);
    doc.save(`Broadcaster_Wise_Validation_Report_${fileStamp}.pdf`);
  };

  // Export results to Excel
  const handleExportExcel = () => {
    if (processedRecords.length === 0) return;

    const dataSheetRows = processedRecords.map(r => ({
      "Broadcaster": r.broadcaster,
      "Product ID": r.productId,
      "Product Name": r.productName,
      "CAS System / Code": r.cas,
      "CAS (C) Count": r.casCount,
      "SMS (S) Count": r.appCount,
      "Difference (C - S)": r.diff,
      "CAS Only Count": r.casOnlyCount || 0,
      "SMS Only Count": r.appOnlyCount || 0,
      "Alignment Status": r.isAligned ? "ALIGNED" : "DISCREPANCY"
    }));

    const ws = XLSX.utils.json_to_sheet(dataSheetRows, { raw: true } as any);
    
    // Set columns visual widths
    ws["!cols"] = [
      { wch: 30 }, // Broadcaster
      { wch: 15 }, // Product ID
      { wch: 25 }, // Product Name
      { wch: 20 }, // CAS System
      { wch: 15 }, // CAS (C) Count
      { wch: 15 }, // SMS (S) Count
      { wch: 18 }, // Difference
      { wch: 15 }, // CAS Only Count
      { wch: 15 }, // SMS Only Count
      { wch: 18 }  // Alignment Status
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Product Validation Report");

    const stamp = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, `Broadcaster_Product_Report_${stamp}.xlsx`);
  };

  // Export results to CSV
  const handleExportCSV = () => {
    if (processedRecords.length === 0) return;

    const headers = [
      "Broadcaster",
      "Product ID",
      "Product Name",
      "CAS System / Code",
      "CAS (C) Count",
      "SMS (S) Count",
      "Difference (C - S)",
      "CAS Only Count",
      "SMS Only Count",
      "Alignment Status"
    ];

    const escapeCSV = (val: any) => {
      let str = String(val === null || val === undefined ? "" : val).trim();
      if (/^\d+$/.test(str) && str.length >= 11) {
        str = "\t" + str;
      }
      if (str.includes(",") || str.includes('"') || str.includes("\n") || str.includes("\r")) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    const lines = [headers.join(",")];
    processedRecords.forEach(r => {
      const row = [
        escapeCSV(r.broadcaster),
        escapeCSV(r.productId),
        escapeCSV(r.productName),
        escapeCSV(r.cas),
        r.casCount,
        r.appCount,
        r.diff,
        r.casOnlyCount || 0,
        r.appOnlyCount || 0,
        r.isAligned ? "ALIGNED" : "DISCREPANCY"
      ];
      lines.push(row.join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + lines.join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    const stamp = new Date().toISOString().slice(0, 10);
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Broadcaster_Product_Report_${stamp}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  // Export a single broadcaster to CSV
  const handleExportBroadcasterCSV = (broadcasterName: string, list: any[]) => {
    const headers = [
      "Product ID",
      "Product Name",
      "CAS System / Code",
      "CAS (C) Count",
      "SMS (S) Count",
      "Difference",
      "CAS Only Count",
      "SMS Only Count",
      "Alignment Status"
    ];

    const escapeCSV = (val: any) => {
      const str = String(val === null || val === undefined ? "" : val);
      if (str.includes(",") || str.includes('"') || str.includes("\n") || str.includes("\r")) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    const lines = [
      `"Broadcaster Report: ${broadcasterName.replace(/"/g, '""')}"`,
      `"Generated: ${new Date().toLocaleString()}"`,
      `"Filter CAS: ${Array.from(appCasSystems).join(", ") || "ALL"}"`,
      `"Unique IDs Only: ${useUniqueOnly ? "YES" : "NO"}"`,
      "",
      headers.join(",")
    ];

    list.forEach(p => {
      const row = [
        escapeCSV(p.productId),
        escapeCSV(p.productName),
        escapeCSV(p.cas),
        p.casCount,
        p.appCount,
        p.diff,
        p.casOnlyCount || 0,
        p.appOnlyCount || 0,
        p.isAligned ? "ALIGNED" : "DISCREPANCY"
      ];
      lines.push(row.join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + lines.map(l => encodeURIComponent(l)).join("%0A");
    const link = document.createElement("a");
    const stamp = new Date().toISOString().slice(0, 10);
    const cleanName = broadcasterName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    link.setAttribute("href", csvContent);
    link.setAttribute("download", `Broadcaster_${cleanName}_Report_${stamp}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export a single broadcaster to PDF (using jsPDF binary download)
  const handleExportBroadcasterPDF = (broadcasterName: string, list: any[]) => {
    if (!list || list.length === 0) return;

    const doc = new jsPDF({ orientation: "landscape" });

    doc.setFontSize(15);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 41, 59);
    doc.text("BROADCASTER WISE VALIDATION REPORT", 148.5, 15, { align: "center" });

    doc.setFontSize(8.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    const stamp = new Date().toLocaleString();
    const alignedCount = list.filter(p => p.isAligned).length;
    const discCount = list.length - alignedCount;
    const broadcasterCasStr = getActiveCasSystemsString(list);
    doc.text(`Generated: ${stamp} | Total Products: ${list.length} | Aligned: ${alignedCount} | Discrepancies: ${discCount}`, 14, 20);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 41, 59);
    doc.text(`BROADCASTER : ${broadcasterName.toUpperCase()}`, 14, 24);
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text(`ACTIVE CAS SYSTEMS : ${broadcasterCasStr}`, 14, 28);

    const head = [
      [
        "Product ID",
        "Product Name",
        "CAS System / Code",
        "CAS (C) Count",
        "SMS (S) Count",
        "Difference",
        "CAS Only",
        "SMS Only",
        "Status"
      ]
    ];

    const body = list.map(p => [
      p.productId || "-",
      p.productName || "-",
      p.cas || "-",
      (p.casCount || 0).toLocaleString(),
      (p.appCount || 0).toLocaleString(),
      (p.diff || 0) > 0 ? `+${p.diff}` : (p.diff || 0).toString(),
      (p.casOnlyCount || 0).toLocaleString(),
      (p.appOnlyCount || 0).toLocaleString(),
      p.isAligned ? "ALIGNED" : "DISCREPANCY"
    ]);

    autoTable(doc, {
      startY: 32,
      head: head,
      body: body,
      theme: "striped",
      headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: "bold", fontSize: 8 },
      bodyStyles: { fontSize: 7, fontStyle: "bold", textColor: 30, overflow: "ellipsize" },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      columnStyles: {
        0: { cellWidth: 65, overflow: "ellipsize" }, // Product ID (fits long codes like ASIANET MOVIES / ADV109)
        1: { cellWidth: 48, overflow: "ellipsize" }, // Product Name (neat single line without empty space)
        2: { cellWidth: 38 }, // CAS System
        3: { cellWidth: 20, halign: "center" },
        4: { cellWidth: 20, halign: "center" },
        5: { cellWidth: 20, halign: "center" },
        6: { cellWidth: 18, halign: "center" },
        7: { cellWidth: 18, halign: "center" },
        8: { cellWidth: 22, halign: "center" }
      },
      didParseCell: (data) => {
        if (data.section === "body") {
          data.cell.styles.fontStyle = "bold";

          // Difference column highlight (Index 5)
          if (data.column.index === 5) {
            const raw = String(data.cell.raw || "");
            const val = parseFloat(raw.replace("+", ""));
            if (!isNaN(val)) {
              if (val > 0) {
                data.cell.styles.textColor = [16, 185, 129]; // GREEN
              } else if (val < 0) {
                data.cell.styles.textColor = [239, 68, 68]; // RED
              }
            }
          }

          // Status column highlight (Index 8)
          if (data.column.index === 8) {
            if (data.cell.raw === "ALIGNED") {
              data.cell.styles.textColor = [16, 185, 129];
            } else {
              data.cell.styles.textColor = [239, 68, 68];
            }
          }
        }
      }
    });

    addPdfHeader(doc, broadcasterName);
    const cleanName = broadcasterName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    const fileStamp = new Date().toISOString().slice(0, 10);
    doc.save(`Broadcaster_${cleanName}_Report_${fileStamp}.pdf`);
  };


  // Filtering of Master Data grid list
  const filteredMasterRows = useMemo(() => {
    if (!masterSearch) return masterProducts;
    const term = masterSearch.toLowerCase().trim();
    return masterProducts.filter(p => 
      p.id.toLowerCase().includes(term) ||
      p.name.toLowerCase().includes(term) ||
      p.cas.toLowerCase().includes(term) ||
      p.broadcaster.toLowerCase().includes(term)
    );
  }, [masterProducts, masterSearch]);


  return (
    <div className="flex-1 flex flex-col gap-4 min-h-0 h-full w-full">
      
      {/* Sub-Tabs & Action Bar */}
      <div className="bg-slate-900/40 border border-slate-800/80 p-2 rounded-2xl flex flex-col lg:flex-row items-center justify-between gap-3 shrink-0 shadow-lg">
        <div className="flex items-center gap-2 w-full lg:w-auto overflow-x-auto">
          <button
            onClick={() => setActiveSubTab("REPORT")}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold tracking-wide transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
              activeSubTab === "REPORT"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/45"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
            }`}
          >
            <Database size={13} />
            <span>1. VALIDATION REPORT</span>
            {reportRecords.length > 0 && (
              <span className={`px-1.5 py-0.2 text-[9px] font-bold font-mono rounded ${stats.mismatched > 0 ? "bg-amber-950/60 border border-amber-500/30 text-amber-400" : "bg-emerald-950/60 border border-emerald-500/30 text-emerald-400"}`}>
                {stats.rate}% Align
              </span>
            )}
          </button>

          <button
            onClick={() => {
              if (reportRecords.length > 0) {
                setActiveSubTab("SUMMARY");
              } else {
                alert("Please click 'VALIDATE PRODUCTS' to generate the reports first.");
              }
            }}
            disabled={reportRecords.length === 0}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold tracking-wide transition-all whitespace-nowrap flex items-center gap-2 ${
              reportRecords.length === 0 ? "opacity-50 cursor-not-allowed text-slate-600" : "cursor-pointer"
            } ${
              activeSubTab === "SUMMARY"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/45"
                : reportRecords.length > 0 
                ? "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40" 
                : "text-slate-600"
            }`}
          >
            <PieChart size={13} />
            <span>2. CAS SUMMARY REPORT</span>
            {casWiseSummary.length > 0 && (
              <span className="px-1.5 py-0.2 text-[9px] font-bold font-mono rounded bg-indigo-950/60 border border-indigo-500/30 text-indigo-300">
                {casWiseSummary.length} CAS
              </span>
            )}
          </button>
        </div>

        {/* Source Files, Master Data Badges & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto shrink-0 justify-end">
          {/* Source Files Status Badge */}
          <button
            type="button"
            onClick={() => onNavigateToTab?.("DATA_UPLOAD")}
            className="px-2.5 py-1.5 rounded-xl text-[11px] font-semibold bg-slate-950 border border-slate-800 hover:border-indigo-500/50 text-slate-300 transition flex items-center gap-1.5 cursor-pointer shadow-sm"
            title="Click to view or manage source files in DATA UPLOAD"
          >
            <Upload size={12} className="text-indigo-400" />
            <span>
              Source: <strong className="text-emerald-400">{sheets.filter(s => s.role === "CAS").length}C</strong> / <strong className="text-violet-400">{sheets.filter(s => s.role === "APP" || s.role === "SMS").length}S</strong>
            </span>
          </button>

          {/* Master Catalog Status Badge */}
          <button
            type="button"
            onClick={() => onNavigateToTab?.("PRODUCT_MASTER")}
            className="px-2.5 py-1.5 rounded-xl text-[11px] font-semibold bg-slate-950 border border-slate-800 hover:border-indigo-500/50 text-slate-300 transition flex items-center gap-1.5 cursor-pointer shadow-sm"
            title="Click to view or edit catalog in PRODUCT MASTER DATA"
          >
            <FileSpreadsheet size={12} className="text-amber-400" />
            <span>
              Catalog: <strong className={masterProducts.length > 0 ? "text-indigo-300 font-mono" : "text-amber-400"}>
                {masterProducts.length > 0 ? `${masterProducts.length.toLocaleString()} Prods` : "Missing"}
              </strong>
            </span>
          </button>

          {/* Reset Action */}
          <button
            onClick={handleReset}
            className="py-2 px-3.5 rounded-xl text-xs font-extrabold transition-all flex items-center space-x-1.5 shadow-md cursor-pointer bg-slate-900 hover:bg-rose-950/70 text-slate-300 hover:text-rose-400 border border-slate-800 hover:border-rose-800/80 active:scale-[0.98]"
            title="Reset validation reports & return to DATA UPLOAD"
          >
            <RotateCcw size={12} />
            <span>RESET</span>
          </button>

          {/* Prominent VALIDATE PRODUCTS button */}
          <button
            onClick={runReportsValidation}
            disabled={((sheets.filter(s => s.role === "CAS").length === 0 && sheets.filter(s => s.role === "APP" || s.role === "SMS").length === 0) || masterProducts.length === 0 || isValidating)}
            className={`py-2 px-5 rounded-xl text-xs font-black tracking-wide transition-all flex items-center space-x-2 shadow-lg cursor-pointer ${
              ((sheets.filter(s => s.role === "CAS").length > 0 || sheets.filter(s => s.role === "APP" || s.role === "SMS").length > 0) && masterProducts.length > 0)
                ? "bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white hover:scale-[1.01] active:scale-[0.99] shadow-emerald-950/40"
                : "bg-slate-800/60 text-slate-500 border border-slate-800 cursor-not-allowed"
            }`}
          >
            <RefreshCw size={13} className={isValidating ? "animate-spin" : ""} />
            <span>{isValidating ? "VALIDATING..." : "VALIDATE PRODUCTS"}</span>
          </button>
        </div>
      </div>

      {/* Main content viewport */}
      <div className="flex-1 min-h-0 bg-slate-950/30 border border-slate-850/60 rounded-3xl p-5 overflow-hidden flex flex-col shadow-2xl relative">
        
        {/* --- VALIDATION IN PROGRESS SCREEN --- */}
        {isValidating && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center space-y-4">
            <div className="mx-auto w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 animate-pulse">
              <Database size={28} />
            </div>
            <div className="space-y-2 max-w-md mx-auto">
              <h3 className="text-base font-bold text-slate-100">Running Products Validation Report</h3>
              <p className="text-xs text-slate-400 leading-relaxed font-sans">
                Correlating master product records with multi-sheet transaction catalogs.
              </p>
            </div>
            <div className="w-full max-w-sm bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800 relative shadow-inner">
              <div 
                className="bg-indigo-500 h-full rounded-full transition-all duration-300 shadow-[0_0_12px_rgba(99,102,241,0.5)]" 
                style={{ width: `${validationProgress}%` }}
              />
            </div>
            <p className="text-[10px] text-slate-500 font-mono">Aggregating unique product distribution matrices: {validationProgress}%</p>
          </div>
        )}

        {/* --- SUB-TAB 4: CAS SUMMARY REPORT --- */}
        {activeSubTab === "SUMMARY" && reportRecords.length > 0 && (
          <div className="flex-1 min-h-0 flex flex-col gap-4">
            
            {/* Top Summary Controller Bar */}
            <div className="bg-slate-900/40 border border-slate-800 p-3 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0 shadow-md">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-indigo-950/80 border border-indigo-700/60 rounded-xl text-indigo-400">
                  <PieChart size={18} />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-sm font-extrabold text-slate-100 font-mono">CAS-WISE SUMMARY RECONCILIATION</h3>
                    <span className="px-2 py-0.5 text-[10px] font-black bg-indigo-950 text-indigo-300 rounded-md border border-indigo-800/60 font-mono">
                      {casWiseSummary.length} CAS Systems
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Categorized Product Breakdown across CAS vs SMS Data Sources
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto justify-end">
                {uniqueCasList.length > 0 && (
                  <div className="relative shrink-0">
                    <select
                      id="summary-cas-filter"
                      value={selectedCasFilter}
                      onChange={(e) => setSelectedCasFilter(e.target.value)}
                      className="appearance-none bg-slate-950 border border-slate-800 text-slate-300 rounded-xl pl-3 pr-8 py-1.5 text-xs focus:outline-none focus:border-indigo-500 cursor-pointer font-bold select-none h-[34px]"
                    >
                      <option value="ALL">All CAS Systems ({uniqueCasList.length})</option>
                      {uniqueCasList.map(casName => (
                        <option key={casName} value={casName}>{casName}</option>
                      ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-slate-500">
                      <svg className="fill-current h-3.5 w-3.5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                      </svg>
                    </div>
                  </div>
                )}

                <div className="relative w-full sm:w-56">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" size={12} />
                  <input
                    type="text"
                    placeholder="Search summary products..."
                    value={reportSearch}
                    onChange={(e) => setReportSearch(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-300 placeholder-slate-600 rounded-xl pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-indigo-500 h-[34px]"
                  />
                </div>

                <button
                  onClick={handleExportAllCasSummariesExcel}
                  className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-indigo-950/40 h-[34px]"
                >
                  <Download size={13} />
                  <span>EXPORT ALL (EXCEL)</span>
                </button>
                <button
                  onClick={handleExportAllCasSummariesPDF}
                  className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-indigo-950/40 h-[34px]"
                >
                  <Download size={13} />
                  <span>EXPORT ALL (PDF)</span>
                </button>
              </div>
            </div>

            {/* CAS Summary List Viewport */}
            <div className="flex-1 overflow-y-auto space-y-5 pr-1">
              {filteredCasWiseSummary.length === 0 ? (
                <div className="py-12 text-center text-slate-500 text-xs bg-slate-900/10 border border-dashed border-slate-850 rounded-2xl">
                  No CAS summary records found matching the active filter/search criteria.
                </div>
              ) : (
                filteredCasWiseSummary.map(casItem => (
                  <div key={casItem.casName} className="bg-slate-900/40 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
                    {/* CAS Section Header */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                      <div className="flex items-center space-x-3">
                        <div className="p-2.5 bg-indigo-950/80 border border-indigo-700/60 rounded-xl text-indigo-400 font-black">
                          <Layers size={18} />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className="text-sm font-extrabold text-slate-100 font-mono">
                              CAS SYSTEM: <span className="text-indigo-400">{casItem.casName}</span>
                            </h3>
                            <span className="px-2 py-0.5 text-[10px] font-black bg-slate-800 text-slate-300 rounded-md border border-slate-700 font-mono">
                              {casItem.totalProductsCount} Products Analyzed
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            CAS & SMS Product Reconciliation Breakdown
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleExportSingleCasSummaryExcel(casItem)}
                          className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer shadow-sm"
                        >
                          <Download size={13} />
                          <span>Excel</span>
                        </button>
                        <button
                          onClick={() => handleExportSingleCasSummaryPDF(casItem)}
                          className="py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer shadow-sm"
                        >
                          <Download size={13} />
                          <span>PDF</span>
                        </button>
                      </div>
                    </div>

                    {/* 5 Category Summary Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                      {/* 1. CAS & SMS Matched Products */}
                      <CasWiseCategoryBox
                        title="CAS & SMS Matched"
                        badgeCount={casItem.matched.length}
                        badgeBg="bg-emerald-950/80"
                        badgeText="text-emerald-300"
                        borderColor="border-emerald-800/60"
                        icon={<CheckCircle2 size={16} className="text-emerald-400" />}
                        products={casItem.matched}
                        type="matched"
                      />

                      {/* 2. CAS File Unique Products */}
                      <CasWiseCategoryBox
                        title="CAS File Unique Products"
                        badgeCount={casItem.casUnique.length}
                        badgeBg="bg-teal-950/80"
                        badgeText="text-teal-300"
                        borderColor="border-teal-800/60"
                        icon={<FileCheck size={16} className="text-teal-400" />}
                        products={casItem.casUnique}
                        type="casUnique"
                      />

                      {/* 3. SMS File Unique Products */}
                      <CasWiseCategoryBox
                        title="SMS File Unique Products"
                        badgeCount={casItem.smsUnique.length}
                        badgeBg="bg-violet-950/80"
                        badgeText="text-violet-300"
                        borderColor="border-violet-800/60"
                        icon={<FileCheck2 size={16} className="text-violet-400" />}
                        products={casItem.smsUnique}
                        type="smsUnique"
                      />

                      {/* 4. CAS Only Products */}
                      <CasWiseCategoryBox
                        title="CAS Only Products"
                        badgeCount={casItem.casOnly.length}
                        badgeBg="bg-amber-950/80"
                        badgeText="text-amber-300"
                        borderColor="border-amber-800/60"
                        icon={<AlertTriangle size={16} className="text-amber-400" />}
                        products={casItem.casOnly}
                        type="casOnly"
                      />

                      {/* 5. SMS Only Products */}
                      <CasWiseCategoryBox
                        title="SMS Only Products"
                        badgeCount={casItem.smsOnly.length}
                        badgeBg="bg-rose-950/80"
                        badgeText="text-rose-300"
                        borderColor="border-rose-800/60"
                        icon={<XCircle size={16} className="text-rose-400" />}
                        products={casItem.smsOnly}
                        type="smsOnly"
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}


        {/* --- SUB-TAB: VALIDATION READY / EMPTY DASHBOARD --- */}
        {activeSubTab === "REPORT" && reportRecords.length === 0 && !isValidating && (
          <div className="flex-1 min-h-0 flex flex-col items-center justify-center p-6 text-center space-y-6 max-w-2xl mx-auto overflow-y-auto">
            <div className="p-4 bg-slate-900/90 rounded-3xl border border-slate-800 text-indigo-400 shadow-2xl">
              <ShoppingBag size={38} />
            </div>
            <div className="space-y-1.5">
              <h3 className="text-base font-black uppercase tracking-wider text-slate-100">
                Products Validation Workspace
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed max-w-md">
                Cross-correlate active products between CAS and SMS/APP source files using your central Product Master catalog.
              </p>
            </div>

            {/* Checklist of Prerequisites */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 w-full text-left">
              {/* Card 1: Common Source Files */}
              <div className={`p-4 rounded-2xl border transition-all ${
                sheets.some(s => s.role === "CAS") && sheets.some(s => s.role === "APP" || s.role === "SMS")
                  ? "bg-emerald-950/20 border-emerald-500/30 text-slate-200"
                  : "bg-slate-900/50 border-slate-800 text-slate-400"
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">1. Source Files</span>
                  {sheets.some(s => s.role === "CAS") && sheets.some(s => s.role === "APP" || s.role === "SMS") ? (
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">Ready</span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">Action Needed</span>
                  )}
                </div>
                <p className="text-xs font-bold text-slate-200">
                  {sheets.filter(s => s.role === "CAS").length} CAS • {sheets.filter(s => s.role === "APP" || s.role === "SMS").length} SMS/APP Sheets
                </p>
                <p className="text-[10.5px] text-slate-500 mt-1">
                  Common transaction files & attached logic
                </p>
                {onNavigateToTab && (
                  <button
                    type="button"
                    onClick={() => onNavigateToTab("DATA_UPLOAD")}
                    className="mt-3 text-[11px] font-bold text-indigo-400 hover:text-indigo-300 underline underline-offset-4 cursor-pointer inline-flex items-center gap-1"
                  >
                    <span>Go to DATA UPLOAD</span>
                    <span>→</span>
                  </button>
                )}
              </div>

              {/* Card 2: Product Master Catalog */}
              <div className={`p-4 rounded-2xl border transition-all ${
                masterProducts.length > 0
                  ? "bg-emerald-950/20 border-emerald-500/30 text-slate-200"
                  : "bg-slate-900/50 border-slate-800 text-slate-400"
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">2. Master Catalog</span>
                  {masterProducts.length > 0 ? (
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">Ready</span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">Action Needed</span>
                  )}
                </div>
                <p className="text-xs font-bold text-slate-200">
                  {masterProducts.length > 0 ? `${masterProducts.length.toLocaleString()} Master Products` : "Catalog not loaded"}
                </p>
                <p className="text-[10.5px] text-slate-500 mt-1">
                  Catalog headers and broadcaster mapping
                </p>
                {onNavigateToTab && (
                  <button
                    type="button"
                    onClick={() => onNavigateToTab("PRODUCT_MASTER")}
                    className="mt-3 text-[11px] font-bold text-indigo-400 hover:text-indigo-300 underline underline-offset-4 cursor-pointer inline-flex items-center gap-1"
                  >
                    <span>Go to PRODUCT MASTER DATA</span>
                    <span>→</span>
                  </button>
                )}
              </div>
            </div>

            {/* Launch Button */}
            <button
              type="button"
              onClick={runReportsValidation}
              disabled={(sheets.filter(s => s.role === "CAS").length === 0 && sheets.filter(s => s.role === "APP" || s.role === "SMS").length === 0) || masterProducts.length === 0 || isValidating}
              className={`py-3 px-7 rounded-2xl text-xs font-black tracking-wider transition-all flex items-center space-x-2.5 shadow-xl ${
                ((sheets.filter(s => s.role === "CAS").length > 0 || sheets.filter(s => s.role === "APP" || s.role === "SMS").length > 0) && masterProducts.length > 0)
                  ? "bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-emerald-950/50 hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                  : "bg-slate-800/50 text-slate-500 border border-slate-800/80 cursor-not-allowed"
              }`}
            >
              <RefreshCw size={15} className={isValidating ? "animate-spin" : ""} />
              <span>VALIDATE PRODUCTS NOW</span>
            </button>
          </div>
        )}

        {/* --- SUB-TAB 3: VALIDATION SUMMARY REPORT & ACCORDIONS --- */}
        {activeSubTab === "REPORT" && reportRecords.length > 0 && (
          <div className="flex-1 min-h-0 flex flex-col gap-4.5">
            
            {/* Top Stats Banner */}
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 shrink-0">
              <div className="bg-slate-900/40 border border-slate-850 p-3 rounded-2xl">
                <p className="text-[10px] uppercase font-bold text-slate-500">Alignment Rate</p>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className={`text-xl font-black font-mono ${stats.rate === 100 ? "text-emerald-400" : "text-amber-400"}`}>
                    {stats.rate}%
                  </span>
                  <span className="text-[10px] text-slate-500">{stats.aligned}/{stats.total} IDs</span>
                </div>
              </div>

              <div className="bg-slate-900/40 border border-slate-850 p-3 rounded-2xl">
                <p className="text-[10px] uppercase font-bold text-slate-500">Mismatched Products</p>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className={`text-xl font-black font-mono ${stats.mismatched > 0 ? "text-rose-400" : "text-slate-400"}`}>
                    {stats.mismatched}
                  </span>
                  <span className="text-[10px] text-slate-500">need sync</span>
                </div>
              </div>

              <div className="bg-slate-900/40 border border-slate-850 p-3 rounded-2xl">
                <p className="text-[10px] uppercase font-bold text-slate-500">CAS Total Instances</p>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-black font-mono text-emerald-400">{stats.totalCasActive}</span>
                  <span className="text-[10px] text-slate-500">tags</span>
                </div>
              </div>

              <div className="bg-slate-900/40 border border-slate-850 p-3 rounded-2xl">
                <p className="text-[10px] uppercase font-bold text-slate-500">SMS Total Instances</p>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-black font-mono text-violet-400">{stats.totalAppActive}</span>
                  <span className="text-[10px] text-slate-500">tags</span>
                </div>
              </div>

              <div className="bg-slate-900/40 border border-slate-850 p-3 rounded-2xl col-span-2 lg:col-span-1">
                <p className="text-[10px] uppercase font-bold text-slate-500">Broadcasters Active</p>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-black font-mono text-indigo-400">{Object.keys(groupedReport).length}</span>
                  <span className="text-[10px] text-slate-500">networks</span>
                </div>
              </div>
            </div>

            {/* Filter and Export Controller */}
            <div className="bg-slate-900/30 border border-slate-850 p-3 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3 shrink-0 shadow-md">
              <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
                <button
                  onClick={() => setReportFilter("ALL")}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold tracking-wide transition border cursor-pointer select-none ${
                    reportFilter === "ALL"
                      ? "bg-indigo-500/10 text-indigo-300 border-indigo-500/30"
                      : "bg-slate-950/40 text-slate-400 border-slate-850/80 hover:bg-slate-900/50 hover:text-slate-300"
                  }`}
                >
                  All Products ({stats.total})
                </button>
                <button
                  onClick={() => setReportFilter("ALIGNED")}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold tracking-wide transition border cursor-pointer select-none ${
                    reportFilter === "ALIGNED"
                      ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"
                      : "bg-slate-950/40 text-slate-400 border-slate-850/80 hover:bg-slate-900/50 hover:text-slate-300"
                  }`}
                >
                  Aligned ({stats.aligned})
                </button>
                <button
                  onClick={() => setReportFilter("MISMATCH")}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold tracking-wide transition border cursor-pointer select-none ${
                    reportFilter === "MISMATCH"
                      ? "bg-rose-500/10 text-rose-300 border-rose-500/30"
                      : "bg-slate-950/40 text-slate-400 border-slate-850/80 hover:bg-slate-900/50 hover:text-slate-300"
                  }`}
                >
                  Mismatches ({stats.mismatched})
                </button>

                <div className="w-[1px] h-3.5 bg-slate-850 mx-1 hidden sm:block" />

                <label className="flex items-center gap-2 px-3 py-1.5 bg-slate-950/40 border border-slate-850/80 rounded-xl text-[10px] font-bold text-slate-400 hover:text-slate-200 cursor-pointer transition select-none">
                  <input
                    type="checkbox"
                    checked={useUniqueOnly}
                    onChange={(e) => setUseUniqueOnly(e.target.checked)}
                    className="accent-indigo-500 rounded cursor-pointer w-3.5 h-3.5 bg-slate-950 border border-slate-800"
                  />
                  <span>Unique IDs Only</span>
                </label>

                <label className="flex items-center gap-2 px-3 py-1.5 bg-slate-950/40 border border-slate-850/80 rounded-xl text-[10px] font-bold text-slate-400 hover:text-slate-200 cursor-pointer transition select-none">
                  <input
                    type="checkbox"
                    checked={bothNoValue}
                    onChange={(e) => setBothNoValue(e.target.checked)}
                    className="accent-indigo-500 rounded cursor-pointer w-3.5 h-3.5 bg-slate-950 border border-slate-800"
                  />
                  <span>Both No Value</span>
                </label>

                <label className="flex items-center gap-2 px-3 py-1.5 bg-slate-950/40 border border-slate-850/80 rounded-xl text-[10px] font-bold text-amber-300 hover:text-amber-200 cursor-pointer transition select-none">
                  <input
                    type="checkbox"
                    id="products-zero-product-checkbox"
                    checked={ignoreZeroProductEnabled}
                    onChange={(e) => setIgnoreZeroProductEnabled(e.target.checked)}
                    className="accent-amber-500 rounded cursor-pointer w-3.5 h-3.5 bg-slate-950 border border-slate-800"
                  />
                  <span>Exclude '0' Product</span>
                </label>
              </div>

              <div className="flex items-center gap-3 w-full md:w-auto justify-end">
                {uniqueCasList.length > 0 && (
                  <div className="relative shrink-0">
                    <select
                      id="cas-system-filter"
                      value={selectedCasFilter}
                      onChange={(e) => setSelectedCasFilter(e.target.value)}
                      className="appearance-none bg-slate-950 border border-slate-850 text-slate-300 rounded-xl pl-3 pr-8 py-1.5 text-[10px] focus:outline-none focus:border-indigo-500 cursor-pointer font-bold select-none h-[30px]"
                    >
                      <option value="ALL">All CAS Systems</option>
                      {uniqueCasList.map(casName => (
                        <option key={casName} value={casName}>{casName}</option>
                      ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-slate-500">
                      <svg className="fill-current h-3 w-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                      </svg>
                    </div>
                  </div>
                )}

                <div className="relative w-full md:w-48">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" size={11} />
                  <input
                    type="text"
                    placeholder="Search results..."
                    value={reportSearch}
                    onChange={(e) => setReportSearch(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 text-slate-300 placeholder-slate-600 rounded-xl pl-8 pr-3 py-1.5 text-[10px] focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={handleExportCSV}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-[10px] font-extrabold text-slate-300 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download size={11} />
                    <span>CSV</span>
                  </button>
                  <button
                    onClick={handleExportExcel}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-[10px] font-extrabold text-white rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-950/30"
                  >
                    <Download size={11} />
                    <span>EXCEL</span>
                  </button>
                  <button
                    onClick={handleExportPDF}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-[10px] font-extrabold text-white rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-950/30"
                  >
                    <Download size={11} />
                    <span>PDF</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Broadcaster Product Details Accordions Viewport */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {Object.keys(groupedReport).length === 0 ? (
                <div className="py-12 text-center text-slate-500 text-xs bg-slate-900/10 border border-dashed border-slate-850 rounded-2xl">
                  No matching products or unmapped entries detected with the active filters.
                </div>
              ) : (
                Object.keys(groupedReport)
                  .sort((a, b) => {
                    // Always put unmapped section at the very bottom
                    if (a.includes("Unmapped Products")) return 1;
                    if (b.includes("Unmapped Products")) return -1;
                    return a.localeCompare(b);
                  })
                  .map(broadcasterName => {
                    const productsList = groupedReport[broadcasterName];
                    const isExpanded = expandedBroadcasters[broadcasterName];
                    const discCount = productsList.filter(p => !p.isAligned).length;

                    return (
                      <div 
                        key={broadcasterName}
                        className="bg-slate-900/35 border border-slate-850 rounded-2xl overflow-hidden shadow-sm"
                      >
                        {/* Header bar */}
                        <div 
                          onClick={() => setExpandedBroadcasters(prev => ({ ...prev, [broadcasterName]: !isExpanded }))}
                          className="p-3 bg-slate-950/35 hover:bg-slate-900/50 transition flex items-center justify-between gap-4 cursor-pointer select-none"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span className="p-1 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shrink-0">
                              <ShoppingBag size={11} />
                            </span>
                            <span className="text-xs font-extrabold text-slate-100 truncate">{broadcasterName}</span>
                            <span className="text-[10px] bg-slate-900 text-slate-400 font-mono font-bold px-1.5 py-0.2 rounded border border-slate-800">
                              {productsList.length} Prods
                            </span>
                            {discCount > 0 && (
                              <span className="px-1.5 py-0.2 text-[9px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/25 rounded flex items-center gap-1 shrink-0">
                                <AlertTriangle size={10} />
                                <span>{discCount} Mismatches</span>
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleExportBroadcasterCSV(broadcasterName, productsList);
                              }}
                              className="px-2 py-1 bg-slate-900/90 hover:bg-slate-800 border border-slate-800/80 hover:border-slate-700 text-[9px] font-extrabold text-slate-300 rounded-lg transition flex items-center gap-1 cursor-pointer select-none"
                              title="Export Broadcaster CSV"
                            >
                              <Download size={10} />
                              <span>CSV</span>
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleExportBroadcasterPDF(broadcasterName, productsList);
                              }}
                              className="px-2 py-1 bg-indigo-600/90 hover:bg-indigo-600 border border-indigo-500/55 hover:border-indigo-400 text-[9px] font-extrabold text-white rounded-lg transition flex items-center gap-1 cursor-pointer select-none shadow-sm"
                              title="Export Broadcaster PDF"
                            >
                              <FileSpreadsheet size={10} />
                              <span>PDF</span>
                            </button>
                            <div className="w-[1px] h-3 bg-slate-800 mx-1" />
                            <div className="text-slate-500">
                              {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                            </div>
                          </div>
                        </div>

                        {/* Accordion Table content */}
                        {isExpanded && (
                          <div className="p-2 bg-slate-950/20 border-t border-slate-900 overflow-x-auto">
                            <table className="w-full text-left border-collapse min-w-[650px]">
                              <thead>
                                <tr className="bg-slate-950/50 border-b border-slate-850/80 text-[8.5px] uppercase font-black tracking-wider text-slate-400">
                                  <th className="py-2 px-4">Product ID</th>
                                  <th className="py-2 px-4">Product Name</th>
                                  <th className="py-2 px-4 text-center">CAS System / Code</th>
                                  <th className="py-2 px-4 text-center">CAS (C) Count</th>
                                  <th className="py-2 px-4 text-center">SMS (S) Count</th>
                                  <th className="py-2 px-4 text-center">Difference</th>
                                  <th className="py-2 px-4 text-center">Status</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-900/60 text-xs">
                                {productsList.map((p, idx) => {
                                  const isAligned = p.isAligned;
                                  return (
                                    <tr 
                                      key={`${p.productId}-${idx}`}
                                      className={`hover:bg-slate-900/40 transition-colors ${!isAligned ? "bg-amber-500/[0.015]" : ""}`}
                                    >
                                      {/* Product ID */}
                                      <td className="py-2 px-4 font-mono font-bold text-slate-300">{p.productId}</td>
                                      
                                      {/* Product Name */}
                                      <td className={`py-2 px-4 font-semibold ${p.isUnmapped ? "text-slate-500 italic" : "text-slate-200"}`}>
                                        {p.productName}
                                      </td>

                                      {/* CAS */}
                                      <td className="py-2 px-4 text-center text-slate-400 font-mono">{p.cas}</td>

                                      {/* CAS Count */}
                                      <td className="py-2 px-4 text-center font-mono">
                                        {p.casCount > 0 ? (
                                          <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20">{p.casCount} rows</span>
                                        ) : (
                                          <span className="text-slate-600">—</span>
                                        )}
                                      </td>

                                      {/* APP Count */}
                                      <td className="py-2 px-4 text-center font-mono">
                                        {p.appCount > 0 ? (
                                          <span className="px-2 py-0.5 rounded bg-violet-500/10 text-violet-400 font-bold border border-violet-500/20">{p.appCount} rows</span>
                                        ) : (
                                          <span className="text-slate-600">—</span>
                                        )}
                                      </td>

                                      {/* Difference */}
                                      <td 
                                        onClick={() => {
                                          setModalSearch("");
                                          setModalFilter("ALL");
                                          setModalPage(1);
                                          setSelectedProductDetails({
                                            productId: p.productId,
                                            productName: p.productName,
                                            cas: p.cas,
                                            broadcaster: p.broadcaster,
                                            diff: p.diff,
                                            casCount: p.casCount,
                                            appCount: p.appCount
                                          });
                                        }}
                                        className="py-2 px-4 text-center font-mono cursor-pointer group"
                                        title="Click to view card keys audit list"
                                      >
                                        <div className="flex flex-col items-center justify-center space-y-1">
                                          <div className="inline-flex items-center space-x-1 px-2 py-1 rounded bg-slate-950/40 group-hover:bg-slate-800 border border-slate-850 group-hover:border-indigo-500/30 transition-all font-bold">
                                            {p.diff === 0 ? (
                                              <span className="text-slate-500">0</span>
                                            ) : p.diff > 0 ? (
                                              <span className="text-emerald-400">+{p.diff}</span>
                                            ) : (
                                              <span className="text-rose-400">{p.diff}</span>
                                            )}
                                            <span className="text-[9px] font-bold text-slate-500 group-hover:text-indigo-400 transition font-sans">View</span>
                                          </div>
                                          {((p.casOnlyCount !== undefined && p.casOnlyCount > 0) || (p.appOnlyCount !== undefined && p.appOnlyCount > 0)) && (
                                            <div className="flex items-center gap-1.5 text-[9px] font-bold text-slate-400 bg-slate-950/20 px-1.5 py-0.5 rounded border border-slate-900/40">
                                              <span className="text-emerald-400">C: {p.casOnlyCount || 0}</span>
                                              <span className="text-slate-600">|</span>
                                              <span className="text-violet-400">S: {p.appOnlyCount || 0}</span>
                                            </div>
                                          )}
                                        </div>
                                      </td>

                                      {/* Alignment status */}
                                      <td className="py-2 px-4 text-center">
                                        {isAligned ? (
                                          <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-500/10 text-emerald-400 border border-emerald-500/25">
                                            <CheckCircle2 size={10} />
                                            <span>ALIGNED</span>
                                          </span>
                                        ) : (
                                          <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded text-[9px] font-black bg-amber-500/10 text-amber-400 border border-amber-500/25">
                                            <AlertTriangle size={10} />
                                            <span>DISCREPANCY</span>
                                          </span>
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    );
                  })
              )}
            </div>
          </div>
        )}

      </div>

      {/* Selected Product Card Keys Detail Modal */}
      <AnimatePresence>
        {selectedProductDetails && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl w-full max-w-4xl h-[80vh] flex flex-col overflow-hidden text-slate-200"
            >
              {/* Header */}
              <div className="p-4 bg-slate-950/40 border-b border-slate-800 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shrink-0">
                    <ShoppingBag size={16} />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-extrabold text-white flex flex-wrap items-center gap-2">
                      <span>Product Card Keys Audit Detail</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-slate-800 border border-slate-750 text-slate-300 font-mono">
                        ID: {selectedProductDetails.productId}
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5 font-medium truncate">
                      {selectedProductDetails.productName} ({selectedProductDetails.broadcaster})
                    </p>
                  </div>
                </div>
                
                <button
                  onClick={() => setSelectedProductDetails(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 transition cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Stats Bar */}
              <div className="p-3 bg-slate-900/30 border-b border-slate-850 grid grid-cols-2 sm:grid-cols-5 gap-2.5 shrink-0 text-xs">
                <div className="bg-slate-950/40 border border-slate-850/80 p-2.5 rounded-xl text-center">
                  <p className="text-[10px] text-slate-500 uppercase font-black tracking-wider">In CAS (C) Rows</p>
                  <p className="text-sm font-black text-emerald-400 font-mono mt-0.5">{selectedProductDetails.casCount} rows</p>
                </div>
                <div className="bg-slate-950/40 border border-slate-850/80 p-2.5 rounded-xl text-center">
                  <p className="text-[10px] text-slate-500 uppercase font-black tracking-wider">In SMS (S) Rows</p>
                  <p className="text-sm font-black text-violet-400 font-mono mt-0.5">{selectedProductDetails.appCount} rows</p>
                </div>
                <div className="bg-slate-950/40 border border-slate-850/80 p-2.5 rounded-xl text-center border-l-2 border-l-emerald-500/50">
                  <p className="text-[10px] text-emerald-500 uppercase font-black tracking-wider">CAS ONLY Keys</p>
                  <p className="text-sm font-black text-emerald-400 font-mono mt-0.5">
                    {selectedProductKeys.filter(k => k.status === "ONLY_CAS").length} cards
                  </p>
                </div>
                <div className="bg-slate-950/40 border border-slate-850/80 p-2.5 rounded-xl text-center border-l-2 border-l-violet-500/50">
                  <p className="text-[10px] text-violet-500 uppercase font-black tracking-wider">SMS ONLY Keys</p>
                  <p className="text-sm font-black text-violet-400 font-mono mt-0.5">
                    {selectedProductKeys.filter(k => k.status === "ONLY_APP").length} cards
                  </p>
                </div>
                <div className="col-span-2 sm:col-span-1 bg-slate-950/40 border border-slate-850/80 p-2.5 rounded-xl text-center">
                  <p className="text-[10px] text-slate-500 uppercase font-black tracking-wider">Net Difference</p>
                  <p className={`text-sm font-black font-mono mt-0.5 ${
                    selectedProductDetails.diff === 0 
                      ? "text-slate-400" 
                      : selectedProductDetails.diff > 0 
                        ? "text-emerald-400" 
                        : "text-rose-400"
                  }`}>
                    {selectedProductDetails.diff > 0 ? `+${selectedProductDetails.diff}` : selectedProductDetails.diff}
                  </p>
                </div>
              </div>

              {/* Toolbar */}
              <div className="p-3.5 bg-slate-900 border-b border-slate-850 flex flex-col gap-3 shrink-0">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" size={13} />
                    <input
                      type="text"
                      placeholder="Search card ID / VC Number..."
                      value={modalSearch}
                      onChange={(e) => {
                        setModalSearch(e.target.value);
                        setModalPage(1);
                      }}
                      className="w-full bg-slate-950 border border-slate-850 text-slate-300 placeholder-slate-600 rounded-xl pl-9 pr-4 py-1.5 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <button
                    onClick={exportProductKeysCSV}
                    className="px-3.5 py-1.5 bg-slate-850 hover:bg-slate-800 border border-slate-800 text-[10.5px] font-bold text-slate-300 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Download size={12} />
                    <span>EXPORT AUDIT LIST</span>
                  </button>
                </div>

                {/* Filters */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mr-1">Filter keys:</span>
                  <button
                    onClick={() => { setModalFilter("ALL"); setModalPage(1); }}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition border cursor-pointer ${
                      modalFilter === "ALL"
                        ? "bg-slate-800 text-indigo-300 border-indigo-500/30"
                        : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-850/40"
                    }`}
                  >
                    All Keys ({selectedProductKeys.length})
                  </button>
                  <button
                    onClick={() => { setModalFilter("MISMATCH"); setModalPage(1); }}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition border cursor-pointer ${
                      modalFilter === "MISMATCH"
                        ? "bg-slate-800 text-amber-300 border-amber-500/30"
                        : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-850/40"
                    }`}
                  >
                    Mismatches ({selectedProductKeys.filter(k => k.status !== "MATCH").length})
                  </button>
                  <button
                    onClick={() => { setModalFilter("ONLY_CAS"); setModalPage(1); }}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition border cursor-pointer ${
                      modalFilter === "ONLY_CAS"
                        ? "bg-slate-800 text-emerald-300 border-emerald-500/30"
                        : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-850/40"
                    }`}
                  >
                    In CAS Only ({selectedProductKeys.filter(k => k.status === "ONLY_CAS").length})
                  </button>
                  <button
                    onClick={() => { setModalFilter("ONLY_APP"); setModalPage(1); }}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition border cursor-pointer ${
                      modalFilter === "ONLY_APP"
                        ? "bg-slate-800 text-violet-300 border-violet-500/30"
                        : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-850/40"
                    }`}
                  >
                    In SMS Only ({selectedProductKeys.filter(k => k.status === "ONLY_APP").length})
                  </button>
                  <button
                    onClick={() => { setModalFilter("MATCH"); setModalPage(1); }}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition border cursor-pointer ${
                      modalFilter === "MATCH"
                        ? "bg-slate-800 text-slate-300 border-slate-700"
                        : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-850/40"
                    }`}
                  >
                    Matched ({selectedProductKeys.filter(k => k.status === "MATCH").length})
                  </button>
                </div>
              </div>

              {/* Table Body */}
              <div className="flex-1 overflow-x-auto min-h-0 bg-slate-950/15">
                <table className="w-full text-left border-collapse min-w-[550px]">
                  <thead>
                    <tr className="bg-slate-950/40 border-b border-slate-850 text-[9px] uppercase font-bold tracking-wider text-slate-400">
                      <th className="py-2.5 px-5">Card ID / VC Number</th>
                      <th className="py-2.5 px-4 text-center">In CAS</th>
                      <th className="py-2.5 px-4 text-center">In SMS</th>
                      <th className="py-2.5 px-4 text-center">Audit Status</th>
                      <th className="py-2.5 px-5">Associated Sheet Files</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850/60 font-sans text-xs">
                    {paginatedModalKeys.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-500">
                          No cards match the active search and filter criteria.
                        </td>
                      </tr>
                    ) : (
                      paginatedModalKeys.map((item) => {
                        return (
                          <tr
                            key={item.key}
                            className={`hover:bg-slate-800/25 transition ${
                              item.status !== "MATCH" ? "bg-amber-500/[0.012]" : ""
                            }`}
                          >
                            <td className="py-2 px-5 font-mono font-bold text-slate-300 whitespace-nowrap">
                              {item.key}
                            </td>
                            <td className="py-2 px-4 text-center whitespace-nowrap">
                              {item.inCas ? (
                                <span className="inline-flex px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 font-bold font-mono text-[10px] border border-emerald-500/20">
                                  YES
                                </span>
                              ) : (
                                <span className="text-slate-600 font-mono">—</span>
                              )}
                            </td>
                            <td className="py-2 px-4 text-center whitespace-nowrap">
                              {item.inApp ? (
                                <span className="inline-flex px-1.5 py-0.2 rounded bg-violet-500/10 text-violet-400 font-bold font-mono text-[10px] border border-violet-500/20">
                                  YES
                                </span>
                              ) : (
                                <span className="text-slate-600 font-mono">—</span>
                              )}
                            </td>
                            <td className="py-2 px-4 text-center whitespace-nowrap">
                              {item.status === "MATCH" ? (
                                <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-500/10 text-emerald-400 border border-emerald-500/25">
                                  <CheckCircle2 size={10} />
                                  <span>ALIGNED</span>
                                </span>
                              ) : item.status === "ONLY_CAS" ? (
                                <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded text-[9px] font-black bg-amber-500/10 text-amber-400 border border-amber-500/25">
                                  <AlertTriangle size={10} />
                                  <span>CAS ONLY</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center space-x-1 px-1.5 py-0.2 rounded text-[9px] font-black bg-violet-500/10 text-violet-400 border border-violet-500/25">
                                  <AlertTriangle size={10} />
                                  <span>SMS ONLY</span>
                                </span>
                              )}
                            </td>
                            <td className="py-2 px-5 text-slate-400 font-sans text-[11px]">
                              {item.inCas && item.casSheets.length > 0 && (
                                <div className="truncate" title={`CAS Files: ${item.casSheets.join(", ")}`}>
                                  <strong className="text-slate-500 text-[10px]">CAS:</strong> {item.casSheets.join(", ")}
                                </div>
                              )}
                              {item.inApp && item.appSheets.length > 0 && (
                                <div className="truncate" title={`SMS Files: ${item.appSheets.join(", ")}`}>
                                  <strong className="text-slate-500 text-[10px]">SMS:</strong> {item.appSheets.join(", ")}
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Pagination Footer */}
              <div className="p-3 bg-slate-950/40 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-400 text-[11px] shrink-0 select-none">
                <div>
                  Showing <span className="font-bold text-slate-300">{startModalRecordIdx}</span> to{" "}
                  <span className="font-bold text-slate-300">{endModalRecordIdx}</span> of{" "}
                  <span className="font-bold text-slate-300">{totalModalRecords}</span> matching keys
                </div>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => setModalPage(1)}
                    disabled={activeModalPage === 1}
                    className="p-1 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 border border-slate-800 rounded-lg text-slate-300 transition disabled:cursor-not-allowed cursor-pointer"
                    title="First Page"
                  >
                    <ChevronsLeft size={13} />
                  </button>
                  <button
                    onClick={() => setModalPage(prev => Math.max(1, prev - 1))}
                    disabled={activeModalPage === 1}
                    className="p-1 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 border border-slate-800 rounded-lg text-slate-300 transition disabled:cursor-not-allowed cursor-pointer"
                    title="Previous Page"
                  >
                    <ChevronLeft size={13} />
                  </button>

                  <div className="px-2.5 py-0.5 bg-slate-950 rounded-lg border border-slate-850 font-mono">
                    Page <span className="font-bold text-slate-200">{activeModalPage}</span> of{" "}
                    <span className="font-bold text-slate-400">{totalModalPages}</span>
                  </div>

                  <button
                    onClick={() => setModalPage(prev => Math.min(totalModalPages, prev + 1))}
                    disabled={activeModalPage === totalModalPages}
                    className="p-1 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 border border-slate-800 rounded-lg text-slate-300 transition disabled:cursor-not-allowed cursor-pointer"
                    title="Next Page"
                  >
                    <ChevronRight size={13} />
                  </button>
                  <button
                    onClick={() => setModalPage(totalModalPages)}
                    disabled={activeModalPage === totalModalPages}
                    className="p-1 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 border border-slate-800 rounded-lg text-slate-300 transition disabled:cursor-not-allowed cursor-pointer"
                    title="Last Page"
                  >
                    <ChevronsRight size={13} />
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>



      {/* Dynamic Printable PDF Executive Report Layer */}
      {printData && createPortal(
        <div id="print-root" className="font-sans text-black bg-white p-8">
          <div style={{ borderBottom: "2px solid #334155", paddingBottom: "16px", marginBottom: "24px" }}>
            <h1 style={{ fontSize: "24px", fontWeight: "bold", color: "#1e293b", margin: 0 }}>
              BROADCASTER VALIDATION REPORT
            </h1>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "24px", fontSize: "12px", color: "#334155" }}>
            <div>
              <p style={{ margin: "4px 0" }}><strong>Broadcaster Network:</strong> {printData.broadcasterName}</p>
              <p style={{ margin: "4px 0" }}><strong>Generated on:</strong> {new Date().toLocaleString()}</p>
              <p style={{ margin: "4px 0" }}><strong>Active CAS System:</strong> {Array.from(appCasSystems).join(", ") || "All CAS Systems"}</p>
              <p style={{ margin: "4px 0" }}><strong>Unique IDs Only:</strong> {useUniqueOnly ? "Enabled (De-duplicated VC_NUMBER instances)" : "Disabled (Raw record counts)"}</p>
              <p style={{ margin: "4px 0" }}><strong>Both No Value:</strong> {bothNoValue ? "Hidden (Excluding items with zero CAS/SMS counts)" : "Shown"}</p>
            </div>
            <div style={{ textAlign: "right" }}>
              <p style={{ margin: "4px 0" }}><strong>Total Products Listed:</strong> {printData.list.length}</p>
              <p style={{ margin: "4px 0" }}><strong>Aligned Products:</strong> {printData.list.filter(p => p.isAligned).length}</p>
              <p style={{ margin: "4px 0" }}><strong>Mismatched Products:</strong> {printData.list.filter(p => !p.isAligned).length}</p>
              <p style={{ margin: "4px 0" }}><strong>Overall Alignment rate:</strong> {printData.list.length > 0 ? Math.round((printData.list.filter(p => p.isAligned).length / printData.list.length) * 100) : 0}%</p>
            </div>
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "16px", fontSize: "11px", textAlign: "left" }}>
            <thead>
              <tr style={{ background: "#f8fafc", borderBottom: "2px solid #cbd5e1" }}>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569" }}>Product ID</th>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569" }}>Product Name</th>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569" }}>CAS Code</th>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569", textAlign: "center" }}>CAS Count</th>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569", textAlign: "center" }}>SMS Count</th>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569", textAlign: "center" }}>Diff</th>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569", textAlign: "center" }}>CAS Only</th>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569", textAlign: "center" }}>SMS Only</th>
                <th style={{ padding: "10px 8px", fontWeight: "bold", color: "#475569", textAlign: "center" }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {printData.list.map((p, idx) => (
                <tr key={`${p.productId}-${idx}`} style={{ borderBottom: "1px solid #e2e8f0", background: idx % 2 === 0 ? "#ffffff" : "#fafafa" }}>
                  <td style={{ padding: "8px", fontFamily: "monospace", fontWeight: "bold" }}>{p.productId}</td>
                  <td style={{ padding: "8px" }}>{p.productName}</td>
                  <td style={{ padding: "8px", fontFamily: "monospace" }}>{p.cas || "—"}</td>
                  <td style={{ padding: "8px", textAlign: "center" }}>{p.casCount}</td>
                  <td style={{ padding: "8px", textAlign: "center" }}>{p.appCount}</td>
                  <td style={{ padding: "8px", textAlign: "center", fontWeight: "bold", color: p.diff === 0 ? "#1e293b" : p.diff > 0 ? "#15803d" : "#b91c1c" }}>
                    {p.diff === 0 ? "0" : p.diff > 0 ? `+${p.diff}` : p.diff}
                  </td>
                  <td style={{ padding: "8px", textAlign: "center", color: "#166534" }}>{p.casOnlyCount || 0}</td>
                  <td style={{ padding: "8px", textAlign: "center", color: "#6b21a8" }}>{p.appOnlyCount || 0}</td>
                  <td style={{ padding: "8px", textAlign: "center" }}>
                    <span style={{
                      padding: "2px 6px",
                      borderRadius: "4px",
                      fontSize: "9px",
                      fontWeight: "bold",
                      background: p.isAligned ? "#dcfce7" : "#fee2e2",
                      color: p.isAligned ? "#166534" : "#991b1b"
                    }}>
                      {p.isAligned ? "ALIGNED" : "MISMATCH"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{ marginTop: "40px", borderTop: "1px solid #e2e8f0", paddingTop: "12px", textAlign: "center", fontSize: "10px", color: "#94a3b8" }}>
            This is an automated system audit report generated by Sumavision Data Validation Tool. Page 1 of 1.
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
