import React, { useState, useRef, useEffect } from "react";
import { 
  Upload, 
  FileSpreadsheet, 
  Trash2, 
  Settings, 
  Layers, 
  Sliders,
  FileCheck2,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Tag,
  Plus,
  ArrowRight,
  Lock,
  ShieldAlert,
  Database,
  MessageSquare
} from "lucide-react";
import { SheetState, UploadedFile, GlobalReferenceMapping, IgnoreDigitRule, StoredReferenceFile } from "../types";
import { getAllUniqueCasNames } from "../utils/casNames";
import { 
  parseExcelMultiSheet, 
} from "../utils/parser";
import { 
  loadStoredReferenceFiles, 
  addStoredReferenceFile, 
  parseReferenceSpreadsheet, 
  convertSheetToStoredReference, 
  REF_EVENT_NAME 
} from "../utils/referenceStorage";

const globalFileReferenceCache: Record<string, File> = {};

export function registerFileReference(fileId: string, file: File) {
  globalFileReferenceCache[fileId] = file;
}

export function getFileReference(fileId: string): File | undefined {
  return globalFileReferenceCache[fileId];
}

interface IgnoreDigitSelectorProps {
  sheets: SheetState[];
  enabled: boolean;
  setEnabled: (val: boolean) => void;
  rules: IgnoreDigitRule[];
  setRules: (val: IgnoreDigitRule[]) => void;
}

export function IgnoreDigitSelector({
  sheets,
  enabled,
  setEnabled,
  rules,
  setRules,
}: IgnoreDigitSelectorProps) {
  const uniqueCasList = React.useMemo<string[]>(() => {
    return getAllUniqueCasNames(sheets);
  }, [sheets]);

  const addRule = () => {
    const newRule: IgnoreDigitRule = {
      id: Math.random().toString(36).substring(2, 9),
      cas: "ALL",
      length: 10,
      direction: "BACKWARD",
      count: 1
    };
    setRules([...rules, newRule]);
  };

  const updateRule = (id: string, updates: Partial<IgnoreDigitRule>) => {
    setRules(rules.map(r => r.id === id ? { ...r, ...updates } : r));
  };

  const deleteRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
  };

  // If rules is empty, auto-add a default rule
  React.useEffect(() => {
    if (!rules || rules.length === 0) {
      setRules([{
        id: "default",
        cas: "ALL",
        length: 10,
        direction: "BACKWARD",
        count: 1
      }]);
    }
  }, [rules?.length]);

  return (
    <div className="flex flex-col gap-2.5 mt-1 bg-slate-950/40 p-3 rounded-xl border border-slate-800/40 text-[10px] select-none text-slate-300 font-medium w-full">
      <div className="flex items-center justify-between w-full border-b border-slate-900/60 pb-2">
        <label className="flex items-center space-x-1.5 bg-violet-500/10 hover:bg-violet-500/15 border border-violet-500/20 rounded px-2.5 py-1 text-[9px] font-black text-violet-300 cursor-pointer select-none tracking-normal transition-all">
          <input
            type="checkbox"
            checked={enabled}
            onChange={(e) => setEnabled(e.target.checked)}
            className="rounded border-slate-700 text-violet-600 focus:ring-violet-500 bg-slate-900 w-3 h-3 cursor-pointer"
          />
          <span>Ignore Digit Normalization</span>
        </label>
      </div>

      {enabled && (
        <div className="flex flex-col gap-2">
          {rules.map((rule, idx) => (
            <div key={rule.id} className="flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[9px] font-bold bg-slate-900/40 p-2 rounded-lg border border-slate-850/60 w-full relative group">
              <span className="text-slate-500 font-mono text-[8px] min-w-[14px]">#{idx + 1}</span>
              
              <div className="flex items-center space-x-1">
                <span className="text-slate-400 font-mono text-[8px] uppercase tracking-wider">CAS:</span>
                <select
                  value={rule.cas}
                  onChange={(e) => updateRule(rule.id, { cas: e.target.value })}
                  className="bg-slate-950 border border-slate-800/80 rounded px-1.5 py-0.5 text-slate-200 text-[9px] focus:outline-none focus:border-violet-500 font-sans cursor-pointer max-w-[120px] h-[22px]"
                >
                  <option value="ALL">ALL CAS</option>
                  {uniqueCasList.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center space-x-1">
                <span className="text-slate-400 font-mono text-[8px] uppercase tracking-wider">If VC Length &gt;</span>
                <input
                  type="number"
                  min="0"
                  value={rule.length}
                  onChange={(e) => updateRule(rule.id, { length: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-10 text-center bg-slate-950 border border-slate-800/80 rounded px-1 py-0.5 text-slate-200 text-[9px] focus:outline-none focus:border-violet-500 font-mono h-[22px]"
                />
              </div>

              <div className="flex items-center space-x-1">
                <span className="text-slate-400 font-mono text-[8px] uppercase tracking-wider">Ignore:</span>
                <select
                  value={rule.direction}
                  onChange={(e) => updateRule(rule.id, { direction: e.target.value as "FORWARD" | "BACKWARD" })}
                  className="bg-slate-950 border border-slate-800/80 rounded px-1.5 py-0.5 text-slate-200 text-[9px] focus:outline-none focus:border-violet-500 font-sans cursor-pointer h-[22px]"
                >
                  <option value="FORWARD">Forward</option>
                  <option value="BACKWARD">Backward</option>
                </select>
              </div>

              <div className="flex items-center space-x-1">
                <span className="text-slate-400 font-mono text-[8px] uppercase tracking-wider">Digits count:</span>
                <input
                  type="number"
                  min="1"
                  value={rule.count}
                  onChange={(e) => updateRule(rule.id, { count: Math.max(1, parseInt(e.target.value) || 1) })}
                  className="w-8 text-center bg-slate-950 border border-slate-800/80 rounded px-1 py-0.5 text-slate-200 text-[9px] focus:outline-none focus:border-violet-500 font-mono h-[22px]"
                />
              </div>

              <div className="flex items-center gap-1.5 ml-auto">
                {idx === rules.length - 1 && (
                  <button
                    type="button"
                    onClick={addRule}
                    className="text-orange-500 hover:text-orange-400 font-black text-2xl leading-none transition-all hover:scale-125 px-1.5 cursor-pointer"
                    title="Add Another Rule"
                  >
                    +
                  </button>
                )}

                {rules.length > 1 && (
                  <button
                    type="button"
                    onClick={() => deleteRule(rule.id)}
                    className="text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 rounded p-1 hover:scale-105 transition-all cursor-pointer"
                    title="Remove Rule"
                  >
                    <Trash2 size={10} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ==========================================
// 1. SMS UPLOAD PANEL
// ==========================================
export interface SmsUploadPanelProps {
  files: UploadedFile[];
  sheets: SheetState[];
  setFiles: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  setSheets: React.Dispatch<React.SetStateAction<SheetState[]>>;
  handleFiles: (uploadedFiles: FileList | null, targetRole: "CAS" | "SMS" | "APP", associatedCasName?: string) => Promise<void>;
  uploadProgress: { fileName: string; stage: string; percent: number; role?: "CAS" | "SMS" | "APP" } | null;
  handleRemoveFile: (fileId: string) => void;
  handleRemoveSmsFiles: () => void;
  showApp?: boolean;
  showSms?: boolean;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  continuitySheets: boolean;
  setContinuitySheets: (val: boolean) => void;
  reprocessAllContinuitySheets: (currentSheets: SheetState[], enabled: boolean) => Promise<void>;
  ignoreDigitEnabled: boolean;
  setIgnoreDigitEnabled: (val: boolean) => void;
  ignoreDigitRules: IgnoreDigitRule[];
  setIgnoreDigitRules: (val: IgnoreDigitRule[]) => void;
}

export function SmsUploadPanel({
  files,
  sheets,
  handleFiles,
  uploadProgress,
  handleRemoveFile,
  handleRemoveSmsFiles,
  showApp = true,
  showSms = false,
  isCollapsed = false,
  onToggleCollapse,
  continuitySheets,
  setContinuitySheets,
  reprocessAllContinuitySheets,
  ignoreDigitEnabled,
  setIgnoreDigitEnabled,
  ignoreDigitRules,
  setIgnoreDigitRules,
}: SmsUploadPanelProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [selectedRole, setSelectedRole] = useState<"APP" | "SMS">("APP");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const appFiles = files.filter(f => f.role === "APP");
  const smsFiles = files.filter(f => f.role === "SMS");
  const allSmsFiles = files.filter(f => f.role === "APP" || f.role === "SMS");
  const allSmsSheets = sheets.filter(s => s.role === "APP" || s.role === "SMS");

  const activeUploadRole = showSms ? selectedRole : "APP";
  const isUploadingThis = uploadProgress && (uploadProgress.role === "APP" || uploadProgress.role === "SMS");

  return (
    <div className={`bg-slate-900/40 border border-slate-800/80 rounded-2xl p-3.5 flex flex-col h-full shadow-xl transition-all duration-300 ${
      isCollapsed ? "min-h-0 xl:w-[60px] space-y-2 p-2 items-center" : "min-h-[420px] space-y-3"
    }`}>
      {/* Header */}
      <div className={`flex items-center justify-between border-b border-slate-800 pb-2.5 shrink-0 w-full ${isCollapsed ? "flex-col gap-2 border-0 pb-0" : ""}`}>
        <div className={`flex items-center space-x-2 ${isCollapsed ? "flex-col space-x-0 gap-1.5" : ""}`}>
          <div className="p-1.5 rounded-lg bg-violet-500/10 border border-violet-500/20 text-violet-400">
            <MessageSquare size={14} />
          </div>
          {!isCollapsed && (
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <span>1. SMS UPLOAD</span>
              </h3>
              <p className="text-[10px] text-slate-400">Drop or pick SMS Source spreadsheets</p>
            </div>
          )}
        </div>
        <div className={`flex items-center space-x-1.5 ${isCollapsed ? "flex-col space-x-0 gap-1.5" : ""}`}>
          {!isCollapsed && (
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-mono font-bold bg-violet-950/80 text-violet-300 px-2 py-0.5 rounded-md border border-violet-800/60">
                {allSmsFiles.length} Files ({allSmsSheets.length} Sheets)
              </span>
              {allSmsFiles.length > 0 && (
                <button
                  type="button"
                  onClick={handleRemoveSmsFiles}
                  className="px-2 py-0.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-md text-[9.5px] font-bold flex items-center gap-1 transition cursor-pointer"
                  title="Clear all uploaded SMS files"
                >
                  <Trash2 size={10} />
                  <span>Clear SMS</span>
                </button>
              )}
            </div>
          )}
          {onToggleCollapse && (
            <button
              type="button"
              onClick={onToggleCollapse}
              className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-violet-400 transition cursor-pointer"
              title={isCollapsed ? "Expand Panel" : "Collapse Panel"}
            >
              {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
            </button>
          )}
        </div>
      </div>

      {isCollapsed ? (
        <div className="flex-1 flex flex-col items-center justify-between py-6 select-none w-full h-full min-h-[250px]">
          <div className="flex flex-col items-center gap-1.5" title="SMS Source Files">
            <span className="text-[11px] font-black text-violet-400 font-mono tracking-widest border-b border-violet-500/30 pb-0.5 px-1">SMS</span>
            <span className="text-xs font-extrabold font-mono text-violet-400 bg-violet-500/10 border border-violet-500/20 px-2 py-0.5 rounded-lg min-w-[28px] text-center shadow-md">
              {allSmsFiles.length}
            </span>
          </div>

          <div className="flex flex-col items-center">
            <span className="text-[10.5px] uppercase font-black tracking-widest text-slate-500 [writing-mode:vertical-lr] rotate-180">
              1. SMS UPLOAD
            </span>
          </div>

          <div className="text-[9px] font-mono text-slate-500">
            {allSmsSheets.length}s
          </div>
        </div>
      ) : (
        <div className="flex-1 w-full min-h-0 flex flex-col gap-2.5 overflow-hidden">
          {/* Continuity Sheets Toggle Bar */}
          <div className="bg-slate-950/50 border border-violet-950/60 p-2 rounded-xl flex items-center justify-between shrink-0">
            <label className="flex items-center space-x-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={continuitySheets}
                onChange={(e) => {
                  const checked = e.target.checked;
                  setContinuitySheets(checked);
                  reprocessAllContinuitySheets(sheets, checked);
                }}
                className="rounded border-slate-700 text-violet-600 focus:ring-violet-500 bg-slate-900 w-3.5 h-3.5 cursor-pointer"
              />
              <div>
                <span className="text-[10.5px] font-bold text-violet-300">Continuity Sheets</span>
                <p className="text-[8.5px] text-slate-400 leading-tight">Auto-align subsequent sheet structures</p>
              </div>
            </label>
            {continuitySheets && (
              <span className="px-1.5 py-0.2 rounded text-[8px] font-bold bg-violet-500/20 text-violet-300 border border-violet-500/30 font-mono">
                Active
              </span>
            )}
          </div>

          {/* Dual SMS Mode Stream Selector if showSms is active */}
          {showSms && (
            <div className="flex items-center gap-1 bg-slate-950/40 p-1 rounded-lg border border-slate-800/80 shrink-0">
              <button
                type="button"
                onClick={() => setSelectedRole("APP")}
                className={`flex-1 py-1 rounded text-[9.5px] font-bold transition cursor-pointer text-center ${
                  selectedRole === "APP"
                    ? "bg-violet-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                SMS (S) ({appFiles.length})
              </button>
              <button
                type="button"
                onClick={() => setSelectedRole("SMS")}
                className={`flex-1 py-1 rounded text-[9.5px] font-bold transition cursor-pointer text-center ${
                  selectedRole === "SMS"
                    ? "bg-sky-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                SMS (B) ({smsFiles.length})
              </button>
            </div>
          )}

          {/* SMS Dropzone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragActive(true); }}
            onDragLeave={() => setIsDragActive(false)}
            onDrop={(e) => { e.preventDefault(); setIsDragActive(false); handleFiles(e.dataTransfer.files, activeUploadRole); }}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-3 text-center cursor-pointer transition-all duration-200 shrink-0 min-h-[90px] flex flex-col items-center justify-center relative ${
              isDragActive
                ? "border-violet-500 bg-violet-950/30"
                : "border-slate-800 hover:border-violet-500/50 bg-slate-950/30 hover:bg-violet-950/10"
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => handleFiles(e.target.files, activeUploadRole)}
              accept=".xlsx,.xls,.csv"
              multiple
              className="hidden"
            />

            {isUploadingThis ? (
              <div className="space-y-1 w-full text-center px-3">
                <p className="text-[10px] text-violet-400 font-bold truncate">{uploadProgress.fileName}</p>
                <div className="bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800 mx-2">
                  <div style={{ width: `${uploadProgress.percent}%` }} className="bg-violet-500 h-full rounded-full transition-all" />
                </div>
                <p className="text-[8px] text-slate-400">{uploadProgress.stage}</p>
              </div>
            ) : (
              <div className="flex flex-col items-center space-y-1">
                <Upload size={16} className="text-violet-400" />
                <span className="text-[11px] font-bold text-slate-200">
                  Click or Drag SMS Files
                </span>
                <span className="text-[9px] text-slate-500 font-mono">.XLSX, .XLS, .CSV</span>
              </div>
            )}
          </div>

          {/* List of Uploaded SMS Files */}
          <div className="flex-1 min-h-[90px] max-h-[160px] overflow-y-auto space-y-1 pr-0.5 shrink-0">
            {allSmsFiles.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-4 border border-dashed border-slate-850 rounded-xl bg-slate-950/20 text-center space-y-0.5 h-full">
                <FileSpreadsheet size={16} className="text-slate-600 mb-1" />
                <p className="text-[10px] font-bold text-slate-500">No SMS files uploaded yet</p>
                <p className="text-[8.5px] text-slate-600">Drop SMS transaction reports above</p>
              </div>
            ) : (
              allSmsFiles.map(file => (
                <div key={file.id} className="bg-slate-900/80 border border-slate-800 rounded-lg p-1.5 px-2 flex items-center justify-between text-[10px]">
                  <div className="min-w-0 flex items-center space-x-1.5">
                    <FileSpreadsheet size={12} className="text-violet-400 shrink-0" />
                    <div className="flex flex-col min-w-0">
                      <span className="font-semibold text-slate-200 truncate max-w-[140px]" title={file.fileName}>
                        {file.fileName}
                      </span>
                      <span className="text-[8px] text-violet-400 font-mono">
                        {file.role === "APP" ? "SMS (S)" : "SMS (B)"} • {file.sheetCount} sheet{file.sheetCount !== 1 ? "s" : ""}
                      </span>
                    </div>
                    <span className="text-[8px] text-slate-500 font-mono self-start mt-0.5">
                      ({(file.fileSize / 1024).toFixed(0)}KB)
                    </span>
                  </div>
                  <button
                    onClick={() => handleRemoveFile(file.id)}
                    className="text-slate-500 hover:text-rose-400 transition p-1 cursor-pointer"
                    title="Remove file"
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Ignore Digit Normalization Feature Controls */}
          <div className="pt-2 border-t border-violet-950/40 shrink-0 w-full mt-auto">
            <IgnoreDigitSelector
              sheets={sheets}
              enabled={ignoreDigitEnabled}
              setEnabled={setIgnoreDigitEnabled}
              rules={ignoreDigitRules}
              setRules={setIgnoreDigitRules}
            />
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 2. CAS UPLOAD PANEL
// ==========================================
export interface CasUploadPanelProps {
  files: UploadedFile[];
  sheets: SheetState[];
  setFiles: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  setSheets: React.Dispatch<React.SetStateAction<SheetState[]>>;
  handleFiles: (uploadedFiles: FileList | null, targetRole: "CAS" | "SMS" | "APP", associatedCasName?: string) => Promise<void>;
  uploadProgress: { fileName: string; stage: string; percent: number; role?: "CAS" | "SMS" | "APP" } | null;
  handleRemoveFile: (fileId: string) => void;
  handleRemoveCasFiles: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export function CasUploadPanel({
  files,
  sheets,
  handleFiles,
  uploadProgress,
  handleRemoveFile,
  handleRemoveCasFiles,
  isCollapsed = false,
  onToggleCollapse,
}: CasUploadPanelProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [selectedCasName, setSelectedCasName] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const casFiles = files.filter(f => f.role === "CAS");
  const casSheets = sheets.filter(s => s.role === "CAS");

  const uniqueCasNames = React.useMemo(() => {
    const names = new Set<string>();
    sheets.forEach(s => {
      if ((s.role === "APP" || s.role === "SMS") && s.parsedCasData) {
        const casData = s.parsedCasData;
        for (const k in casData) {
          const val = casData[k];
          if (typeof val === "string" && val.trim() !== "") {
            names.add(val.trim());
          }
        }
      }
    });
    return Array.from(names).sort((a, b) => a.localeCompare(b));
  }, [sheets]);

  const isUploadingThis = uploadProgress && uploadProgress.role === "CAS";

  return (
    <div className={`bg-slate-900/40 border border-slate-800/80 rounded-2xl p-3.5 flex flex-col h-full shadow-xl transition-all duration-300 ${
      isCollapsed ? "min-h-0 xl:w-[60px] space-y-2 p-2 items-center" : "min-h-[420px] space-y-3"
    }`}>
      {/* Header */}
      <div className={`flex items-center justify-between border-b border-slate-800 pb-2.5 shrink-0 w-full ${isCollapsed ? "flex-col gap-2 border-0 pb-0" : ""}`}>
        <div className={`flex items-center space-x-2 ${isCollapsed ? "flex-col space-x-0 gap-1.5" : ""}`}>
          <div className="p-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <Database size={14} />
          </div>
          {!isCollapsed && (
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <span>2. CAS UPLOAD</span>
              </h3>
              <p className="text-[10px] text-slate-400">Drop or pick CAS Source spreadsheets</p>
            </div>
          )}
        </div>
        <div className={`flex items-center space-x-1.5 ${isCollapsed ? "flex-col space-x-0 gap-1.5" : ""}`}>
          {!isCollapsed && (
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-mono font-bold bg-emerald-950/80 text-emerald-300 px-2 py-0.5 rounded-md border border-emerald-800/60">
                {casFiles.length} Files ({casSheets.length} Sheets)
              </span>
              {casFiles.length > 0 && (
                <button
                  type="button"
                  onClick={handleRemoveCasFiles}
                  className="px-2 py-0.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-md text-[9.5px] font-bold flex items-center gap-1 transition cursor-pointer"
                  title="Clear all uploaded CAS files"
                >
                  <Trash2 size={10} />
                  <span>Clear CAS</span>
                </button>
              )}
            </div>
          )}
          {onToggleCollapse && (
            <button
              type="button"
              onClick={onToggleCollapse}
              className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-emerald-400 transition cursor-pointer"
              title={isCollapsed ? "Expand Panel" : "Collapse Panel"}
            >
              {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
            </button>
          )}
        </div>
      </div>

      {isCollapsed ? (
        <div className="flex-1 flex flex-col items-center justify-between py-6 select-none w-full h-full min-h-[250px]">
          <div className="flex flex-col items-center gap-1.5" title="CAS Source Files">
            <span className="text-[11px] font-black text-emerald-400 font-mono tracking-widest border-b border-emerald-500/30 pb-0.5 px-1">CAS</span>
            <span className="text-xs font-extrabold font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-lg min-w-[28px] text-center shadow-md">
              {casFiles.length}
            </span>
          </div>

          <div className="flex flex-col items-center">
            <span className="text-[10.5px] uppercase font-black tracking-widest text-slate-500 [writing-mode:vertical-lr] rotate-180">
              2. CAS UPLOAD
            </span>
          </div>

          <div className="text-[9px] font-mono text-slate-500">
            {casSheets.length}s
          </div>
        </div>
      ) : (
        <div className="flex-1 w-full min-h-0 flex flex-col gap-2.5 overflow-hidden">
          {/* CAS Upload Association Filter */}
          <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/80 space-y-1.5 shrink-0">
            <div className="flex items-center justify-between">
              <label className="text-[9px] font-black uppercase text-slate-300 tracking-wider flex items-center gap-1.5">
                <Tag size={11} className="text-emerald-400" />
                <span>CAS Upload Association Filter</span>
              </label>
              {selectedCasName ? (
                <span className="px-1.5 py-0.2 rounded text-[7.5px] font-black bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 uppercase tracking-widest font-mono">
                  Scoped Mode
                </span>
              ) : (
                <span className="text-[8px] text-slate-500 font-mono">Optional</span>
              )}
            </div>
            <select
              value={selectedCasName}
              onChange={(e) => setSelectedCasName(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 text-slate-200 rounded-lg p-1.5 text-[9.5px] truncate focus:outline-none focus:border-emerald-500/60 font-medium cursor-pointer"
            >
              <option value="">-- All (No CAS Filter) --</option>
              {uniqueCasNames.length === 0 ? (
                <option value="" disabled>No CAS names loaded. Upload SMS Source first to scope.</option>
              ) : (
                uniqueCasNames.map((name) => (
                  <option key={name} value={name}>{name}</option>
                ))
              )}
            </select>
          </div>

          {/* CAS Dropzone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragActive(true); }}
            onDragLeave={() => setIsDragActive(false)}
            onDrop={(e) => { e.preventDefault(); setIsDragActive(false); handleFiles(e.dataTransfer.files, "CAS", selectedCasName); }}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-3 text-center cursor-pointer transition-all duration-200 shrink-0 min-h-[90px] flex flex-col items-center justify-center relative ${
              isDragActive
                ? "border-emerald-500 bg-emerald-950/30"
                : "border-slate-800 hover:border-emerald-500/50 bg-slate-950/30 hover:bg-emerald-950/10"
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => handleFiles(e.target.files, "CAS", selectedCasName)}
              accept=".xlsx,.xls,.csv"
              multiple
              className="hidden"
            />

            {isUploadingThis ? (
              <div className="space-y-1 w-full text-center px-3">
                <p className="text-[10px] text-emerald-400 font-bold truncate">{uploadProgress.fileName}</p>
                <div className="bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800 mx-2">
                  <div style={{ width: `${uploadProgress.percent}%` }} className="bg-emerald-500 h-full rounded-full transition-all" />
                </div>
                <p className="text-[8px] text-slate-400">{uploadProgress.stage}</p>
              </div>
            ) : (
              <div className="flex flex-col items-center space-y-1">
                <Upload size={16} className="text-emerald-400" />
                <span className="text-[11px] font-bold text-slate-200">
                  Click or Drag CAS Files
                </span>
                <span className="text-[9px] text-slate-500 font-mono">.XLSX, .XLS, .CSV</span>
              </div>
            )}
          </div>

          {/* List of Uploaded CAS Files */}
          <div className="flex-1 min-h-[90px] overflow-y-auto space-y-1 pr-0.5 shrink-0">
            {casFiles.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-6 border border-dashed border-slate-850 rounded-xl bg-slate-950/20 text-center space-y-1 h-full">
                <FileSpreadsheet size={16} className="text-slate-600 mb-1" />
                <p className="text-[10px] font-bold text-slate-500">No CAS files uploaded yet</p>
                <p className="text-[8.5px] text-slate-600 max-w-[200px]">
                  Drop CAS transaction reports or ground truth spreadsheets above
                </p>
              </div>
            ) : (
              casFiles.map(file => (
                <div key={file.id} className="bg-slate-900/80 border border-slate-800 rounded-lg p-1.5 px-2 flex items-center justify-between text-[10px]">
                  <div className="min-w-0 flex items-center space-x-1.5">
                    <FileSpreadsheet size={12} className="text-emerald-400 shrink-0" />
                    <div className="flex flex-col min-w-0">
                      <span className="font-semibold text-slate-200 truncate max-w-[140px]" title={file.fileName}>
                        {file.fileName}
                      </span>
                      <div className="flex items-center gap-1 mt-0.5">
                        <span className="text-[8px] text-emerald-400 font-mono">
                          CAS • {file.sheetCount} sheet{file.sheetCount !== 1 ? "s" : ""}
                        </span>
                        {file.associatedCasName && (
                          <span className="text-[7.5px] text-emerald-300 font-bold bg-emerald-500/15 border border-emerald-500/25 px-1 rounded font-mono">
                            CAS: {file.associatedCasName}
                          </span>
                        )}
                      </div>
                    </div>
                    <span className="text-[8px] text-slate-500 font-mono self-start mt-0.5">
                      ({(file.fileSize / 1024).toFixed(0)}KB)
                    </span>
                  </div>
                  <button
                    onClick={() => handleRemoveFile(file.id)}
                    className="text-slate-500 hover:text-rose-400 transition p-1 cursor-pointer"
                    title="Remove file"
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// Backward compatibility aliases
export type FileUploadPanelProps = SmsUploadPanelProps;
export const FileUploadPanel = SmsUploadPanel;

export interface AttachedLogicPanelProps {
  sheets: SheetState[];
  setSheets: React.Dispatch<React.SetStateAction<SheetState[]>>;
  activeSheetSettingsId: string | null;
  setActiveSheetSettingsId: React.Dispatch<React.SetStateAction<string | null>>;
  handleUpdateSheetSkipRows: (sheetId: string, skipRows: number) => void;
  handleUpdateSheetColumns: (sheetId: string, type: "key" | "product" | "cas", value: string) => void;
  handleUpdateSheetRole: (sheetId: string, role: "CAS" | "SMS" | "APP" | "SKIP") => void;
  handleUpdateSheetReferenceSettings?: (sheetId: string, enabled: boolean, refFileId: string) => void;
  handleUpdateSheetAssociatedCasName?: (sheetId: string, associatedCasName: string) => void;
  showCas?: boolean;
  showSms?: boolean;
  showApp?: boolean;
  showProductCol?: boolean;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  continuitySheets: boolean;
  setContinuitySheets: React.Dispatch<React.SetStateAction<boolean>>;
  reprocessAllContinuitySheets: (currentSheets: SheetState[], enabled: boolean) => Promise<void>;
  globalReferenceEnabled: boolean;
  setGlobalReferenceEnabled: React.Dispatch<React.SetStateAction<boolean>>;
  globalReferenceMappings: GlobalReferenceMapping[];
  setGlobalReferenceMappings: React.Dispatch<React.SetStateAction<GlobalReferenceMapping[]>>;
  onNavigateToReference?: () => void;
}

export function AttachedLogicPanel({
  sheets,
  setSheets,
  activeSheetSettingsId,
  setActiveSheetSettingsId,
  handleUpdateSheetSkipRows,
  handleUpdateSheetColumns,
  handleUpdateSheetRole,
  handleUpdateSheetReferenceSettings,
  handleUpdateSheetAssociatedCasName,
  showCas = true,
  showSms = false,
  showApp = true,
  showProductCol = true,
  isCollapsed = false,
  onToggleCollapse,
  continuitySheets,
  setContinuitySheets,
  reprocessAllContinuitySheets,
  globalReferenceEnabled,
  setGlobalReferenceEnabled,
  globalReferenceMappings,
  setGlobalReferenceMappings,
  onNavigateToReference
}: AttachedLogicPanelProps) {
  const [isCasCollapsed, setIsCasCollapsed] = useState(false);
  const [isSmsCollapsed, setIsSmsCollapsed] = useState(false);
  const [isAppCollapsed, setIsAppCollapsed] = useState(false);
  const [storedReferenceFiles, setStoredReferenceFiles] = useState<StoredReferenceFile[]>(() => loadStoredReferenceFiles());
  const [isRefUploading, setIsRefUploading] = useState(false);
  const [showSheetToRefModal, setShowSheetToRefModal] = useState(false);
  const [selectedSheetForRef, setSelectedSheetForRef] = useState<string>("");
  const [sheetRefName, setSheetRefName] = useState<string>("");
  const [sheetRefIdCol, setSheetRefIdCol] = useState<string>("");
  const [sheetRefValCol, setSheetRefValCol] = useState<string>("");
  const inlineRefFileInputRef = useRef<HTMLInputElement>(null);

  const uniqueCasNames = React.useMemo(() => {
    return getAllUniqueCasNames(sheets);
  }, [sheets]);

  // Real-time synchronization of stored reference files across tabs and workspaces
  useEffect(() => {
    const refresh = () => {
      const latest = loadStoredReferenceFiles();
      setStoredReferenceFiles(prev => {
        if (prev.length === latest.length && prev.every((p, i) => p.id === latest[i]?.id && p.savedAt === latest[i]?.savedAt)) {
          return prev;
        }
        return latest;
      });
    };
    window.addEventListener(REF_EVENT_NAME, refresh);
    window.addEventListener("storage", refresh);
    window.addEventListener("focus", refresh);
    return () => {
      window.removeEventListener(REF_EVENT_NAME, refresh);
      window.removeEventListener("storage", refresh);
      window.removeEventListener("focus", refresh);
    };
  }, []);

  // Auto-bind reference file if only 1 exists and current mapping has none
  useEffect(() => {
    if (storedReferenceFiles.length === 1 && storedReferenceFiles[0]?.id) {
      const onlyId = storedReferenceFiles[0].id;
      setGlobalReferenceMappings(prev => {
        if (prev.length > 0 && !prev[0].referenceFileId) {
          return [{ ...prev[0], referenceFileId: onlyId }, ...prev.slice(1)];
        }
        return prev;
      });
    }
  }, [storedReferenceFiles]);

  const handleInlineRefFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsRefUploading(true);
      const parsed = await parseReferenceSpreadsheet(file);
      const updated = addStoredReferenceFile(parsed);
      setStoredReferenceFiles(updated);

      // Auto-assign to mapping
      if (globalReferenceMappings.length > 0) {
        const nextMappings = [...globalReferenceMappings];
        const emptyIdx = nextMappings.findIndex(m => !m.referenceFileId);
        if (emptyIdx >= 0) {
          nextMappings[emptyIdx] = { ...nextMappings[emptyIdx], referenceFileId: parsed.id };
        } else {
          nextMappings[0] = { ...nextMappings[0], referenceFileId: parsed.id };
        }
        setGlobalReferenceMappings(nextMappings);
      }
    } catch (err: any) {
      alert("Failed to parse reference spreadsheet: " + (err?.message || "Invalid file format"));
    } finally {
      setIsRefUploading(false);
      if (e.target) e.target.value = "";
    }
  };

  const handleConvertSheetToRef = () => {
    const targetSheet = sheets.find(s => s.id === selectedSheetForRef);
    if (!targetSheet) return;
    if (!sheetRefIdCol || !sheetRefValCol) {
      alert("Please select both Product ID and Reference Value columns.");
      return;
    }
    const name = sheetRefName.trim() || targetSheet.sheetName;
    const newRef = convertSheetToStoredReference(targetSheet, name, sheetRefIdCol, sheetRefValCol);
    const updated = addStoredReferenceFile(newRef);
    setStoredReferenceFiles(updated);

    if (globalReferenceMappings.length > 0) {
      const nextMappings = [...globalReferenceMappings];
      const emptyIdx = nextMappings.findIndex(m => !m.referenceFileId);
      if (emptyIdx >= 0) {
        nextMappings[emptyIdx] = { ...nextMappings[emptyIdx], referenceFileId: newRef.id };
      } else {
        nextMappings[0] = { ...nextMappings[0], referenceFileId: newRef.id };
      }
      setGlobalReferenceMappings(nextMappings);
    }
    setShowSheetToRefModal(false);
  };

  const activeSheets = sheets.filter(s => s.role !== "SKIP");
  const skippedSheets = sheets.filter(s => s.role === "SKIP");

  const activeRoles: ("CAS" | "SMS" | "APP")[] = [];
  if (showApp) activeRoles.push("APP");
  if (showSms) activeRoles.push("SMS");
  if (showCas) activeRoles.push("CAS");

  const isTwoSections = activeRoles.length === 2;
  const topRole = isTwoSections ? activeRoles[0] : null;
  const bottomRole = isTwoSections ? activeRoles[1] : null;

  const topSheets = topRole ? activeSheets.filter(s => s.role === topRole) : [];
  const bottomSheets = bottomRole ? activeSheets.filter(s => s.role === bottomRole) : [];

  const isRoleCollapsed = (role: "CAS" | "SMS" | "APP") => {
    if (role === "CAS") return isCasCollapsed;
    if (role === "SMS") return isSmsCollapsed;
    if (role === "APP") return isAppCollapsed;
    return false;
  };

  const toggleRoleCollapse = (role: "CAS" | "SMS" | "APP") => {
    if (role === "CAS") setIsCasCollapsed(!isCasCollapsed);
    if (role === "SMS") setIsSmsCollapsed(!isSmsCollapsed);
    if (role === "APP") setIsAppCollapsed(!isAppCollapsed);
  };

  const getLogicSectionFlexStyle = (role: "CAS" | "SMS" | "APP") => {
    const isCollapsed = isRoleCollapsed(role);
    if (isCollapsed) return { flex: "0 0 auto", minHeight: "36px" };
    if (!isTwoSections) return undefined;
    
    if (role === topRole || role === bottomRole) {
      return { flex: "1 1 0%", minHeight: "120px" };
    }
    return undefined;
  };

  const getRoleLabel = (role: "CAS" | "SMS" | "APP") => {
    if (role === "CAS") return "CAS SOURCE (C)";
    if (role === "SMS") return "SMS SOURCE (B)";
    if (role === "APP") return "SMS SOURCE (S)";
    return role;
  };

  const renderSheetCardsList = (filteredSheets: SheetState[], emptyPlaceholder: string) => {
    if (filteredSheets.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center p-4 border border-dashed border-slate-850 rounded-xl bg-slate-950/15 text-center space-y-1 h-full min-h-[50px] my-auto">
          <p className="text-[10px] font-bold text-slate-500">{emptyPlaceholder}</p>
        </div>
      );
    }

    return (
      <div className="space-y-2.5 overflow-y-auto pr-0.5 max-h-full">
        {filteredSheets.map(sheet => {
          const isActive = activeSheetSettingsId === sheet.id;
          const keysCount = Object.keys(sheet.parsedData).length;

          let roleBadgeBg = "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
          if (sheet.role === "APP") roleBadgeBg = "bg-violet-500/10 text-violet-400 border-violet-500/20";
          if (sheet.role === "SMS") roleBadgeBg = "bg-sky-500/10 text-sky-400 border-sky-500/20";

          const appSheets = sheets.filter(s => s.role === "APP");
          const isFirstAppSheet = appSheets.length > 0 && sheet.id === appSheets[0].id;
          const isContinuityAndSubsequent = continuitySheets && sheet.role === "APP" && !isFirstAppSheet;

          return (
            <div 
              key={sheet.id}
              className="bg-slate-950/60 border border-slate-800/90 rounded-xl overflow-hidden shadow-md transition-all hover:border-slate-700"
            >
              {/* Header row */}
              <div className="p-2 flex items-center justify-between gap-2 bg-slate-900/40">
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={`text-[9px] font-black px-1.5 py-0.2 rounded border uppercase font-mono ${roleBadgeBg}`}>
                      {sheet.role === "APP" ? "SMS" : sheet.role}
                    </span>
                    <h4 className="text-[11px] font-bold text-slate-200 truncate max-w-[140px]" title={sheet.sheetName}>
                      {sheet.sheetName}
                    </h4>
                    <span className="text-[9px] bg-emerald-500/15 text-emerald-300 font-mono font-bold px-1.5 py-0.2 rounded border border-emerald-500/20">
                      {keysCount} IDs
                    </span>
                  </div>
                  <p className="text-[8px] text-slate-500 truncate" title={sheet.fileName}>
                    ({sheet.fileName})
                  </p>
                </div>

                <div className="flex items-center space-x-1.5 shrink-0">
                  <button
                    onClick={() => handleUpdateSheetRole(sheet.id, "SKIP")}
                    className="bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-rose-400 border border-slate-800 text-[9px] font-bold px-1.5 py-0.5 rounded-md transition cursor-pointer"
                    title="Bypass this sheet from analysis"
                  >
                    Bypass
                  </button>
                  <button
                    onClick={() => setActiveSheetSettingsId(isActive ? null : sheet.id)}
                    className={`p-1 bg-slate-900 hover:bg-slate-800 border rounded-md text-slate-400 transition cursor-pointer ${
                      isActive ? "text-indigo-400 border-indigo-500/40 bg-indigo-950/30" : "border-slate-800 hover:text-slate-200"
                    }`}
                    title="Configure Sheet Logic & Column Mappings"
                  >
                    <Settings size={12} />
                  </button>
                </div>
              </div>

              {/* Always visible column logic settings */}
              <div className="p-2 bg-slate-950/90 border-t border-slate-900/80 space-y-1.5 text-[10px]">
                <div className="flex items-center justify-between gap-2 border-b border-slate-900/80 pb-1">
                  <span className="font-semibold text-slate-400">Skip matrix rows</span>
                  <input
                    type="number"
                    min="0"
                    max="40"
                    value={sheet.skipRows}
                    disabled={isContinuityAndSubsequent}
                    onChange={(e) => {
                      const val = Math.max(0, parseInt(e.target.value, 10) || 0);
                      handleUpdateSheetSkipRows(sheet.id, val);
                    }}
                    className="w-12 px-1.5 py-0.5 bg-slate-900 border border-slate-700 disabled:opacity-50 text-slate-200 rounded text-center focus:outline-none focus:border-indigo-500 font-mono font-bold text-[10px]"
                  />
                </div>

                {isContinuityAndSubsequent ? (
                  <div className="bg-violet-950/30 border border-violet-500/20 text-violet-300 rounded-lg p-1.5 text-[8.5px] flex items-center gap-1.5 font-medium leading-relaxed">
                    <span className="w-1.5 h-1.5 rounded-full bg-violet-400 shrink-0 animate-pulse"></span>
                    <span>Continuity Active: Inheriting locked column mapping of the first SMS sheet.</span>
                  </div>
                ) : (
                  <div className={`grid ${
                    sheet.role === "APP" 
                      ? (showProductCol ? "grid-cols-3" : "grid-cols-2") 
                      : (showProductCol ? "grid-cols-2" : "grid-cols-1")
                  } gap-2`}>
                    <div>
                      <p className="font-bold text-slate-500 text-[8px] uppercase mb-0.5">CARD ID COL</p>
                      <select
                        value={sheet.detectedKeyCol}
                        onChange={(e) => handleUpdateSheetColumns(sheet.id, "key", e.target.value)}
                        className="w-full bg-slate-900 border border-slate-750 text-slate-200 rounded-lg p-1 text-[9px] truncate focus:outline-none focus:border-indigo-500"
                      >
                        {sheet.columns.map((col, idx) => (
                          <option key={`${col}-${idx}`} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>
                    {showProductCol && (
                      <div>
                        <p className="font-bold text-slate-500 text-[8px] uppercase mb-0.5">PRODUCT COL</p>
                        <select
                          value={sheet.detectedProductCol}
                          onChange={(e) => handleUpdateSheetColumns(sheet.id, "product", e.target.value)}
                          className="w-full bg-slate-900 border border-slate-750 text-slate-200 rounded-lg p-1 text-[9px] truncate focus:outline-none focus:border-indigo-550"
                        >
                          {sheet.columns.map((col, idx) => (
                            <option key={`${col}-${idx}`} value={col}>{col}</option>
                          ))}
                        </select>
                      </div>
                    )}
                    {sheet.role === "APP" && (
                      <div>
                        <p className="font-bold text-slate-500 text-[8px] uppercase mb-0.5">CAS COL</p>
                        <select
                          value={sheet.detectedCasCol || ""}
                          onChange={(e) => handleUpdateSheetColumns(sheet.id, "cas", e.target.value)}
                          className="w-full bg-slate-900 border border-slate-750 text-slate-200 rounded-lg p-1 text-[9px] truncate focus:outline-none focus:border-indigo-550"
                        >
                          <option value="">-- None --</option>
                          {sheet.columns.map((col, idx) => (
                            <option key={`${col}-${idx}`} value={col}>{col}</option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>
                )}

                {/* Associated CAS Name for CAS Sheets */}
                {sheet.role === "CAS" && (
                  <div className="border-t border-slate-900/60 pt-2 mt-2 space-y-1">
                    <div className="flex items-center justify-between">
                      <p className="font-bold text-slate-400 text-[8px] uppercase tracking-wider">Associated CAS Name Filter</p>
                      {sheet.associatedCasName && (
                        <span className="text-[7px] font-extrabold bg-emerald-500/15 border border-emerald-500/20 text-emerald-400 px-1 py-0.2 rounded font-mono uppercase tracking-widest">
                          Active
                        </span>
                      )}
                    </div>
                    <select
                      value={sheet.associatedCasName || ""}
                      onChange={(e) => {
                        if (handleUpdateSheetAssociatedCasName) {
                          handleUpdateSheetAssociatedCasName(sheet.id, e.target.value);
                        }
                      }}
                      className="w-full bg-slate-900 border border-slate-750 text-slate-200 rounded-lg p-1 text-[9px] truncate focus:outline-none focus:border-indigo-500 font-medium cursor-pointer"
                    >
                      <option value="">-- All (No CAS Filter) --</option>
                      {uniqueCasNames.map((name) => (
                        <option key={name} value={name}>{name}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className={`bg-slate-900/40 border border-slate-800/80 rounded-2xl p-3.5 flex flex-col h-full shadow-xl transition-all duration-300 ${
      isCollapsed ? "min-h-0 md:w-[68px] space-y-2 p-2 items-center" : "min-h-[420px] space-y-3.5"
    }`}>
      <div className={`flex items-center justify-between border-b border-slate-800 pb-2.5 shrink-0 w-full ${isCollapsed ? "flex-col gap-2 border-0 pb-0" : ""}`}>
        <div className={`flex items-center space-x-2 ${isCollapsed ? "flex-col space-x-0 gap-1.5" : ""}`}>
          <div className="p-1.5 rounded-lg bg-teal-500/10 border border-teal-500/20 text-teal-400">
            <Sliders size={14} />
          </div>
          {!isCollapsed && (
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                3. ATTACHED LOGIC ASSIGN
              </h3>
              <p className="text-[10px] text-slate-400">Column mappings & matrix skip controls</p>
            </div>
          )}
        </div>
        <div className={`flex items-center space-x-1.5 ${isCollapsed ? "flex-col space-x-0 gap-1.5" : ""}`}>
          {!isCollapsed && (
            <span className="text-[10px] font-mono font-bold bg-teal-950/80 text-teal-300 px-2 py-0.5 rounded-md border border-teal-800/60">
              {activeSheets.length} Sheets
            </span>
          )}
          {onToggleCollapse && (
            <button
              type="button"
              onClick={onToggleCollapse}
              className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-teal-400 transition cursor-pointer"
              title={isCollapsed ? "Expand Panel" : "Collapse Panel"}
            >
              {isCollapsed ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
            </button>
          )}
        </div>
      </div>

      {isCollapsed ? (
        <div className="flex-1 flex flex-col items-center justify-between py-6 select-none w-full h-full min-h-[250px]">
          {/* Top: CAS (C) Sheet Indicator */}
          {showCas && (
            <div className="flex flex-col items-center gap-1.5" title="CAS (C) Active Sheets">
              <span className="text-[11px] font-black text-emerald-400 font-mono tracking-widest border-b border-emerald-500/30 pb-0.5 px-1">C</span>
              <span className="text-xs font-extrabold font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-lg min-w-[28px] text-center shadow-md">
                {sheets.filter(s => s.role === "CAS").length}
              </span>
            </div>
          )}

          {/* Middle: Rotated Panel Label */}
          <div className="flex flex-col items-center">
            <span className="text-[10.5px] uppercase font-black tracking-widest text-slate-500 [writing-mode:vertical-lr] rotate-180">
              3. ATTACHED LOGIC ASSIGN
            </span>
          </div>

          {/* Bottom: SMS (S) Sheet Indicator */}
          {showApp && (
            <div className="flex flex-col items-center gap-1.5" title="SMS (S) Active Sheets">
              <span className="text-xs font-extrabold font-mono text-violet-400 bg-violet-500/10 border border-violet-500/20 px-2 py-0.5 rounded-lg min-w-[28px] text-center shadow-md">
                {sheets.filter(s => s.role === "APP").length}
              </span>
              <span className="text-[11px] font-black text-violet-400 font-mono tracking-widest border-t border-violet-500/30 pt-0.5 px-1">S</span>
            </div>
          )}
        </div>
      ) : (
        <div className="flex-1 w-full flex flex-col gap-3 overflow-hidden">
          {activeSheets.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-6 border border-dashed border-slate-800 rounded-xl bg-slate-950/20 text-center space-y-2 my-auto flex-1">
              <FileCheck2 size={24} className="text-slate-600" />
              <p className="text-xs font-bold text-slate-400">No Sheets Attached Yet</p>
              <p className="text-[10px] text-slate-500 max-w-[200px]">
                Upload SMS or CAS files in Layout 1 or 2 to configure column mappings, roles and reference logic here.
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-3 flex-1 overflow-hidden">
              {/* Global Reference Mapping Control Card */}
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5 space-y-2 shrink-0">
                <input
                  type="file"
                  ref={inlineRefFileInputRef}
                  onChange={handleInlineRefFileUpload}
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                />

                <div className="flex items-center justify-between">
                  <label className="flex items-center space-x-2 text-[10px] font-black text-slate-300 uppercase tracking-wider cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={globalReferenceEnabled}
                      onChange={(e) => setGlobalReferenceEnabled(e.target.checked)}
                      className="rounded border-slate-700 text-indigo-600 focus:ring-indigo-500 bg-slate-900 w-3 h-3 cursor-pointer"
                    />
                    <span>Global Reference Mapping</span>
                  </label>

                  <div className="flex items-center gap-1.5">
                    {globalReferenceEnabled && (
                      <span className="px-1.5 py-0.2 rounded text-[7.5px] font-extrabold bg-indigo-500/15 border border-indigo-500/20 text-indigo-400 uppercase tracking-widest font-mono">
                        Active
                      </span>
                    )}
                    {globalReferenceEnabled && (
                      <span className={`px-1.5 py-0.2 rounded text-[7.5px] font-bold border font-mono ${
                        storedReferenceFiles.length > 0 
                          ? "bg-emerald-500/15 border-emerald-500/25 text-emerald-300"
                          : "bg-amber-500/15 border-amber-500/25 text-amber-300"
                      }`}>
                        {storedReferenceFiles.length} Ref File{storedReferenceFiles.length !== 1 ? "s" : ""}
                      </span>
                    )}
                    {globalReferenceEnabled && (
                      <button
                        type="button"
                        onClick={() => inlineRefFileInputRef.current?.click()}
                        disabled={isRefUploading}
                        className="px-1.5 py-0.5 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 hover:text-indigo-200 rounded text-[8px] font-bold flex items-center gap-1 transition cursor-pointer"
                        title="Directly upload a reference spreadsheet file"
                      >
                        <Upload size={8} />
                        <span>{isRefUploading ? "..." : "+ Upload"}</span>
                      </button>
                    )}
                    {globalReferenceEnabled && onNavigateToReference && (
                      <button
                        type="button"
                        onClick={onNavigateToReference}
                        className="px-1.5 py-0.5 bg-slate-800 hover:bg-slate-700 border border-slate-750 text-slate-300 hover:text-white rounded text-[8px] font-medium transition cursor-pointer"
                        title="Manage all reference files in the Reference Tab"
                      >
                        Manage →
                      </button>
                    )}
                  </div>
                </div>

                {globalReferenceEnabled && (
                  <div className="space-y-2 pt-2 border-t border-slate-900/80 max-h-[160px] overflow-y-auto pr-0.5">
                    {storedReferenceFiles.length === 0 ? (
                      <div className="bg-slate-900/90 border border-amber-500/30 rounded-xl p-3 text-center space-y-2">
                        <div className="flex items-center justify-center gap-1.5 text-amber-400">
                          <Tag size={13} />
                          <span className="text-[10px] font-bold uppercase tracking-wider">No Reference Files Registered</span>
                        </div>
                        <p className="text-[9px] text-slate-400 leading-relaxed max-w-[280px] mx-auto">
                          Upload a reference spreadsheet (card or product lookup) or convert one of your uploaded sheets.
                        </p>
                        <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => inlineRefFileInputRef.current?.click()}
                            disabled={isRefUploading}
                            className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-[9px] font-bold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
                          >
                            <Upload size={10} />
                            <span>{isRefUploading ? "Parsing File..." : "Upload Reference File"}</span>
                          </button>
                          {onNavigateToReference && (
                            <button
                              type="button"
                              onClick={onNavigateToReference}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-indigo-300 rounded-lg text-[9px] font-medium transition cursor-pointer border border-slate-700"
                            >
                              Open Reference Tab →
                            </button>
                          )}
                        </div>
                        {sheets.length > 0 && (
                          <button
                            type="button"
                            onClick={() => setShowSheetToRefModal(true)}
                            className="text-[8.5px] text-emerald-400 hover:text-emerald-300 font-semibold block mx-auto pt-1 cursor-pointer hover:underline"
                          >
                            + Or use one of your {sheets.length} uploaded sheets as Reference
                          </button>
                        )}
                      </div>
                    ) : (
                      <>
                        {globalReferenceMappings.map((mapping, idx) => (
                          <div key={mapping.id} className="flex items-center gap-1.5">
                            {/* Ref File Select */}
                            <div className="flex-1 min-w-0">
                              <select
                                value={mapping.referenceFileId}
                                onChange={(e) => {
                                  const updated = [...globalReferenceMappings];
                                  updated[idx] = { ...updated[idx], referenceFileId: e.target.value };
                                  setGlobalReferenceMappings(updated);
                                }}
                                className="w-full bg-slate-900 border border-slate-750 text-slate-200 rounded-lg p-1 text-[9px] truncate focus:outline-none focus:border-indigo-500 font-semibold cursor-pointer"
                              >
                                <option value="">-- Select Ref File --</option>
                                {storedReferenceFiles.map(refFile => (
                                  <option key={refFile.id} value={refFile.id}>
                                    {refFile.referenceName} ({refFile.originalName})
                                  </option>
                                ))}
                              </select>
                            </div>

                            {/* Arrow Icon */}
                            <ArrowRight size={10} className="text-slate-500 shrink-0" />

                            {/* CAS Filter Select */}
                            <div className="flex-1 min-w-0">
                              <select
                                value={mapping.casName}
                                onChange={(e) => {
                                  const updated = [...globalReferenceMappings];
                                  updated[idx] = { ...updated[idx], casName: e.target.value };
                                  setGlobalReferenceMappings(updated);
                                }}
                                className="w-full bg-slate-900 border border-slate-750 text-slate-200 rounded-lg p-1 text-[9px] truncate focus:outline-none focus:border-indigo-500 font-semibold cursor-pointer"
                              >
                                <option value="">-- Fallback (ALL) --</option>
                                {uniqueCasNames.map((name) => (
                                  <option key={name} value={name}>{name}</option>
                                ))}
                              </select>
                            </div>

                            {/* Plus / Remove Buttons */}
                            <div className="flex items-center gap-1 shrink-0">
                              {idx === globalReferenceMappings.length - 1 ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setGlobalReferenceMappings([
                                      ...globalReferenceMappings,
                                      { id: `${Date.now()}-${Math.random()}`, referenceFileId: storedReferenceFiles[0]?.id || "", casName: "" }
                                    ]);
                                  }}
                                  className="p-1 bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-800 text-emerald-400 hover:text-emerald-300 transition cursor-pointer"
                                  title="Add another reference mapping"
                                >
                                  <Plus size={11} />
                                </button>
                              ) : null}
                              {globalReferenceMappings.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setGlobalReferenceMappings(globalReferenceMappings.filter((_, i) => i !== idx));
                                  }}
                                  className="p-1 bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-800 text-rose-400 hover:text-rose-300 transition cursor-pointer"
                                  title="Remove mapping"
                                >
                                  <Trash2 size={11} />
                                </button>
                              )}
                            </div>
                          </div>
                        ))}

                        <div className="flex items-center justify-between text-[8px] text-slate-400 pt-1 border-t border-slate-900">
                          <button
                            type="button"
                            onClick={() => inlineRefFileInputRef.current?.click()}
                            className="text-indigo-400 hover:text-indigo-300 hover:underline cursor-pointer flex items-center gap-1"
                          >
                            <Upload size={8} /> + Upload another reference file
                          </button>
                          {sheets.length > 0 && (
                            <button
                              type="button"
                              onClick={() => setShowSheetToRefModal(true)}
                              className="text-emerald-400 hover:text-emerald-300 hover:underline cursor-pointer"
                            >
                              Convert sheet to reference
                            </button>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Lists of Sheets */}
              <div className={`flex-1 min-h-0 ${isTwoSections ? "flex flex-col gap-3.5 items-stretch overflow-hidden" : "space-y-3 overflow-y-auto pr-0.5"}`}>
                {isTwoSections ? (
                  <>
                    {/* Top Section - 60% */}
                    <div 
                      style={getLogicSectionFlexStyle(topRole!)} 
                      className="flex flex-col bg-slate-950/20 border border-slate-800/60 rounded-xl p-2 transition-all duration-200 min-h-0 overflow-hidden"
                    >
                      <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 shrink-0 uppercase tracking-wider font-mono px-1 select-none">
                        <div className="flex items-center gap-2">
                          <span>{getRoleLabel(topRole!)}</span>
                          {topRole === "APP" && (
                            <label className="flex items-center space-x-1 bg-violet-500/10 hover:bg-violet-500/15 border border-violet-500/25 rounded px-1.5 py-0.5 text-[8.5px] font-black text-violet-300 cursor-pointer select-none normal-case tracking-normal transition-all">
                              <input
                                type="checkbox"
                                checked={continuitySheets}
                                onChange={(e) => {
                                  const checked = e.target.checked;
                                  setContinuitySheets(checked);
                                  reprocessAllContinuitySheets(sheets, checked);
                                }}
                                className="rounded border-slate-700 text-violet-600 focus:ring-violet-500 bg-slate-900 w-2.5 h-2.5 cursor-pointer"
                              />
                              <span>Continuity Sheets</span>
                            </label>
                          )}
                        </div>
                        <div className="flex items-center space-x-1.5">
                          <span className={`px-1.5 py-0.2 rounded border ${
                            topRole === "APP"
                              ? "bg-violet-950/60 text-violet-400 border-violet-900/50"
                              : "bg-emerald-950/60 text-emerald-400 border-emerald-900/50"
                          }`}>{topSheets.length} active</span>
                          <button
                            type="button"
                            onClick={() => toggleRoleCollapse(topRole!)}
                            className="p-0.5 hover:bg-slate-800 rounded text-slate-400 hover:text-indigo-400 transition cursor-pointer"
                            title={isRoleCollapsed(topRole!) ? "Expand" : "Collapse"}
                          >
                            {isRoleCollapsed(topRole!) ? <ChevronDown size={11} /> : <ChevronUp size={11} />}
                          </button>
                        </div>
                      </div>
                      {!isRoleCollapsed(topRole!) && (
                        <div className="flex-1 min-h-0 overflow-y-auto mt-1.5 pr-0.5">
                          {renderSheetCardsList(topSheets, `No active sheets for ${getRoleLabel(topRole!)}`)}
                        </div>
                      )}
                    </div>

                    {/* Bottom Section - 40% */}
                    <div 
                      style={getLogicSectionFlexStyle(bottomRole!)} 
                      className="flex flex-col bg-slate-950/20 border border-slate-800/60 rounded-xl p-2 transition-all duration-200 min-h-0 overflow-hidden"
                    >
                      <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 shrink-0 uppercase tracking-wider font-mono px-1 select-none">
                        <div className="flex items-center gap-2">
                          <span>{getRoleLabel(bottomRole!)}</span>
                          {bottomRole === "APP" && (
                            <label className="flex items-center space-x-1 bg-violet-500/10 hover:bg-violet-500/15 border border-violet-500/25 rounded px-1.5 py-0.5 text-[8.5px] font-black text-violet-300 cursor-pointer select-none normal-case tracking-normal transition-all">
                              <input
                                type="checkbox"
                                checked={continuitySheets}
                                onChange={(e) => {
                                  const checked = e.target.checked;
                                  setContinuitySheets(checked);
                                  reprocessAllContinuitySheets(sheets, checked);
                                }}
                                className="rounded border-slate-700 text-violet-600 focus:ring-violet-500 bg-slate-900 w-2.5 h-2.5 cursor-pointer"
                              />
                              <span>Continuity Sheets</span>
                            </label>
                          )}
                        </div>
                        <div className="flex items-center space-x-1.5">
                          <span className={`px-1.5 py-0.2 rounded border ${
                            bottomRole === "CAS"
                              ? "bg-emerald-950/60 text-emerald-400 border-emerald-900/50"
                              : "bg-violet-950/60 text-violet-400 border-violet-900/50"
                          }`}>{bottomSheets.length} active</span>
                          <button
                            type="button"
                            onClick={() => toggleRoleCollapse(bottomRole!)}
                            className="p-0.5 hover:bg-slate-800 rounded text-slate-400 hover:text-emerald-400 transition cursor-pointer"
                            title={isRoleCollapsed(bottomRole!) ? "Expand" : "Collapse"}
                          >
                            {isRoleCollapsed(bottomRole!) ? <ChevronDown size={11} /> : <ChevronUp size={11} />}
                          </button>
                        </div>
                      </div>
                      {!isRoleCollapsed(bottomRole!) && (
                        <div className="flex-1 min-h-0 overflow-y-auto mt-1.5 pr-0.5">
                          {renderSheetCardsList(bottomSheets, `No active sheets for ${getRoleLabel(bottomRole!)}`)}
                        </div>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="space-y-3.5 flex-1 overflow-y-auto">
                    {activeRoles.map(role => {
                      const roleSheets = activeSheets.filter(s => s.role === role);
                      const isCollapsed = isRoleCollapsed(role);
                      const count = roleSheets.length;
                      let countBadgeBg = "bg-emerald-950/60 text-emerald-400 border-emerald-900/50";
                      if (role === "APP") countBadgeBg = "bg-violet-950/60 text-violet-400 border-violet-900/50";
                      if (role === "SMS") countBadgeBg = "bg-sky-950/60 text-sky-400 border-sky-900/50";

                      return (
                        <div 
                          key={role}
                          style={getLogicSectionFlexStyle(role)}
                          className="flex flex-col bg-slate-950/20 border border-slate-800/60 rounded-xl p-2 transition-all duration-200"
                        >
                          <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 shrink-0 uppercase tracking-wider font-mono px-1 select-none">
                            <div className="flex items-center gap-2">
                              <span>{getRoleLabel(role)}</span>
                              {role === "APP" && (
                                <label className="flex items-center space-x-1 bg-violet-500/10 hover:bg-violet-500/15 border border-violet-500/25 rounded px-1.5 py-0.5 text-[8.5px] font-black text-violet-300 cursor-pointer select-none normal-case tracking-normal transition-all">
                                  <input
                                    type="checkbox"
                                    checked={continuitySheets}
                                    onChange={(e) => {
                                      const checked = e.target.checked;
                                      setContinuitySheets(checked);
                                      reprocessAllContinuitySheets(sheets, checked);
                                    }}
                                    className="rounded border-slate-700 text-violet-600 focus:ring-violet-500 bg-slate-900 w-2.5 h-2.5 cursor-pointer"
                                  />
                                  <span>Continuity Sheets</span>
                                </label>
                              )}
                            </div>
                            <div className="flex items-center space-x-1.5">
                              <span className={`px-1.5 py-0.2 rounded border font-mono ${countBadgeBg}`}>{count} active</span>
                              <button
                                type="button"
                                onClick={() => toggleRoleCollapse(role)}
                                className="p-0.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition cursor-pointer"
                                title={isCollapsed ? "Expand" : "Collapse"}
                              >
                                {isCollapsed ? <ChevronDown size={11} /> : <ChevronUp size={11} />}
                              </button>
                            </div>
                          </div>
                          {!isCollapsed && (
                            <div className="flex-1 overflow-y-auto mt-1.5">
                              {renderSheetCardsList(roleSheets, `No active sheets for ${getRoleLabel(role)}`)}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Bypassed Worksheets Section */}
          {skippedSheets.length > 0 && (
            <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-2.5 space-y-2 mt-1 shrink-0">
              <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <Layers size={11} className="text-slate-500" />
                <span>Bypassed Worksheets ({skippedSheets.length})</span>
              </h4>
              <div className="space-y-1 max-h-[80px] overflow-y-auto">
                {skippedSheets.map(s => (
                  <div key={s.id} className="bg-slate-900/60 border border-slate-800 p-1.5 rounded-lg flex items-center justify-between text-[9px]">
                    <span className="text-slate-400 font-bold truncate max-w-[120px]" title={s.sheetName}>
                      {s.sheetName}
                    </span>
                    <div className="flex space-x-1">
                      <button 
                        onClick={() => handleUpdateSheetRole(s.id, "CAS")}
                        className="text-[8px] text-emerald-400 hover:underline font-bold cursor-pointer"
                      >
                        Restore to CAS
                      </button>
                      <span className="text-slate-600">•</span>
                      <button 
                        onClick={() => handleUpdateSheetRole(s.id, "APP")}
                        className="text-[8px] text-violet-400 hover:underline font-bold cursor-pointer"
                      >
                        Restore to SMS
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {/* Convert Sheet to Reference Modal */}
          {showSheetToRefModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Tag size={16} className="text-indigo-400" />
                    <span>Convert Uploaded Sheet to Reference</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setShowSheetToRefModal(false)}
                    className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1">
                      1. Select Source Sheet
                    </label>
                    <select
                      value={selectedSheetForRef}
                      onChange={(e) => {
                        const sId = e.target.value;
                        setSelectedSheetForRef(sId);
                        const found = sheets.find(s => s.id === sId);
                        if (found) {
                          setSheetRefName(found.sheetName.toUpperCase());
                          setSheetRefIdCol(found.detectedKeyCol || found.columns[0] || "");
                          setSheetRefValCol(found.detectedProductCol || found.columns[1] || found.columns[0] || "");
                        }
                      }}
                      className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl p-2.5 text-xs focus:outline-none focus:border-indigo-500 font-semibold cursor-pointer"
                    >
                      <option value="">-- Choose Sheet --</option>
                      {sheets.map(s => (
                        <option key={s.id} value={s.id}>
                          {s.fileName} → [{s.sheetName}] ({s.rowCount || 0} rows)
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedSheetForRef && (
                    <>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1">
                          2. Reference Name
                        </label>
                        <input
                          type="text"
                          value={sheetRefName}
                          onChange={(e) => setSheetRefName(e.target.value)}
                          placeholder="e.g. CARD_LOOKUP_REF"
                          className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl p-2 text-xs font-mono focus:outline-none focus:border-indigo-500"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                            Product ID / Key Col
                          </label>
                          <select
                            value={sheetRefIdCol}
                            onChange={(e) => setSheetRefIdCol(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl p-2 text-xs focus:outline-none focus:border-indigo-500 cursor-pointer"
                          >
                            <option value="">-- Select Column --</option>
                            {sheets.find(s => s.id === selectedSheetForRef)?.columns.map(col => (
                              <option key={col} value={col}>{col}</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                            Reference Value Col
                          </label>
                          <select
                            value={sheetRefValCol}
                            onChange={(e) => setSheetRefValCol(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl p-2 text-xs focus:outline-none focus:border-indigo-500 cursor-pointer"
                          >
                            <option value="">-- Select Column --</option>
                            {sheets.find(s => s.id === selectedSheetForRef)?.columns.map(col => (
                              <option key={col} value={col}>{col}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </>
                  )}
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setShowSheetToRefModal(false)}
                    className="px-3 py-1.5 rounded-xl text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleConvertSheetToRef}
                    disabled={!selectedSheetForRef || !sheetRefIdCol || !sheetRefValCol}
                    className="px-4 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white transition cursor-pointer shadow-md"
                  >
                    Register Reference File
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

interface MultiFileWorkspaceProps {
  sheets: SheetState[];
  setSheets: React.Dispatch<React.SetStateAction<SheetState[]>>;
  files: UploadedFile[];
  setFiles: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  onStartValidation?: () => void;
  isValidating?: boolean;
  showCas?: boolean;
  showSms?: boolean;
  showApp?: boolean;
  isUploadPanelCollapsed?: boolean;
  setIsUploadPanelCollapsed?: (val: boolean) => void;
  isSmsPanelCollapsed?: boolean;
  setIsSmsPanelCollapsed?: (val: boolean) => void;
  isCasPanelCollapsed?: boolean;
  setIsCasPanelCollapsed?: (val: boolean) => void;
  isLogicPanelCollapsed?: boolean;
  setIsLogicPanelCollapsed?: (val: boolean) => void;
  continuitySheets: boolean;
  setContinuitySheets: React.Dispatch<React.SetStateAction<boolean>>;
  globalReferenceEnabled: boolean;
  setGlobalReferenceEnabled: React.Dispatch<React.SetStateAction<boolean>>;
  globalReferenceMappings: GlobalReferenceMapping[];
  setGlobalReferenceMappings: React.Dispatch<React.SetStateAction<GlobalReferenceMapping[]>>;
  ignoreDigitEnabled?: boolean;
  setIgnoreDigitEnabled?: (val: boolean) => void;
  ignoreDigitRules?: IgnoreDigitRule[];
  setIgnoreDigitRules?: (val: IgnoreDigitRule[]) => void;
  isLicensed?: boolean;
  showProductCol?: boolean;
  onNavigateToReference?: () => void;
}

export default function MultiFileWorkspace({
  sheets,
  setSheets,
  files,
  setFiles,
  showCas = true,
  showSms = false,
  showApp = true,
  showProductCol = true,
  isUploadPanelCollapsed,
  setIsUploadPanelCollapsed,
  isSmsPanelCollapsed,
  setIsSmsPanelCollapsed,
  isCasPanelCollapsed,
  setIsCasPanelCollapsed,
  isLogicPanelCollapsed,
  setIsLogicPanelCollapsed,
  continuitySheets,
  setContinuitySheets,
  globalReferenceEnabled,
  setGlobalReferenceEnabled,
  globalReferenceMappings,
  setGlobalReferenceMappings,
  ignoreDigitEnabled = false,
  setIgnoreDigitEnabled = () => {},
  ignoreDigitRules = [],
  setIgnoreDigitRules = () => {},
  isLicensed,
  onNavigateToReference,
}: MultiFileWorkspaceProps) {
  const isLicensedActive = isLicensed ?? (localStorage.getItem("ya_is_licensed") === "true");
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [premiumFeatureName, setPremiumFeatureName] = useState("");

  const [internalSmsCollapsed, setInternalSmsCollapsed] = useState(false);
  const [internalCasCollapsed, setInternalCasCollapsed] = useState(false);
  const [internalLogicCollapsed, setInternalLogicCollapsed] = useState(false);

  const isSmsCollapsed = isSmsPanelCollapsed ?? internalSmsCollapsed;
  const setIsSmsCollapsed = setIsSmsPanelCollapsed ?? setInternalSmsCollapsed;

  const isCasCollapsed = isCasPanelCollapsed ?? internalCasCollapsed;
  const setIsCasCollapsed = setIsCasPanelCollapsed ?? setInternalCasCollapsed;

  const isLogicCollapsed = isLogicPanelCollapsed ?? internalLogicCollapsed;
  const setIsLogicCollapsed = setIsLogicPanelCollapsed ?? setInternalLogicCollapsed;

  const [uploadProgress, setUploadProgress] = useState<{ fileName: string; stage: string; percent: number; role?: "CAS" | "SMS" | "APP" } | null>(null);
  const [activeSheetSettingsId, setActiveSheetSettingsId] = useState<string | null>(null);

  const handleFiles = async (uploadedFiles: FileList | null, targetRole: "CAS" | "SMS" | "APP", associatedCasName?: string) => {
    if (!uploadedFiles || uploadedFiles.length === 0) return;
    
    // Enforcement of Trial Mode Limits (Single File Evaluation Limit)
    if (!isLicensedActive && files.length >= 1) {
      setPremiumFeatureName("Multi-File & Multi-Stream Workspace");
      setShowPremiumModal(true);
      return;
    }
    
    for (let i = 0; i < uploadedFiles.length; i++) {
      const file = uploadedFiles[i];
      const fileId = `${Date.now()}-${targetRole}-${file.name.replace(/\s+/g, "_")}`;
      
      setUploadProgress({
        fileName: file.name,
        stage: "Decompacting workbook structures...",
        percent: 10,
        role: targetRole
      });

      try {
        registerFileReference(fileId, file);

        const parsed = await parseExcelMultiSheet(file, targetRole, undefined, undefined, undefined, (stage, percent) => {
          setUploadProgress({
            fileName: file.name,
            stage,
            percent,
            role: targetRole
          });
        });

        const newSheetsToAppend: SheetState[] = [];
        let totalFileRows = 0;

        for (const rawSheet of parsed.sheets) {
          totalFileRows += rawSheet.rowCount;
          const sheetId = `${fileId}-${rawSheet.sheetName}`;

          newSheetsToAppend.push({
            id: sheetId,
            fileId,
            fileName: file.name,
            sheetName: rawSheet.sheetName,
            grid: rawSheet.partialGrid,
            skipRows: rawSheet.skipRows,
            columns: rawSheet.columns,
            rawRows: undefined,
            rowCount: rawSheet.rowCount,
            detectedKeyCol: rawSheet.detectedKeyCol,
            detectedProductCol: rawSheet.detectedProductCol,
            detectedCasCol: rawSheet.detectedCasCol,
            parsedData: rawSheet.parsedData,
            parsedCasData: rawSheet.parsedCasData,
            uniqueCasNames: rawSheet.uniqueCasNames,
            role: targetRole,
            associatedCasName: targetRole === "CAS" ? associatedCasName : undefined
          });
        }

        if (newSheetsToAppend.length > 0) {
          setFiles(prev => [
            ...prev,
            {
              id: fileId,
              fileName: file.name,
              fileSize: file.size,
              totalRows: totalFileRows,
              sheetCount: newSheetsToAppend.length,
              role: targetRole,
              associatedCasName: targetRole === "CAS" ? associatedCasName : undefined
            }
          ]);
          setSheets(prev => {
            const nextSheets = [...prev, ...newSheetsToAppend];
            if (targetRole === "APP" && continuitySheets) {
              setTimeout(() => {
                reprocessAllContinuitySheets(nextSheets, true);
              }, 50);
            }
            return nextSheets;
          });
        }
      } catch (err) {
        console.error("Error reading file sheets:", err);
        alert(`Could not process spreadsheet: ${file.name}. Ensure it is a valid Excel file.`);
      }
    }
    setUploadProgress(null);
  };

  const reprocessAllContinuitySheets = async (currentSheets: SheetState[], enabled: boolean) => {
    const appSheets = currentSheets.filter(s => s.role === "APP");
    if (appSheets.length <= 1) {
      return;
    }

    const firstAppSheet = appSheets[0];
    const targetSheets = currentSheets.filter(s => s.role === "APP" && s.id !== firstAppSheet.id);
    const totalToProcess = targetSheets.length;
    let processedIndex = 0;

    setUploadProgress({
      fileName: "SMS Source Continuity Alignment",
      stage: enabled ? "Aligning subsequent continuity sheets sequentially..." : "Resetting sheets to standard format...",
      percent: 10,
      role: "APP"
    });

    try {
      const updatedSheets: SheetState[] = [];

      for (const sheet of currentSheets) {
        if (sheet.role !== "APP" || sheet.id === firstAppSheet.id) {
          updatedSheets.push(sheet);
          continue;
        }

        const file = getFileReference(sheet.fileId);
        if (!file) {
          updatedSheets.push(sheet);
          continue;
        }

        processedIndex++;
        const currentProgressPct = Math.round((processedIndex / Math.max(1, totalToProcess)) * 100);

        setUploadProgress({
          fileName: `SMS Source Continuity (${processedIndex}/${totalToProcess}): ${sheet.sheetName}`,
          stage: enabled ? "Aligning header structure..." : "Re-parsing sheet structure...",
          percent: currentProgressPct,
          role: "APP"
        });

        // Small yield to allow React UI to render progress bar smoothly
        await new Promise(r => setTimeout(r, 20));

        if (enabled) {
          // Continuity mode is ON: process without header, using first sheet's header mappings
          const parsed = await parseExcelMultiSheet(
            file,
            "APP",
            0, // skipRows is 0 because subsequent sheets have no headers
            firstAppSheet.detectedKeyCol,
            firstAppSheet.detectedProductCol,
            (stage, percent) => {
              setUploadProgress({
                fileName: `SMS Source Continuity (${processedIndex}/${totalToProcess}): ${sheet.sheetName}`,
                stage,
                percent,
                role: "APP"
              });
            },
            true, // isContinuitySheet
            firstAppSheet.columns,
            firstAppSheet.detectedCasCol
          );
          const updatedRawSheet = parsed.sheets.find(s => s.sheetName === sheet.sheetName);
          if (updatedRawSheet) {
            updatedSheets.push({
              ...sheet,
              skipRows: 0,
              columns: updatedRawSheet.columns,
              rowCount: updatedRawSheet.rowCount,
              detectedKeyCol: updatedRawSheet.detectedKeyCol,
              detectedProductCol: updatedRawSheet.detectedProductCol,
              detectedCasCol: updatedRawSheet.detectedCasCol,
              parsedData: updatedRawSheet.parsedData,
              parsedCasData: updatedRawSheet.parsedCasData,
              grid: updatedRawSheet.partialGrid
            });
            continue;
          }
        } else {
          // Continuity mode is OFF: process normally (auto-detect)
          const parsed = await parseExcelMultiSheet(
            file,
            "APP",
            undefined,
            undefined,
            undefined,
            (stage, percent) => {
              setUploadProgress({
                fileName: `SMS Source Continuity (${processedIndex}/${totalToProcess}): ${sheet.sheetName}`,
                stage,
                percent,
                role: "APP"
              });
            }
          );
          const updatedRawSheet = parsed.sheets.find(s => s.sheetName === sheet.sheetName);
          if (updatedRawSheet) {
            updatedSheets.push({
              ...sheet,
              skipRows: updatedRawSheet.skipRows,
              columns: updatedRawSheet.columns,
              rowCount: updatedRawSheet.rowCount,
              detectedKeyCol: updatedRawSheet.detectedKeyCol,
              detectedProductCol: updatedRawSheet.detectedProductCol,
              detectedCasCol: updatedRawSheet.detectedCasCol,
              parsedData: updatedRawSheet.parsedData,
              parsedCasData: updatedRawSheet.parsedCasData,
              grid: updatedRawSheet.partialGrid
            });
            continue;
          }
        }
        updatedSheets.push(sheet);
      }

      setSheets(updatedSheets);
    } catch (err) {
      console.error("Error aligning continuity sheets:", err);
    } finally {
      setUploadProgress(null);
    }
  };

  const reprocessSheetWithSettings = async (
    sheet: SheetState,
    skipRows: number,
    keyCol: string,
    prodCol: string,
    casCol?: string
  ) => {
    if (sheet.role === "SKIP") return;
    const targetRole = sheet.role;

    const file = getFileReference(sheet.fileId);
    if (!file) return;

    setUploadProgress({
      fileName: file.name,
      stage: "Updating sheet columns and mappings...",
      percent: 30,
      role: targetRole
    });

    try {
      const parsed = await parseExcelMultiSheet(
        file,
        targetRole,
        skipRows,
        keyCol,
        prodCol,
        (stage, percent) => {
          setUploadProgress({
            fileName: file.name,
            stage,
            percent,
            role: targetRole
          });
        },
        undefined,
        undefined,
        casCol
      );

      const updatedRawSheet = parsed.sheets.find(s => s.sheetName === sheet.sheetName);
      if (updatedRawSheet) {
        setSheets(prev => {
          const nextSheets = prev.map(s => {
            if (s.id !== sheet.id) return s;
            return {
              ...s,
              skipRows,
              columns: updatedRawSheet.columns,
              rowCount: updatedRawSheet.rowCount,
              detectedKeyCol: updatedRawSheet.detectedKeyCol,
              detectedProductCol: updatedRawSheet.detectedProductCol,
              detectedCasCol: updatedRawSheet.detectedCasCol,
              parsedData: updatedRawSheet.parsedData,
              parsedCasData: updatedRawSheet.parsedCasData,
              grid: updatedRawSheet.partialGrid
            };
          });

          // Propagation: If first APP sheet changed & continuitySheets enabled, align other APP sheets
          const appSheets = nextSheets.filter(s => s.role === "APP");
          if (continuitySheets && appSheets.length > 1 && sheet.id === appSheets[0].id) {
            setTimeout(() => {
              reprocessAllContinuitySheets(nextSheets, true);
            }, 50);
          }

          return nextSheets;
        });
      }
    } catch (err) {
      console.error("Error updating sheet settings:", err);
    } finally {
      setUploadProgress(null);
    }
  };

  const handleUpdateSheetSkipRows = (sheetId: string, skipRows: number) => {
    const sheet = sheets.find(s => s.id === sheetId);
    if (sheet) {
      // When skipRows changes, the headers change. We clear the manual column overrides so the parser runs fresh auto-detection on the new headers.
      reprocessSheetWithSettings(sheet, skipRows, undefined as any, undefined as any, undefined as any);
    }
  };

  const handleUpdateSheetColumns = (sheetId: string, type: "key" | "product" | "cas", value: string) => {
    const sheet = sheets.find(s => s.id === sheetId);
    if (sheet) {
      const keyCol = type === "key" ? value : sheet.detectedKeyCol;
      const prodCol = type === "product" ? value : sheet.detectedProductCol;
      const casCol = type === "cas" ? value : (sheet.detectedCasCol || "");
      reprocessSheetWithSettings(sheet, sheet.skipRows, keyCol, prodCol, casCol);
    }
  };

  const handleUpdateSheetReferenceSettings = (sheetId: string, enabled: boolean, refFileId: string) => {
    setSheets(prev => prev.map(s => {
      if (s.id !== sheetId) return s;
      return {
        ...s,
        useReferenceFile: enabled,
        selectedReferenceFileId: refFileId
      };
    }));
  };

  const handleUpdateSheetAssociatedCasName = (sheetId: string, associatedCasName: string) => {
    setSheets(prev => prev.map(s => {
      if (s.id !== sheetId) return s;
      return {
        ...s,
        associatedCasName
      };
    }));
  };

  const handleUpdateSheetRole = (sheetId: string, role: "CAS" | "SMS" | "APP" | "SKIP") => {
    setSheets(prev => prev.map(sheet => {
      if (sheet.id !== sheetId) return sheet;
      
      if (role === "SKIP") {
        return {
          ...sheet,
          role,
          parsedData: {}
        };
      }

      const targetRole: "CAS" | "SMS" | "APP" = role;

      const file = getFileReference(sheet.fileId);
      if (!file) {
        return {
          ...sheet,
          role
        };
      }

      setUploadProgress({
        fileName: file.name,
        stage: "Updating sheet analysis role...",
        percent: 30,
        role: targetRole
      });

      parseExcelMultiSheet(
        file,
        targetRole,
        sheet.skipRows,
        undefined,
        undefined,
        (stage, percent) => {
          setUploadProgress({
            fileName: file.name,
            stage,
            percent,
            role: targetRole
          });
        }
      ).then(parsed => {
        const updatedRawSheet = parsed.sheets.find(s => s.sheetName === sheet.sheetName);
        if (updatedRawSheet) {
          setSheets(prev => prev.map(s => {
            if (s.id !== sheet.id) return s;
            return {
              ...s,
              role: targetRole,
              skipRows: updatedRawSheet.skipRows,
              columns: updatedRawSheet.columns,
              rowCount: updatedRawSheet.rowCount,
              detectedKeyCol: updatedRawSheet.detectedKeyCol,
              detectedProductCol: updatedRawSheet.detectedProductCol,
              parsedData: updatedRawSheet.parsedData,
              grid: updatedRawSheet.partialGrid
            };
          }));
        }
      }).catch(err => {
        console.error("Error updating sheet role:", err);
      }).finally(() => {
        setUploadProgress(null);
      });

      return {
        ...sheet,
        role: targetRole
      };
    }));
  };

  const handleContinuitySheetsChange = (checked: boolean) => {
    if (!isLicensedActive) {
      setPremiumFeatureName("Automatic Continuity Sheets Alignment");
      setShowPremiumModal(true);
      return;
    }
    setContinuitySheets(checked);
    reprocessAllContinuitySheets(sheets, checked);
  };

  const handleRemoveSmsFiles = () => {
    setFiles(prev => prev.filter(f => f.role !== "APP" && f.role !== "SMS"));
    setSheets(prev => prev.filter(s => s.role !== "APP" && s.role !== "SMS"));
    if (activeSheetSettingsId) {
      const activeSheet = sheets.find(s => s.id === activeSheetSettingsId);
      if (activeSheet && (activeSheet.role === "APP" || activeSheet.role === "SMS")) {
        setActiveSheetSettingsId(null);
      }
    }
  };

  const handleRemoveCasFiles = () => {
    setFiles(prev => prev.filter(f => f.role !== "CAS"));
    setSheets(prev => prev.filter(s => s.role !== "CAS"));
    if (activeSheetSettingsId) {
      const activeSheet = sheets.find(s => s.id === activeSheetSettingsId);
      if (activeSheet && activeSheet.role === "CAS") {
        setActiveSheetSettingsId(null);
      }
    }
  };

  const handleRemoveFile = (fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
    setSheets(prev => prev.filter(s => s.fileId !== fileId));
    if (activeSheetSettingsId?.startsWith(fileId)) {
      setActiveSheetSettingsId(null);
    }
  };

  return (
    <div className="flex flex-col xl:flex-row gap-3 h-full items-stretch min-h-0">
      {/* 1. SMS UPLOAD */}
      <div className={`transition-all duration-300 min-w-0 ${
        isSmsCollapsed 
          ? "xl:w-[60px] shrink-0" 
          : isCasCollapsed && isLogicCollapsed 
            ? "flex-1" 
            : isCasCollapsed || isLogicCollapsed 
              ? "xl:w-[48%] flex-1" 
              : "xl:w-[31%] flex-1"
      }`}>
        <SmsUploadPanel
          files={files}
          sheets={sheets}
          setFiles={setFiles}
          setSheets={setSheets}
          handleFiles={handleFiles}
          uploadProgress={uploadProgress}
          handleRemoveFile={handleRemoveFile}
          handleRemoveSmsFiles={handleRemoveSmsFiles}
          showApp={showApp}
          showSms={showSms}
          isCollapsed={isSmsCollapsed}
          onToggleCollapse={() => setIsSmsCollapsed(!isSmsCollapsed)}
          continuitySheets={continuitySheets}
          setContinuitySheets={handleContinuitySheetsChange}
          reprocessAllContinuitySheets={reprocessAllContinuitySheets}
          ignoreDigitEnabled={ignoreDigitEnabled}
          setIgnoreDigitEnabled={setIgnoreDigitEnabled}
          ignoreDigitRules={ignoreDigitRules}
          setIgnoreDigitRules={setIgnoreDigitRules}
        />
      </div>

      {/* 2. CAS UPLOAD */}
      <div className={`transition-all duration-300 min-w-0 ${
        isCasCollapsed 
          ? "xl:w-[60px] shrink-0" 
          : isSmsCollapsed && isLogicCollapsed 
            ? "flex-1" 
            : isSmsCollapsed || isLogicCollapsed 
              ? "xl:w-[48%] flex-1" 
              : "xl:w-[31%] flex-1"
      }`}>
        <CasUploadPanel
          files={files}
          sheets={sheets}
          setFiles={setFiles}
          setSheets={setSheets}
          handleFiles={handleFiles}
          uploadProgress={uploadProgress}
          handleRemoveFile={handleRemoveFile}
          handleRemoveCasFiles={handleRemoveCasFiles}
          isCollapsed={isCasCollapsed}
          onToggleCollapse={() => setIsCasCollapsed(!isCasCollapsed)}
        />
      </div>

      {/* 3. ATTACHED LOGIC ASSIGN */}
      <div className={`transition-all duration-300 min-w-0 ${
        isLogicCollapsed 
          ? "xl:w-[60px] shrink-0" 
          : isSmsCollapsed && isCasCollapsed 
            ? "flex-1" 
            : isSmsCollapsed || isCasCollapsed 
              ? "xl:w-[50%] flex-1" 
              : "xl:w-[38%] flex-1"
      }`}>
        <AttachedLogicPanel
          sheets={sheets}
          setSheets={setSheets}
          activeSheetSettingsId={activeSheetSettingsId}
          setActiveSheetSettingsId={setActiveSheetSettingsId}
          handleUpdateSheetSkipRows={handleUpdateSheetSkipRows}
          handleUpdateSheetColumns={handleUpdateSheetColumns}
          handleUpdateSheetRole={handleUpdateSheetRole}
          handleUpdateSheetReferenceSettings={handleUpdateSheetReferenceSettings}
          handleUpdateSheetAssociatedCasName={handleUpdateSheetAssociatedCasName}
          showCas={showCas}
          showSms={showSms}
          showApp={showApp}
          showProductCol={showProductCol}
          isCollapsed={isLogicCollapsed}
          onToggleCollapse={() => setIsLogicCollapsed(!isLogicCollapsed)}
          continuitySheets={continuitySheets}
          setContinuitySheets={handleContinuitySheetsChange}
          reprocessAllContinuitySheets={reprocessAllContinuitySheets}
          globalReferenceEnabled={globalReferenceEnabled}
          setGlobalReferenceEnabled={setGlobalReferenceEnabled}
          globalReferenceMappings={globalReferenceMappings}
          setGlobalReferenceMappings={setGlobalReferenceMappings}
          onNavigateToReference={onNavigateToReference}
        />
      </div>

      {/* Elegant Premium Trial Limit Modal */}
      {showPremiumModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-none">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-2xl max-w-sm w-full space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-amber-500/10 border border-amber-500/25 text-amber-400 rounded-xl">
                <Lock size={20} className="animate-pulse" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-sm uppercase tracking-wide">
                  Premium Feature Locked
                </h3>
                <p className="text-[10px] text-rose-400 font-mono font-bold mt-0.5">
                  UNLICENSED / EXPIRED MODE
                </p>
              </div>
            </div>
            
            <div className="space-y-2 bg-slate-950/50 p-3 rounded-xl border border-slate-850">
              <p className="text-xs text-slate-300 leading-relaxed">
                <span className="font-bold text-indigo-400">{premiumFeatureName}</span> requires a valid, activated license file (.key).
              </p>
            </div>

            <p className="text-[10.5px] text-slate-400 leading-relaxed">
              Activate your license signature key on the <span className="font-bold text-indigo-400">LICENSE</span> page to unlock unlimited multi-stream auditing, continuous sheets alignment, and high-performance exports.
            </p>

            <div className="flex gap-2 pt-1.5">
              <button
                onClick={() => setShowPremiumModal(false)}
                className="flex-1 py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold transition cursor-pointer text-center"
              >
                Dismiss
              </button>
              <button
                onClick={() => setShowPremiumModal(false)}
                className="flex-1 py-1.5 px-3 bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white rounded-lg text-xs font-bold transition cursor-pointer text-center shadow-md shadow-indigo-950/50"
              >
                Unlock
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
