import React, { useState, useEffect } from "react";
import { 
  Key, 
  Lock, 
  Unlock,
  Upload, 
  XCircle, 
  CheckCircle2,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Cpu,
  Globe,
  Terminal,
  Copy,
  Check,
  Clock,
  Trash2,
  Activity,
  FileCheck,
  AlertTriangle,
  Download,
  Eye,
  EyeOff,
  KeyRound,
  Mail,
  HelpCircle,
  LifeBuoy,
  Headphones,
  MessageSquare,
  Send,
  ExternalLink,
  Settings,
  Phone
} from "lucide-react";

interface LicensePageProps {
  onLicenseChange?: (isLicensed: boolean) => void;
}

interface LicenseData {
  product_identity: string;
  hardware_id: string;
  device_hostname: string;
  platform: string;
  expires_at: string;
  generated_at: string;
  node_auth: string;
  protocol: string;
  signature: string;
}

const HOST_XOR_KEY = [32, 7, 23, 75, 39, 100, 110, 85, 111, 86, 82, 23, 7, 114, 98, 124, 34, 11, 82, 28, 23, 124, 111, 101];

// Generate unique browser-level client hardware fingerprint fallback
const generateClientFingerprint = (): string => {
  if (typeof window === "undefined") return "A1B2-C3D4-E5F6-7890";
  try {
    const ua = navigator.userAgent || "";
    const screenRes = `${window.screen.width}x${window.screen.height}x${window.screen.colorDepth}`;
    const lang = navigator.language || "";
    const platform = navigator.platform || "";
    const cores = navigator.hardwareConcurrency || 4;

    const raw = `${ua}|${screenRes}|${lang}|${platform}|${cores}`;
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      const char = raw.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    const absHash = Math.abs(hash).toString(16).toUpperCase().padStart(16, "0");
    return `${absHash.substring(0, 4)}-${absHash.substring(4, 8)}-${absHash.substring(8, 12)}-${absHash.substring(12, 16)}`;
  } catch {
    return "A1B2-C3D4-E5F6-7890";
  }
};

// XOR cipher decryptor with Base64 payload
const xorDecryptBase64 = (b64Str: string, key: string): string => {
  if (!b64Str || !key) return "";
  try {
    const raw = atob(b64Str.trim());
    return Array.from(raw)
      .map((c, i) => String.fromCharCode(c.charCodeAt(0) ^ key.charCodeAt(i % key.length)))
      .join("");
  } catch (e) {
    return "";
  }
};

// Robust decoder/verifier for encrypted, base64, XOR, epoch, or standard license expiry dates
const parseExpiryDate = (data: any, secretKey?: string): Date | null => {
  if (!data) return null;

  const isValidDate = (d: any): d is Date => {
    return d instanceof Date && !isNaN(d.getTime()) && d.getFullYear() > 2000 && d.getFullYear() < 2100;
  };

  let candidate: any = data;
  if (typeof data === "object" && data !== null) {
    candidate = 
      data.expires_at || 
      data.expiry_date || 
      data.expiration_date || 
      data.expiry || 
      data.expiration || 
      data.valid_until || 
      data.expires || 
      data.expire_time || 
      data.exp || 
      data.enc_expiry || 
      data.enc_expires || 
      data.encrypted_expiry || 
      data.encrypted_expiration ||
      data.expiry_timestamp ||
      data.expire_date ||
      data.date;

    if (!candidate) {
      for (const key of Object.keys(data)) {
        const val = data[key];
        if (typeof val === "string" || typeof val === "number") {
          const tryD = parseExpiryDate(val, secretKey);
          if (tryD && isValidDate(tryD)) return tryD;
        }
      }
    }
  }

  if (!candidate) return null;

  const tryNumeric = (val: any): Date | null => {
    const num = Number(val);
    if (!isNaN(num) && num > 0) {
      const ms = num < 10000000000 ? num * 1000 : num;
      const d = new Date(ms);
      if (isValidDate(d)) return d;
    }
    return null;
  };

  const tryStringDate = (str: string): Date | null => {
    if (!str || typeof str !== "string") return null;
    const trimmed = str.trim();
    if (!trimmed) return null;

    let d = new Date(trimmed);
    if (isValidDate(d)) return d;

    d = new Date(trimmed.replace(" ", "T"));
    if (isValidDate(d)) return d;

    d = new Date(trimmed.replace(/-/g, "/"));
    if (isValidDate(d)) return d;

    return null;
  };

  const tryBase64 = (str: string): Date | null => {
    if (!str || typeof str !== "string") return null;
    try {
      const decoded = atob(str.trim());
      if (decoded && decoded !== str) {
        const dNum = tryNumeric(decoded);
        if (dNum) return dNum;

        const dStr = tryStringDate(decoded);
        if (dStr) return dStr;

        if (decoded.startsWith("{") && decoded.endsWith("}")) {
          try {
            const parsed = JSON.parse(decoded);
            const dParsed = parseExpiryDate(parsed, secretKey);
            if (dParsed) return dParsed;
          } catch {}
        }

        if (decoded.includes("|")) {
          for (const part of decoded.split("|")) {
            const dPart = tryNumeric(part) || tryStringDate(part) || tryBase64(part);
            if (dPart) return dPart;
          }
        }
      }
    } catch {}
    return null;
  };

  const tryXOR = (str: string, key?: string): Date | null => {
    if (!str || typeof str !== "string" || !key) return null;
    try {
      const decrypted = xorDecryptBase64(str, key);
      if (!decrypted) return null;

      const dNum = tryNumeric(decrypted);
      if (dNum) return dNum;

      const dStr = tryStringDate(decrypted);
      if (dStr) return dStr;

      if (decrypted.includes("|")) {
        for (const part of decrypted.split("|")) {
          const dPart = tryNumeric(part) || tryStringDate(part);
          if (dPart) return dPart;
        }
      }
    } catch {}
    return null;
  };

  const valStr = String(candidate);

  const resNum = tryNumeric(candidate);
  if (resNum) return resNum;

  const resStr = tryStringDate(valStr);
  if (resStr) return resStr;

  if (secretKey) {
    const resXOR = tryXOR(valStr, secretKey);
    if (resXOR) return resXOR;
  }

  const resB64 = tryBase64(valStr);
  if (resB64) return resB64;

  if (typeof valStr === "string" && /^[0-9a-fA-F]+$/.test(valStr)) {
    try {
      const hexStr = valStr.replace(/^0x/, "");
      let str = "";
      for (let i = 0; i < hexStr.length; i += 2) {
        str += String.fromCharCode(parseInt(hexStr.substr(i, 2), 16));
      }
      const resHex = tryNumeric(str) || tryStringDate(str) || tryBase64(str);
      if (resHex) return resHex;
    } catch {}
  }

  return null;
};

export default function LicensePage({ onLicenseChange }: LicensePageProps) {
  // Load saved license data if any
  const [licenseData, setLicenseData] = useState<LicenseData | null>(() => {
    try {
      const saved = localStorage.getItem("ya_license_data");
      if (saved) {
        const parsed = JSON.parse(saved) as LicenseData;
        const decodedExpiry = parseExpiryDate(parsed);
        if (decodedExpiry) {
          parsed.expires_at = decodedExpiry.toISOString();
          if (decodedExpiry.getTime() <= Date.now()) {
            localStorage.setItem("ya_is_licensed", "false");
            return null; // Already expired
          }
        }
        return parsed;
      }
    } catch (e) {
      // ignore
    }
    return null;
  });

  // Sync state with localStorage
  const [isLicensedState, setIsLicensedState] = useState(() => {
    if (localStorage.getItem("ya_is_licensed") !== "true") return false;
    const saved = localStorage.getItem("ya_license_data");
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as LicenseData;
        const decodedExpiry = parseExpiryDate(parsed);
        if (decodedExpiry && decodedExpiry.getTime() <= Date.now()) {
          localStorage.setItem("ya_is_licensed", "false");
          return false;
        }
      } catch (e) {
        // ignore
      }
    }
    return true;
  });

  // Auto-detect Hardware ID (Uses unique hardware fingerprint if no stored ID)
  const [hardwareId, setHardwareId] = useState(() => {
    let stored = localStorage.getItem("ya_detected_hwid");
    if (!stored || stored === "M4Z9-KCRV-HU7A-ZZXP") {
      stored = generateClientFingerprint();
      localStorage.setItem("ya_detected_hwid", stored);
    }
    return stored;
  });

  // Track remaining time countdown
  const [timeRemaining, setTimeRemaining] = useState<string>("Calculating...");
  const [, setIsExpired] = useState(false);

  // Auto-detect Hostname
  const [hostname, setHostname] = useState(() => {
    if (typeof window !== "undefined") {
      return window.location.hostname || "localhost";
    }
    return "localhost";
  });

  // Fetch license state & unique system-info from Express backend API on component mount
  useEffect(() => {
    fetch("/api/license")
      .then((res) => res.json())
      .then((data) => {
        if (data && data.isLicensed && data.licenseData) {
          localStorage.setItem("ya_is_licensed", "true");
          localStorage.setItem("ya_license_data", JSON.stringify(data.licenseData));
          setLicenseData(data.licenseData);
          setIsLicensedState(true);
          onLicenseChange?.(true);
        }
      })
      .catch((err) => console.log("Backend license fetch error:", err));

    fetch("/api/system-info")
      .then((res) => res.json())
      .then((info) => {
        if (info && info.hardwareId) {
          const stored = localStorage.getItem("ya_detected_hwid");
          if (!stored || stored === "M4Z9-KCRV-HU7A-ZZXP") {
            setHardwareId(info.hardwareId);
            localStorage.setItem("ya_detected_hwid", info.hardwareId);
          }
        }
        if (info && info.hostname) {
          setHostname(info.hostname);
        }
      })
      .catch(() => {});
  }, []);

  // Auto-detect Platform
  const [platform] = useState(() => {
    if (typeof navigator !== "undefined") {
      const ua = navigator.userAgent.toLowerCase();
      if (ua.includes("win")) return "WINDOWS";
      if (ua.includes("mac")) return "MACOS";
      if (ua.includes("linux")) return "LINUX";
      if (ua.includes("android")) return "ANDROID";
      if (ua.includes("iphone") || ua.includes("ipad")) return "IOS";
    }
    return "LINUX";
  });

  const [notification, setNotification] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [authKeyInput, setAuthKeyInput] = useState("");
  const [secretKeyInput, setSecretKeyInput] = useState("s^VFn10UaZhKV*cx");
  const [showSecretKey, setShowSecretKey] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState("");
  const [isFieldsUnlocked, setIsFieldsUnlocked] = useState(false);

  // Clipboard copy state
  const [copiedHwid, setCopiedHwid] = useState(false);
  const [copiedHost, setCopiedHost] = useState(false);
  const [copiedSupportEmail, setCopiedSupportEmail] = useState(false);
  const [copiedAccountsEmail, setCopiedAccountsEmail] = useState(false);

  // Security confirmation modal for license revocation
  const [showRevokeModal, setShowRevokeModal] = useState(false);

  // Drag-and-drop state
  const [isDragging, setIsDragging] = useState(false);

  // Helper to normalize hostnames
  const cleanHost = (h?: string): string => {
    if (!h) return "";
    return h.replace(/^https?:\/\//, "").split(":")[0].trim().toLowerCase();
  };

  // Helper to obfuscate device hostname using XOR key
  const getObfuscatedHostname = (host: string): string => {
    let padded = host;
    if (padded.length < 24) {
      padded = padded.padEnd(24, " ");
    } else if (padded.length > 24) {
      padded = padded.substring(0, 24);
    }
    
    const bytes = [];
    for (let i = 0; i < 24; i++) {
      bytes.push(padded.charCodeAt(i) ^ HOST_XOR_KEY[i]);
    }
    
    return btoa(String.fromCharCode(...bytes));
  };

  // Sync remaining time dynamic countdown
  useEffect(() => {
    if (!isLicensedState || !licenseData) {
      return;
    }

    const updateTimer = () => {
      const expiryDate = parseExpiryDate(licenseData, secretKeyInput);

      if (!expiryDate || isNaN(expiryDate.getTime())) {
        setTimeRemaining("Valid License");
        return;
      }

      const expiryTime = expiryDate.getTime();
      const now = Date.now();
      const diff = expiryTime - now;

      if (diff <= 0) {
        setTimeRemaining("Expired");
        setIsExpired(true);
        // Automatically revoke license on expiration
        localStorage.setItem("ya_is_licensed", "false");
        setIsLicensedState(false);
        onLicenseChange?.(false);
        setNotification({
          type: "error",
          text: "License has expired! System returned to Expired / Unlicensed mode."
        });
      } else {
        setIsExpired(false);
        const secs = Math.floor(diff / 1000);
        const mins = Math.floor(secs / 60);
        const hours = Math.floor(mins / 60);
        const days = Math.floor(hours / 24);

        const rHours = hours % 24;
        const rMins = mins % 60;
        const rSecs = secs % 60;

        let str = "";
        if (days > 0) str += `${days}d `;
        if (hours > 0 || days > 0) str += `${rHours}h `;
        str += `${rMins}m ${rSecs}s`;
        setTimeRemaining(str);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [isLicensedState, licenseData, onLicenseChange, secretKeyInput]);

  const handleCopyHwid = () => {
    navigator.clipboard.writeText(hardwareId);
    setCopiedHwid(true);
    setNotification({ type: "success", text: "Hardware ID copied to clipboard!" });
    setTimeout(() => setCopiedHwid(false), 2000);
  };

  const handleCopyHost = () => {
    navigator.clipboard.writeText(hostname);
    setCopiedHost(true);
    setNotification({ type: "success", text: "Device Hostname copied to clipboard!" });
    setTimeout(() => setCopiedHost(false), 2000);
  };

  const handleCopySupportEmail = () => {
    navigator.clipboard.writeText("support@yatech.co.in");
    setCopiedSupportEmail(true);
    setNotification({ type: "success", text: "Technical support email support@yatech.co.in copied!" });
    setTimeout(() => setCopiedSupportEmail(false), 2000);
  };

  const handleCopyAccountsEmail = () => {
    navigator.clipboard.writeText("accounts@yatech.co.in");
    setCopiedAccountsEmail(true);
    setNotification({ type: "success", text: "Accounts email accounts@yatech.co.in copied!" });
    setTimeout(() => setCopiedAccountsEmail(false), 2000);
  };

  const handleGenerateAppDetails = () => {
    try {
      const appDetails = {
        product_identity: "YA AUDIT TOOL V.0.1",
        hardware_id: hardwareId,
        device_hostname: hostname,
        platform: platform,
        node_auth: "0x9047489741",
        protocol: "RBAC-LEVEL-3",
        exported_at: new Date().toISOString()
      };

      const dataStr = JSON.stringify(appDetails, null, 2);
      const blob = new Blob([dataStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.download = `ya_app_details_${hardwareId}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setNotification({
        type: "success",
        text: "App details JSON file generated and downloaded successfully!"
      });

      setTimeout(() => {
        setNotification(null);
      }, 4000);
    } catch (e) {
      setNotification({
        type: "error",
        text: "Failed to generate app details JSON file."
      });
    }
  };

  // File loading function
  const processFileContent = (text: string, fileName: string) => {
    if (!fileName.toLowerCase().endsWith(".key")) {
      setNotification({
        type: "error",
        text: "Invalid file format! Only .key license files are accepted."
      });
      return;
    }

    setUploadedFileName(fileName);
    setAuthKeyInput(text.trim());
    setNotification({
      type: "success",
      text: `Loaded license file: ${fileName}`
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        processFileContent(text, file.name);
      } catch (err) {
        setNotification({ type: "error", text: "Failed to read license file." });
      }
    };
    reader.readAsText(file);
  };

  // Drag-and-drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (isFieldsUnlocked) {
      setIsDragging(true);
    }
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (!isFieldsUnlocked) return;

    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        processFileContent(text, file.name);
      } catch (err) {
        setNotification({ type: "error", text: "Failed to read dropped license file." });
      }
    };
    reader.readAsText(file);
  };

  const handleSubmitLicense = () => {
    const rawInput = authKeyInput.trim();
    const cleanSecretKey = secretKeyInput.trim();

    if (!cleanSecretKey) {
      setNotification({
        type: "error",
        text: "Please enter the Encryption Secret Key alongside your license file!"
      });
      return;
    }

    if (!uploadedFileName || !rawInput) {
      setNotification({
        type: "error",
        text: "Please upload a valid .key license file!"
      });
      return;
    }

    let parsedJson: (LicenseData & { secret_key?: string; app_secret_key?: string }) | null = null;
    let signatureToValidate = rawInput;

    if (rawInput.startsWith("{") && rawInput.endsWith("}")) {
      try {
        parsedJson = JSON.parse(rawInput);
        signatureToValidate = parsedJson?.signature || rawInput;
      } catch (e) {
        setNotification({
          type: "error",
          text: "Invalid JSON format in license file!"
        });
        return;
      }
    }

    // Try to decode base64 signature/input
    let decodedString = signatureToValidate;
    try {
      const b64Decoded = atob(signatureToValidate);
      if (b64Decoded && (b64Decoded.includes("|") || b64Decoded.startsWith("{"))) {
        decodedString = b64Decoded;
      }
    } catch (e) {
      // not base64, keep raw signatureToValidate
    }

    // Check JSON explicit secret key if present
    if (parsedJson) {
      const jsonSecret = parsedJson.secret_key || parsedJson.app_secret_key;
      if (jsonSecret && jsonSecret !== cleanSecretKey) {
        setNotification({
          type: "error",
          text: "Encryption Secret Key mismatch! The provided secret key does not match the license file."
        });
        return;
      }
    }

    let isSignatureValid = false;
    let extractedExpiresAt: string | null = null;
    let extractedProdId = parsedJson?.product_identity || "YA AUDIT TOOL V.0.1";
    let extractedHwid = parsedJson?.hardware_id || hardwareId;
    let extractedHostname = parsedJson?.device_hostname || hostname;
    let extractedPlatform = parsedJson?.platform || platform;
    let extractedNodeAuth = parsedJson?.node_auth || "0x9047489741";
    let extractedProtocol = parsedJson?.protocol || "RBAC-LEVEL-3";

    // 1. Decrypt signature payload using XOR Cipher + Base64 with cleanSecretKey
    const xorDecryptedSig = xorDecryptBase64(signatureToValidate, cleanSecretKey);
    let sigParts = xorDecryptedSig ? xorDecryptedSig.split("|") : [];

    // Fallback: Check if signature is plain base64 encoded pipe string
    if (sigParts.length < 8) {
      try {
        const plainDecoded = atob(signatureToValidate);
        if (plainDecoded.includes("|")) {
          sigParts = plainDecoded.split("|");
        }
      } catch {}
    }

    // Check 8-part pipe structure: PROD_ID|HW_ID|HOST|PLATFORM|EXPIRES_AT|NODE_AUTH|PROTOCOL|SECRET_KEY
    if (sigParts.length >= 8) {
      const [pProdId, pHwid, pHost, pPlat, pExpAt, pNodeAuth, pProto, pSecretKey] = sigParts;

      // 1. Secret Key Check
      if (pSecretKey !== cleanSecretKey) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }
      if (parsedJson?.secret_key && parsedJson.secret_key !== cleanSecretKey) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      // 2. Hardware ID Check (Machine match)
      if (pHwid !== "GLOBAL" && pHwid !== "*" && pHwid !== hardwareId) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }
      if (parsedJson?.hardware_id && parsedJson.hardware_id !== "GLOBAL" && parsedJson.hardware_id !== "*" && parsedJson.hardware_id !== hardwareId) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      // 3. Product Identity Check
      if (parsedJson?.product_identity && parsedJson.product_identity !== pProdId) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      // 4. Device Hostname Check (Exact machine match against signature & license)
      const sysHost = (hostname || "").toLowerCase().trim();
      const sigHost = (pHost || "").toLowerCase().trim();
      const jsonHost = (parsedJson?.device_hostname || "").toLowerCase().trim();

      if (sigHost !== "global" && sigHost !== "*" && sigHost !== sysHost) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }
      if (jsonHost && jsonHost !== "global" && jsonHost !== "*" && jsonHost !== sysHost) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }
      if (jsonHost && jsonHost !== sigHost && jsonHost !== "global" && sigHost !== "global" && jsonHost !== "*" && sigHost !== "*") {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      // 5. Platform Check (Machine match)
      const normPlat = (p: string) => {
        const u = (p || "").toUpperCase().trim();
        return u === "WIN32" ? "WINDOWS" : u === "DARWIN" ? "MACOS" : u;
      };
      const sysPlat = normPlat(platform);
      const sigPlat = normPlat(pPlat);
      const jsonPlat = normPlat(parsedJson?.platform || "");

      if (sigPlat !== "GLOBAL" && sigPlat !== "*") {
        if (sigPlat !== sysPlat) {
          setNotification({
            type: "error",
            text: "Unauthorized License"
          });
          return;
        }
      }
      if (jsonPlat && jsonPlat !== "GLOBAL" && jsonPlat !== "*") {
        if (jsonPlat !== sysPlat) {
          setNotification({
            type: "error",
            text: "Unauthorized License"
          });
          return;
        }
      }
      if (jsonPlat && jsonPlat !== sigPlat && jsonPlat !== "GLOBAL" && sigPlat !== "GLOBAL" && jsonPlat !== "*" && sigPlat !== "*") {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      // 6. Node Auth Check
      if (parsedJson?.node_auth && parsedJson.node_auth !== pNodeAuth) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      // 7. Protocol Check
      if (parsedJson?.protocol && parsedJson.protocol !== pProto) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      // 8. Expiration Date Check
      const expDate = parseExpiryDate(pExpAt, cleanSecretKey) ||
        parseExpiryDate(parsedJson?.expires_at, cleanSecretKey) ||
        parseExpiryDate(parsedJson, cleanSecretKey);

      if (!expDate || isNaN(expDate.getTime())) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      if (expDate.getTime() <= Date.now()) {
        setNotification({
          type: "error",
          text: "Unauthorized License"
        });
        return;
      }

      extractedProdId = pProdId;
      extractedHwid = pHwid;
      extractedHostname = pHost;
      extractedPlatform = pPlat;
      extractedExpiresAt = pExpAt;
      extractedNodeAuth = pNodeAuth;
      extractedProtocol = pProto;
      isSignatureValid = true;
    } else {
      // Signature could not be decrypted or did not yield valid 8-part payload matching secret_key
      setNotification({
        type: "error",
        text: "Unauthorized License"
      });
      return;
    }

    if (!isSignatureValid) {
      setNotification({
        type: "error",
        text: "Unauthorized License"
      });
      return;
    }

    // Decode and verify Expiration Date from signature, JSON expires_at, or XOR candidate
    const expDate = parseExpiryDate(extractedExpiresAt, cleanSecretKey) ||
      parseExpiryDate(parsedJson?.expires_at, cleanSecretKey) ||
      parseExpiryDate(parsedJson, cleanSecretKey);

    if (!expDate || isNaN(expDate.getTime())) {
      setNotification({
        type: "error",
        text: "Unauthorized License"
      });
      return;
    }

    if (expDate.getTime() <= Date.now()) {
      setNotification({
        type: "error",
        text: "Unauthorized License"
      });
      return;
    }

    const finalExpiresAtStr = expDate.toISOString();

    const licenseObj: LicenseData = {
      product_identity: extractedProdId,
      hardware_id: extractedHwid,
      device_hostname: extractedHostname,
      platform: extractedPlatform,
      expires_at: finalExpiresAtStr,
      generated_at: parsedJson?.generated_at || new Date().toISOString(),
      node_auth: extractedNodeAuth,
      protocol: extractedProtocol,
      signature: signatureToValidate
    };

    localStorage.setItem("ya_is_licensed", "true");
    localStorage.setItem("ya_license_data", JSON.stringify(licenseObj));

    setLicenseData(licenseObj);
    setIsLicensedState(true);
    onLicenseChange?.(true);

    // Sync license activation with backend API
    try {
      fetch("/api/license/activate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rawInput,
          secretKey: cleanSecretKey,
          hardwareId,
          hostname,
          platform
        })
      }).catch((e) => console.error("Backend activation sync error:", e));
    } catch (e) {
      // client-side fallback continues
    }

    setNotification({
      type: "success",
      text: "Valid License"
    });

    setTimeout(() => {
      setNotification(null);
    }, 5000);
  };

  const handleLockSystem = () => {
    setShowRevokeModal(false);
    localStorage.setItem("ya_is_licensed", "false");
    localStorage.removeItem("ya_license_data");
    setIsLicensedState(false);
    setLicenseData(null);
    onLicenseChange?.(false);
    setAuthKeyInput("");
    setUploadedFileName("");
    setIsFieldsUnlocked(false);

    // Revoke license on backend
    try {
      fetch("/api/license/revoke", { method: "POST" }).catch((e) => console.error("Backend revoke error:", e));
    } catch (e) {}

    setNotification({
      type: "success",
      text: "License revoked. App set to Expired / Unlicensed mode."
    });
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  return (
    <div id="license-workspace-container" className="space-y-6 w-full mx-auto py-6 px-4 sm:px-6 lg:px-10 bg-[#080b11] text-slate-100 rounded-3xl border border-slate-900/80 shadow-2xl relative">
      
      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-[200] flex items-center space-x-3 px-4 py-3 bg-slate-900 border border-indigo-500/30 rounded-xl shadow-2xl max-w-sm animate-in fade-in slide-in-from-bottom-2">
          {notification.type === "success" ? (
            <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
          ) : (
            <XCircle size={16} className="text-rose-400 shrink-0" />
          )}
          <span className="text-xs font-semibold text-slate-200 leading-relaxed">
            {notification.text}
          </span>
        </div>
      )}

      {/* Header Banner & Support Header Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 pb-6 border-b border-slate-900/80">
        
        {/* Left / Center Header Box (Client Device License Status) */}
        <div className="xl:col-span-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-slate-900/40 border border-slate-900/80 rounded-2xl shadow-xl">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-gradient-to-br from-indigo-500 to-indigo-700 rounded-2xl shadow-lg shadow-indigo-950/20 text-white shrink-0">
              <Shield size={28} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-black uppercase tracking-wider text-slate-100">
                Client Device License Status
              </h1>
              <p className="text-[11px] font-bold text-slate-500 tracking-widest uppercase font-mono mt-0.5">
                Device Hardware Profile & External License Authorization
              </p>
            </div>
          </div>

          {/* System Status badge */}
          <div className="flex items-center space-x-3 shrink-0">
            {isLicensedState ? (
              <div className="inline-flex items-center space-x-2 px-4 py-2 bg-emerald-950/30 border border-emerald-900/60 rounded-xl text-emerald-400 text-xs font-bold uppercase tracking-wider shadow-lg shadow-emerald-950/10">
                <ShieldCheck size={16} className="text-emerald-400" />
                <span>Licensed (Active)</span>
              </div>
            ) : (
              <div className="inline-flex items-center space-x-2 px-4 py-2 bg-rose-950/30 border border-rose-900/60 rounded-xl text-rose-400 text-xs font-bold uppercase tracking-wider shadow-lg shadow-rose-950/10">
                <AlertTriangle size={16} className="text-rose-400" />
                <span>Expired / Unlicensed Mode</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Header Box (Support) */}
        <div className="flex items-center justify-between p-5 bg-slate-900/40 border border-slate-900/80 rounded-2xl shadow-xl">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-2xl shrink-0">
              <Headphones size={24} />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase tracking-wider text-slate-100">
                Support
              </h2>
              <p className="text-[10.5px] font-bold text-slate-500 uppercase font-mono tracking-wider">
                Accounts & Technical Assistance
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 rounded-lg text-[10px] font-mono font-bold uppercase shrink-0">
            24/7 SLA
          </span>
        </div>

      </div>

      {/* Grid Layout - Hardware Profile, License Controller, and Support Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 items-start">
        
        {/* Column 1: Client Device Hardware & App Profile */}
        <div className="bg-slate-900/30 border border-slate-900/80 rounded-2xl p-6 space-y-6">
          <div className="flex items-center space-x-2.5 pb-3 border-b border-slate-900/60">
            <Cpu size={18} className="text-indigo-400" />
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Client Device Hardware Profile
            </h3>
          </div>



          {/* Device details list */}
          <div className="space-y-3">
            {[
              { 
                label: "HARDWARE ID", 
                val: hardwareId, 
                icon: <Cpu size={15} className="text-indigo-400" />,
                copyAction: handleCopyHwid,
                copiedState: copiedHwid,
                highlight: true
              },
              { 
                label: "DEVICE HOSTNAME", 
                val: hostname, 
                icon: <Globe size={15} className="text-indigo-400" />,
                copyAction: handleCopyHost,
                copiedState: copiedHost
              },
              { 
                label: "OPERATING PLATFORM", 
                val: platform, 
                icon: <Terminal size={15} className="text-slate-400" /> 
              }
            ].map((item, idx) => (
              <div 
                key={idx} 
                className={`flex items-center justify-between p-3 rounded-xl transition border ${
                  item.highlight 
                    ? "bg-slate-950/70 border-indigo-500/30" 
                    : "bg-slate-950/40 border-slate-900/80"
                }`}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-400 shrink-0">
                    {item.icon}
                  </div>
                  <div className="min-w-0">
                    <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                      {item.label}
                    </span>
                    <span className={`block text-xs font-black truncate font-mono ${item.highlight ? "text-indigo-300" : "text-slate-200"}`}>
                      {item.val}
                    </span>
                  </div>
                </div>
                {item.copyAction && (
                  <button
                    type="button"
                    onClick={item.copyAction}
                    title="Copy to clipboard"
                    className="p-2 bg-slate-900 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/40 rounded-lg text-slate-400 hover:text-indigo-300 transition cursor-pointer shrink-0"
                  >
                    {item.copiedState ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-900/60 flex items-center justify-between text-[10px] font-mono text-slate-500">
            <span>Status: Client Ready</span>
            <span className="text-indigo-400 font-bold">Bound to Local Environment</span>
          </div>

          <div className="pt-4 border-t border-slate-900/60">
            <button
              type="button"
              onClick={handleGenerateAppDetails}
              className="w-full py-3 px-4 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-400 hover:to-indigo-500 text-white font-black uppercase text-xs tracking-wider rounded-xl shadow-lg shadow-indigo-950/30 transition flex items-center justify-center space-x-2 cursor-pointer hover:scale-[1.01] active:scale-[0.99]"
            >
              <Download size={15} />
              <span>Generate App Details</span>
            </button>
          </div>
        </div>

        {/* Column 2: License Validity & External Key Upload */}
        <div className="bg-slate-900/30 border border-slate-900/80 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-900/60">
            <div className="flex items-center space-x-2.5">
              <FileCheck size={18} className="text-emerald-400" />
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                License Activation & Validity
              </h3>
            </div>
            {!isLicensedState && (
              <button
                type="button"
                onClick={() => setIsFieldsUnlocked(!isFieldsUnlocked)}
                className={`inline-flex items-center space-x-1.5 py-1 px-3 rounded-lg text-[10px] font-black uppercase tracking-wider transition cursor-pointer ${
                  isFieldsUnlocked
                    ? "bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30"
                    : "bg-slate-900 border border-slate-800 text-slate-400 hover:bg-slate-800"
                }`}
              >
                {isFieldsUnlocked ? <Unlock size={11} /> : <Lock size={11} />}
                <span>{isFieldsUnlocked ? "Editing Unlocked" : "Enable Input"}</span>
              </button>
            )}
          </div>

          {!isLicensedState ? (
            /* Unlicensed State: Key Input & File Upload */
            <div className="space-y-5">
              <p className="text-xs text-slate-400 leading-relaxed">
                Provide your <strong>Encryption Secret Key</strong> and upload your <strong>License File</strong> (<code className="text-indigo-300 font-mono">.key</code>). Both must match to activate your client license.
              </p>

              <div 
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`space-y-4 rounded-2xl border p-5 transition ${
                  isDragging 
                    ? "border-indigo-500 bg-indigo-950/20" 
                    : "border-slate-900/80 bg-slate-950/40"
                }`}
              >
                {/* Secret Key Input Field */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="block text-[9px] font-extrabold text-indigo-300 uppercase tracking-widest font-mono flex items-center space-x-1.5">
                      <KeyRound size={11} className="text-indigo-400" />
                      <span>1. Encryption Secret Key</span>
                    </label>
                    <span className="text-[9px] text-slate-500 font-mono">Must match license file</span>
                  </div>
                  <div className="relative">
                    <input
                      type={showSecretKey ? "text" : "password"}
                      value={secretKeyInput}
                      onChange={(e) => setSecretKeyInput(e.target.value)}
                      placeholder={isFieldsUnlocked ? "Enter Encryption Secret Key..." : "🔒 Enable Input above to edit"}
                      disabled={!isFieldsUnlocked}
                      className={`w-full py-2.5 pl-3 pr-10 text-xs font-mono bg-slate-950 border rounded-xl focus:outline-none focus:border-indigo-500 transition ${
                        !isFieldsUnlocked 
                          ? "border-slate-950 text-slate-600 bg-slate-950/20 cursor-not-allowed" 
                          : "border-slate-800 text-indigo-300"
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowSecretKey(!showSecretKey)}
                      disabled={!isFieldsUnlocked}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition cursor-pointer"
                      title={showSecretKey ? "Hide Secret Key" : "Show Secret Key"}
                    >
                      {showSecretKey ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>

                {/* File Upload Zone */}
                <div className="space-y-1.5">
                  <label className="block text-[9px] font-extrabold text-indigo-300 uppercase tracking-widest font-mono flex items-center space-x-1.5">
                    <Upload size={11} className="text-indigo-400" />
                    <span>2. Upload License File (.key)</span>
                  </label>
                  <div>
                    <input
                      type="file"
                      id="client-license-file-upload"
                      accept=".key"
                      className="hidden"
                      onChange={handleFileUpload}
                      disabled={!isFieldsUnlocked}
                    />
                    {uploadedFileName ? (
                      <div className="border border-indigo-500/40 rounded-xl p-3.5 text-center flex items-center justify-between bg-slate-950/60">
                        <div className="flex items-center space-x-2.5 min-w-0">
                          <FileCheck size={18} className="text-indigo-400 shrink-0" />
                          <span className="text-xs font-bold text-indigo-300 truncate">
                            {uploadedFileName}
                          </span>
                        </div>
                        <button
                          type="button"
                          disabled={!isFieldsUnlocked}
                          onClick={() => {
                            setUploadedFileName("");
                            setAuthKeyInput("");
                          }}
                          className={`text-[10px] font-bold uppercase tracking-wider text-rose-400 hover:text-rose-300 transition px-2.5 py-1 bg-rose-950/30 hover:bg-rose-950/50 rounded-lg border border-rose-900/40 cursor-pointer ${
                            !isFieldsUnlocked ? "opacity-40 cursor-not-allowed" : ""
                          }`}
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <label
                        htmlFor={isFieldsUnlocked ? "client-license-file-upload" : undefined}
                        className={`w-full border-2 border-dashed rounded-xl p-5 text-center flex flex-col items-center justify-center space-y-2 transition duration-200 ${
                          !isFieldsUnlocked
                            ? "border-slate-950 bg-slate-950/20 cursor-not-allowed opacity-40 select-none"
                            : "border-slate-800 hover:border-indigo-500/60 bg-slate-950/30 hover:bg-slate-950/60 cursor-pointer"
                        }`}
                      >
                        <Upload size={22} className={!isFieldsUnlocked ? "text-slate-700" : "text-indigo-400"} />
                        <span className={`text-xs font-bold uppercase tracking-wider ${!isFieldsUnlocked ? "text-slate-600" : "text-slate-300"}`}>
                          {isDragging 
                            ? "Drop .key file here!" 
                            : isFieldsUnlocked 
                              ? "Drag & Drop or Click to Upload .key License File" 
                              : "Click 'Enable Input' above to upload .key file"}
                        </span>
                      </label>
                    )}
                  </div>
                </div>

                {/* Submit Action Button */}
                <button
                  type="button"
                  onClick={handleSubmitLicense}
                  disabled={!isFieldsUnlocked}
                  className={`w-full py-3 font-black uppercase text-xs tracking-wider rounded-xl flex items-center justify-center space-x-2 transition shadow-lg ${
                    !isFieldsUnlocked
                      ? "bg-slate-900 text-slate-600 border border-slate-950 cursor-not-allowed opacity-40 shadow-none"
                      : "bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-400 hover:to-indigo-500 text-white cursor-pointer shadow-indigo-950/30 hover:scale-[1.01] active:scale-[0.99]"
                  }`}
                >
                  <Lock size={14} />
                  <span>Activate Client License</span>
                </button>
              </div>
            </div>
          ) : (
            /* Active License Info Card */
            <div className="bg-emerald-950/20 border border-emerald-900/60 p-5 rounded-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-emerald-900/40">
                <div className="flex items-center space-x-2.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
                    Active Verified License
                  </span>
                </div>
                <span className="text-[10px] font-bold text-emerald-300 font-mono bg-emerald-950/60 border border-emerald-800/60 px-2.5 py-0.5 rounded-md">
                  AUTHENTICATED
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                    LICENSED PRODUCT
                  </span>
                  <span className="block font-bold text-slate-200 mt-0.5">
                    {licenseData?.product_identity || "YA AUDIT TOOL V.0.1"}
                  </span>
                </div>
                <div>
                  <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                    OPERATING PLATFORM
                  </span>
                  <span className="block font-bold text-slate-200 font-mono mt-0.5">
                    {licenseData?.platform || platform}
                  </span>
                </div>
              </div>

              {/* Countdown Section */}
              <div className="p-3.5 bg-slate-950/60 border border-emerald-900/40 rounded-xl space-y-1">
                <div className="flex items-center space-x-1.5 text-slate-400">
                  <Clock size={13} className="text-emerald-400 shrink-0" />
                  <span className="text-[10px] font-bold uppercase tracking-wider font-mono text-emerald-400">
                    Remaining License Validity
                  </span>
                </div>
                <span className="block text-xl font-black text-emerald-300 font-mono tracking-wider">
                  {timeRemaining}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-[11px] pt-1">
                <div>
                  <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                    ISSUED / GENERATED AT
                  </span>
                  <span className="block text-slate-300 font-mono mt-0.5">
                    {licenseData?.generated_at ? new Date(licenseData.generated_at).toLocaleString() : "N/A"}
                  </span>
                </div>
                <div>
                  <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                    EXPIRATION DATE
                  </span>
                  <span className="block text-amber-400 font-mono font-bold mt-0.5">
                    {(() => {
                      const expD = parseExpiryDate(licenseData, secretKeyInput);
                      if (expD && !isNaN(expD.getTime())) {
                        return expD.toLocaleString();
                      }
                      if (licenseData?.expires_at) {
                        const d = new Date(licenseData.expires_at);
                        if (!isNaN(d.getTime())) return d.toLocaleString();
                      }
                      return "N/A";
                    })()}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowRevokeModal(true)}
                className="w-full mt-2 py-2.5 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-rose-400 font-bold uppercase text-[10px] tracking-wider rounded-xl border border-slate-800 hover:border-rose-950/50 transition cursor-pointer flex items-center justify-center space-x-2"
              >
                <Trash2 size={12} />
                <span>Deauthorize & Revoke License</span>
              </button>
            </div>
          )}
        </div>

        {/* Column 3: Technical Support Desk */}
        <div className="bg-slate-900/30 border border-slate-900/80 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-900/60">
            <div className="flex items-center space-x-2.5">
              <Headphones size={18} className="text-indigo-400" />
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Technical Support Desk
              </h3>
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/40 border border-emerald-900/60 px-2 py-0.5 rounded font-mono">
              ONLINE
            </span>
          </div>



          {/* Accounts & Support Cards */}
          <div className="space-y-3">
            {/* For Account Card */}
            <div className="p-3.5 bg-slate-950/70 border border-indigo-500/30 rounded-2xl space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                  <Mail size={12} className="text-indigo-400" />
                  <span>FOR ACCOUNT & RENEWAL</span>
                </span>
                <span className="text-[9px] font-mono text-indigo-300 font-bold bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-900/60">
                  BILLING
                </span>
              </div>

              <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-2 rounded-xl">
                <span className="text-xs font-mono font-bold text-indigo-300 truncate">
                  accounts@yatech.co.in
                </span>
                <button
                  type="button"
                  onClick={handleCopyAccountsEmail}
                  title="Copy Accounts Email"
                  className="p-1 bg-slate-950 hover:bg-indigo-950/50 border border-slate-800 hover:border-indigo-500/40 rounded-lg text-slate-400 hover:text-indigo-300 transition cursor-pointer shrink-0 ml-2"
                >
                  {copiedAccountsEmail ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                </button>
              </div>
            </div>

            {/* For Support Card */}
            <div className="p-3.5 bg-slate-950/70 border border-sky-500/30 rounded-2xl space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                  <Mail size={12} className="text-sky-400" />
                  <span>FOR TECHNICAL SUPPORT</span>
                </span>
                <span className="text-[9px] font-mono text-sky-300 font-bold bg-sky-950/60 px-2 py-0.5 rounded border border-sky-900/60">
                  24/7 HELPDESK
                </span>
              </div>

              <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-2 rounded-xl">
                <span className="text-xs font-mono font-bold text-sky-300 truncate">
                  support@yatech.co.in
                </span>
                <button
                  type="button"
                  onClick={handleCopySupportEmail}
                  title="Copy Support Email"
                  className="p-1 bg-slate-950 hover:bg-sky-950/50 border border-slate-800 hover:border-sky-500/40 rounded-lg text-slate-400 hover:text-sky-300 transition cursor-pointer shrink-0 ml-2"
                >
                  {copiedSupportEmail ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                </button>
              </div>
            </div>
          </div>


        </div>

      </div>



      {/* Secure Revoke Confirmation Modal */}
      {showRevokeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-rose-900/50 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 relative">
            <div className="flex items-start space-x-3.5">
              <div className="p-2.5 bg-rose-950/60 border border-rose-800/60 rounded-xl shrink-0 text-rose-400">
                <AlertTriangle size={22} />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-extrabold text-slate-100 uppercase tracking-wider font-mono">
                  Confirm License Revocation
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Are you sure you want to deauthorize and revoke this license? This action will immediately return the application to <strong className="text-rose-400">Expired / Unlicensed Mode</strong> and lock premium audit capabilities.
                </p>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 font-mono space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">CLIENT HWID:</span>
                <span className="text-indigo-300 font-bold">{hardwareId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">STATUS:</span>
                <span className="text-rose-400 font-bold">REVOKED ON CONFIRM</span>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowRevokeModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleLockSystem}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-rose-950/50 transition cursor-pointer flex items-center space-x-1.5"
              >
                <Trash2 size={13} />
                <span>Confirm Revocation</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
