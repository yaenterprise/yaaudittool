import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileSpreadsheet, 
  Tag, 
  Save, 
  Check, 
  Upload, 
  Trash2, 
  Database,
  ArrowRight,
  Info,
  Calendar,
  Layers,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  FileCode
} from "lucide-react";
import * as XLSX from "xlsx";
import { UploadedFile, StoredReferenceFile } from "../types";
import { 
  loadStoredReferenceFiles, 
  saveStoredReferenceFiles, 
  addStoredReferenceFile, 
  deleteStoredReferenceFile, 
  REF_EVENT_NAME 
} from "../utils/referenceStorage";

interface WorkspaceReferenceProps {
  files: UploadedFile[];
  setFiles?: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
}

export default function WorkspaceReference({ files = [], setFiles }: WorkspaceReferenceProps) {
  // Stored references list, backed by localStorage and real-time event sync
  const [storedFiles, setStoredFiles] = useState<StoredReferenceFile[]>(() => loadStoredReferenceFiles());

  // Listen for reference updates across tabs and workspaces
  useEffect(() => {
    const handleUpdate = () => {
      const latest = loadStoredReferenceFiles();
      setStoredFiles(prev => {
        if (prev.length === latest.length && prev.every((p, i) => p.id === latest[i]?.id && p.savedAt === latest[i]?.savedAt)) {
          return prev;
        }
        return latest;
      });
    };
    window.addEventListener(REF_EVENT_NAME, handleUpdate);
    window.addEventListener("storage", handleUpdate);
    return () => {
      window.removeEventListener(REF_EVENT_NAME, handleUpdate);
      window.removeEventListener("storage", handleUpdate);
    };
  }, []);

  // Currently uploaded file waiting to be saved
  const [pendingFile, setPendingFile] = useState<{
    id: string;
    name: string;
    size: number;
    headers: string[];
    sheetCount: number;
    totalRows: number;
    rawRows?: any[];
  } | null>(null);

  // Input value for the pending file's reference name
  const [referenceInput, setReferenceInput] = useState("");
  const [pendingProductIdCol, setPendingProductIdCol] = useState("");
  const [pendingReferenceValueCol, setPendingReferenceValueCol] = useState("");
  
  // Drag and drop states
  const [isDragging, setIsDragging] = useState(false);
  
  // Loading state during file parsing
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);

  // Expanded headers states for saved items
  const [expandedHeaders, setExpandedHeaders] = useState<Record<string, boolean>>({});

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle Drag Events
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFiles = e.dataTransfer.files;
    if (droppedFiles && droppedFiles.length > 0) {
      processFile(droppedFiles[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    if (selectedFiles && selectedFiles.length > 0) {
      processFile(selectedFiles[0]);
    }
  };

  // Parse excel / csv file to extract details and headers
  const processFile = (file: File) => {
    setIsParsing(true);
    setParseError(null);
    setPendingFile(null);

    const fileExtension = file.name.split(".").pop()?.toLowerCase();
    if (!["xlsx", "xls", "csv"].includes(fileExtension || "")) {
      setParseError("Unsupported file type. Please upload an Excel (.xlsx, .xls) or CSV (.csv) file.");
      setIsParsing(false);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: "array" });
        
        const sheetCount = workbook.SheetNames.length;
        if (sheetCount === 0) {
          throw new Error("No sheets found in file");
        }

        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to 2D array to extract headers
        const rawJson = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        const headers = ((rawJson[0] as any[]) || []).map(h => String(h || "").trim()).filter(Boolean);
        const totalRows = rawJson.length > 0 ? rawJson.length - 1 : 0;

        // Parse as object rows to get mapping values
        const rawRows = XLSX.utils.sheet_to_json<any>(worksheet);

        setPendingFile({
          id: `${Date.now()}-${file.name.replace(/\s+/g, "_")}`,
          name: file.name,
          size: file.size,
          headers,
          sheetCount,
          totalRows,
          rawRows
        });
        
        // Suggest a capitalized reference name based on filename
        const cleanName = file.name
          .split(".")[0]
          .toUpperCase()
          .replace(/[^A-Z0-9_-]/g, "_")
          .substring(0, 30);
        setReferenceInput(cleanName);

        // Auto-detect matching column headers
        let suggestedIdCol = headers[0] || "";
        let suggestedValCol = headers[1] || headers[0] || "";

        for (const h of headers) {
          const lower = h.toLowerCase();
          if (lower.includes("productid") || lower.includes("prodid") || lower === "id" || lower.includes("product_id") || lower.includes("productcode")) {
            suggestedIdCol = h;
          }
          if (lower.includes("reference") || lower.includes("value") || lower.includes("cas") || lower.includes("code") || lower.includes("sys")) {
            suggestedValCol = h;
          }
        }
        setPendingProductIdCol(suggestedIdCol);
        setPendingReferenceValueCol(suggestedValCol);

      } catch (err) {
        console.error(err);
        setParseError("Could not parse file. Ensure it is not password protected or corrupted.");
      } finally {
        setIsParsing(false);
      }
    };

    reader.onerror = () => {
      setParseError("Error reading file.");
      setIsParsing(false);
    };

    reader.readAsArrayBuffer(file);
  };

  // Save reference action
  const handleSaveReference = () => {
    if (!pendingFile) return;

    const finalReferenceName = referenceInput.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    if (!finalReferenceName) {
      setParseError("Please enter a valid non-empty Reference Name.");
      return;
    }

    // Check if duplicate reference name already exists
    if (storedFiles.some(f => f.referenceName === finalReferenceName)) {
      setParseError(`Reference name "${finalReferenceName}" already exists. Please choose a unique name.`);
      return;
    }

    if (!pendingProductIdCol || !pendingReferenceValueCol) {
      setParseError("Please choose both Product ID and Reference Value mapping columns.");
      return;
    }

    // Build the fast key-value lookup map
    const lookupMap: Record<string, string> = {};
    if (pendingFile.rawRows) {
      pendingFile.rawRows.forEach((row: any) => {
        const key = String(row[pendingProductIdCol] !== undefined && row[pendingProductIdCol] !== null ? row[pendingProductIdCol] : "").trim();
        const value = String(row[pendingReferenceValueCol] !== undefined && row[pendingReferenceValueCol] !== null ? row[pendingReferenceValueCol] : "").trim();
        if (key) {
          lookupMap[key] = value;
        }
      });
    }

    const newRecord: StoredReferenceFile = {
      id: pendingFile.id,
      referenceName: finalReferenceName,
      originalName: pendingFile.name,
      fileSize: pendingFile.size,
      totalRows: pendingFile.totalRows,
      sheetCount: pendingFile.sheetCount,
      headers: pendingFile.headers,
      savedAt: new Date().toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }),
      productIdCol: pendingProductIdCol,
      referenceValueCol: pendingReferenceValueCol,
      lookupMap
    };

    // Persist to storage and update local state list
    const updated = addStoredReferenceFile(newRecord);
    setStoredFiles(updated);

    // Optional: Sync back to parent files list
    if (setFiles) {
      const parentUploadedFile: UploadedFile = {
        id: pendingFile.id,
        fileName: pendingFile.name,
        fileSize: pendingFile.size,
        totalRows: pendingFile.totalRows,
        sheetCount: pendingFile.sheetCount,
        referenceName: finalReferenceName
      };
      setFiles(prev => [parentUploadedFile, ...prev]);
    }

    // Reset pending upload file
    setPendingFile(null);
    setReferenceInput("");
  };

  // Delete saved reference file
  const handleDeleteReference = (id: string, refName: string) => {
    const updated = deleteStoredReferenceFile(id);
    setStoredFiles(updated);
    
    // Optional: Remove from parent files state
    if (setFiles) {
      setFiles(prev => prev.filter(f => f.id !== id));
    }
  };

  const toggleHeadersExpand = (id: string) => {
    setExpandedHeaders(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex-1 min-h-0 h-full w-full flex flex-col gap-4 overflow-hidden"
    >
      {/* Visual Header */}
      <div className="bg-slate-900/40 border border-slate-800 p-4 rounded-2xl shrink-0 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl">
            <Tag size={20} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              File Reference Registry
            </h2>
            <p className="text-xs text-slate-400">
              Upload any spreadsheet file, inspect all headers, and store custom Reference Names.
            </p>
          </div>
        </div>
        <div className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 border border-indigo-500/20 text-indigo-300">
          {storedFiles.length} Saved File{storedFiles.length !== 1 ? "s" : ""}
        </div>
      </div>

      {/* Main Grid View: Left Side Upload, Right Side Saved Files */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-5 min-h-0">
        
        {/* Left Side: Upload Zone & Headers Inspection */}
        <div className="lg:col-span-7 flex flex-col gap-4 overflow-y-auto pr-1">
          <div className="bg-slate-950/40 border border-slate-850 rounded-2xl p-5 space-y-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wide">
              1. Upload Spreadsheet File
            </h3>

            {/* Drag and Drop Zone */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-3 ${
                isDragging
                  ? "border-indigo-500 bg-indigo-500/5"
                  : "border-slate-800 hover:border-indigo-500/40 bg-slate-900/10 hover:bg-slate-900/20"
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                accept=".xlsx,.xls,.csv"
                className="hidden"
              />
              <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400">
                <Upload size={24} className={isParsing ? "animate-pulse" : ""} />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-200 block">
                  {isParsing ? "Parsing Excel Spreadsheet..." : "Click or drag your spreadsheet here"}
                </span>
                <span className="text-[10px] text-slate-500 font-mono block mt-1">
                  Supports .xlsx, .xls, .csv
                </span>
              </div>
            </div>

            {/* Parsing / Upload Error Banner */}
            {parseError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs rounded-xl flex items-center gap-2 font-semibold">
                <AlertCircle size={14} className="shrink-0" />
                <span>{parseError}</span>
              </div>
            )}

            {/* Active File Inspection Card */}
            <AnimatePresence mode="wait">
              {pendingFile && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="border border-indigo-500/30 bg-slate-900/20 p-5 rounded-xl space-y-4"
                >
                  <div className="flex items-start justify-between border-b border-slate-800/40 pb-3">
                    <div className="space-y-0.5">
                      <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest font-mono">
                        Active Upload
                      </span>
                      <h4 className="text-xs font-bold text-slate-200 truncate max-w-md" title={pendingFile.name}>
                        {pendingFile.name}
                      </h4>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">
                      {(pendingFile.size / 1024).toFixed(1)} KB
                    </span>
                  </div>

                  {/* Headers Visualization Grid */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wide flex items-center gap-1.5">
                      <Layers size={11} className="text-indigo-400" />
                      <span>Extracted Headers ({pendingFile.headers.length})</span>
                    </span>
                    
                    {pendingFile.headers.length === 0 ? (
                      <span className="text-[10px] font-mono text-slate-500 block italic">
                        No columns detected on sheet 1.
                      </span>
                    ) : (
                      <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto bg-slate-950/60 border border-slate-850 p-3 rounded-lg">
                        {pendingFile.headers.map((hdr, idx) => (
                          <span 
                            key={idx} 
                            className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/10 border border-indigo-500/15 text-indigo-300"
                          >
                            {hdr}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Reference Name Assignment Row */}
                  {/* Select Column Mappings */}
                  <div className="grid grid-cols-2 gap-3 border-t border-slate-800/40 pt-3">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wide block">
                        Product ID Header
                      </label>
                      <select
                        value={pendingProductIdCol}
                        onChange={(e) => setPendingProductIdCol(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none px-2 py-1.5 rounded-lg text-xs font-mono font-bold text-slate-300 transition"
                      >
                        <option value="">-- Select Column --</option>
                        {pendingFile.headers.map((h, idx) => (
                          <option key={idx} value={h}>{h}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wide block">
                        Reference Value Header
                      </label>
                      <select
                        value={pendingReferenceValueCol}
                        onChange={(e) => setPendingReferenceValueCol(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none px-2 py-1.5 rounded-lg text-xs font-mono font-bold text-slate-300 transition"
                      >
                        <option value="">-- Select Column --</option>
                        {pendingFile.headers.map((h, idx) => (
                          <option key={idx} value={h}>{h}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2 pt-1 border-t border-slate-800/40">
                    <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wide block">
                      2. Assign Reference Name & Store
                    </label>
                    <div className="flex items-stretch gap-2">
                      <input
                        type="text"
                        value={referenceInput}
                        onChange={(e) => setReferenceInput(e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g, ""))}
                        placeholder="Type Reference Name (e.g. CAS_PRIMARY_AUG)..."
                        className="flex-1 bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none px-3 py-2 rounded-xl text-xs font-mono font-bold text-slate-200 placeholder-slate-600 transition"
                      />
                      <button
                        onClick={handleSaveReference}
                        className="px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs tracking-wider border border-indigo-500 hover:shadow-lg hover:shadow-indigo-950/40 transition duration-150 flex items-center gap-1.5 cursor-pointer select-none"
                      >
                        <Save size={13} />
                        <span>Save Mappings</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Guidelines / Help box */}
          <div className="bg-indigo-500/[0.02] border border-indigo-500/15 p-4 rounded-2xl flex items-start gap-3">
            <Info size={16} className="text-indigo-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-[11px] font-bold text-indigo-300 uppercase">Reference Persistence Guidelines</h4>
              <p className="text-[10.5px] text-slate-400 leading-relaxed font-sans">
                These references are stored in local persistent database state. Once saved, the custom system maps remain available in 
                future sessions on this device, helping you identify complex spreadsheets easily.
              </p>
            </div>
          </div>
        </div>

        {/* Right Side: Saved References & Registry */}
        <div className="lg:col-span-5 flex flex-col gap-4 overflow-y-auto pr-1">
          <div className="bg-slate-950/40 border border-slate-850 rounded-2xl p-4 flex-1 flex flex-col min-h-0">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 shrink-0">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wide flex items-center gap-2">
                <Database size={13} className="text-indigo-400" />
                <span>Stored Reference Files</span>
              </span>
              <span className="text-[10px] font-mono text-slate-500">
                {storedFiles.length} Registered
              </span>
            </div>

            {/* Scrollable list of saved file mapping templates */}
            <div className="flex-1 overflow-y-auto mt-3.5 space-y-3.5 pr-0.5">
              {storedFiles.length === 0 ? (
                <div className="h-full py-20 text-center flex flex-col justify-center items-center gap-2.5 text-slate-500 font-sans">
                  <FileCode size={28} className="text-slate-600 animate-pulse" />
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase block">Registry Empty</span>
                    <span className="text-[10px] text-slate-500 max-w-xs block mt-0.5 leading-relaxed">
                      Upload and save spreadsheets on the left side. Saved records will populate here instantly.
                    </span>
                  </div>
                </div>
              ) : (
                storedFiles.map(file => {
                  const hasHeaders = file.headers && file.headers.length > 0;
                  const isExpanded = !!expandedHeaders[file.id];

                  return (
                    <div 
                      key={file.id}
                      className="bg-slate-900/30 border border-slate-800/80 rounded-xl p-3.5 hover:border-slate-700 transition"
                    >
                      {/* Top Row: Ref Name and Trash Delete option */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-0.5">
                          <span className="px-1.5 py-0.2 rounded text-[9.5px] font-black bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 uppercase tracking-wider font-mono">
                            {file.referenceName}
                          </span>
                          <h4 
                            className="text-xs font-semibold text-slate-200 truncate max-w-[200px] sm:max-w-xs block font-sans pt-1" 
                            title={file.originalName}
                          >
                            {file.originalName}
                          </h4>
                        </div>
                        
                        <button
                          onClick={() => handleDeleteReference(file.id, file.referenceName)}
                          className="p-1.5 bg-slate-950/40 hover:bg-rose-500/10 border border-slate-800 hover:border-rose-500/25 text-slate-500 hover:text-rose-400 rounded-lg transition cursor-pointer"
                          title="Delete Stored Reference File"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>

                      {/* Column Mappings Detail */}
                      {file.productIdCol && file.referenceValueCol && (
                        <div className="mt-2 text-[9px] bg-slate-950/50 rounded-lg p-2 border border-slate-800/40 text-slate-400 space-y-1 font-mono">
                          <div className="flex justify-between">
                            <span>Key Header:</span>
                            <span className="font-bold text-slate-200 max-w-[130px] truncate" title={file.productIdCol}>{file.productIdCol}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Val Header:</span>
                            <span className="font-bold text-indigo-400 max-w-[130px] truncate" title={file.referenceValueCol}>{file.referenceValueCol}</span>
                          </div>
                        </div>
                      )}

                      {/* File Details Grid */}
                      <div className="grid grid-cols-2 gap-2 mt-3 pt-2 border-t border-slate-800/30 text-[9.5px] text-slate-400 font-mono">
                        <div className="flex items-center gap-1">
                          <Calendar size={11} className="text-slate-500" />
                          <span>{file.savedAt}</span>
                        </div>
                        <div className="text-right">
                          <span>{(file.fileSize / 1024).toFixed(1)} KB • {file.totalRows} rows</span>
                        </div>
                      </div>

                      {/* Expandable Column headers list */}
                      {hasHeaders && (
                        <div className="mt-2.5 pt-1">
                          <button
                            onClick={() => toggleHeadersExpand(file.id)}
                            className="w-full flex items-center justify-between text-[10px] text-slate-500 hover:text-slate-300 font-bold select-none cursor-pointer"
                          >
                            <span>Columns/Headers ({file.headers.length})</span>
                            {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                          </button>

                          {isExpanded && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              className="mt-2 flex flex-wrap gap-1 bg-slate-950 p-2.5 rounded-lg border border-slate-850 max-h-32 overflow-y-auto"
                            >
                              {file.headers.map((h, i) => (
                                <span 
                                  key={i} 
                                  className="px-1.5 py-0.2 rounded text-[9.5px] font-mono font-bold bg-slate-900 border border-slate-800 text-slate-400"
                                >
                                  {h}
                                </span>
                              ))}
                            </motion.div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

      </div>
    </motion.div>
  );
}
