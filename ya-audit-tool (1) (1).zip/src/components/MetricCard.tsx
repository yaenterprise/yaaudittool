import React from "react";
import { motion } from "motion/react";

interface MetricCardProps {
  label: string;
  value: string | number;
  description: string;
  colorClass: string;
  icon: React.ReactNode;
}

export default function MetricCard({
  label,
  value,
  description,
  colorClass,
  icon,
}: MetricCardProps) {
  const isMatch = label.toLowerCase().includes("match") || label.toLowerCase().includes("aligned");
  const isMismatch = label.toLowerCase().includes("mismatch");

  let cardBg = "bg-slate-800/40 border-slate-700";
  let labelColor = "text-slate-400";
  let valColor = "text-white";
  let descColor = "text-slate-500";
  let iconBg = "bg-slate-700/50 text-indigo-400";

  if (isMatch) {
    cardBg = "bg-emerald-950/20 border-emerald-500/30";
    labelColor = "text-emerald-400";
    valColor = "text-emerald-400";
    descColor = "text-emerald-500/70";
    iconBg = "bg-emerald-500/10 text-emerald-400";
  } else if (isMismatch) {
    cardBg = "bg-rose-950/20 border-rose-500/30";
    labelColor = "text-rose-400";
    valColor = "text-rose-400";
    descColor = "text-rose-500/70";
    iconBg = "bg-rose-500/10 text-rose-400";
  } else {
    // Lookup keys / Base records card
    cardBg = "bg-slate-800/40 border-slate-700";
    iconBg = "bg-indigo-500/10 text-indigo-400";
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className={`rounded-xl border p-3 flex items-center justify-between relative overflow-hidden transition-all hover:scale-[1.01] ${cardBg}`}
    >
      <div className="space-y-0.5">
        <span className={`text-[10px] font-bold uppercase tracking-wider block ${labelColor}`}>
          {label}
        </span>
        <div className="flex items-baseline space-x-1.5">
          <h3 className={`text-xl font-bold font-mono tracking-tight leading-none ${valColor}`}>
            {value}
          </h3>
        </div>
        <p className={`text-[10px] font-normal leading-tight opacity-90 ${descColor}`}>
          {description}
        </p>
      </div>
      <div className={`p-1.5 rounded-lg border border-white/5 flex items-center justify-center shrink-0 ${iconBg}`}>
        {icon}
      </div>
    </motion.div>
  );
}
