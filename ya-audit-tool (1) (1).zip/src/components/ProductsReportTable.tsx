import React, { useState, useMemo } from "react";
import { Search, Filter, ArrowUpDown, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, CheckCircle2, AlertTriangle, HelpCircle, FileSpreadsheet, Percent, Database, ShoppingBag } from "lucide-react";
import { getAllDisplayRecords } from "../utils/validationCache";

interface ProductsReportTableProps {
  comparisonMode: "A_B" | "B_C" | "A_C" | "A_B_C";
  showCas: boolean;
  showSms: boolean;
  showApp: boolean;
  validationToken: number;
}

interface ProductStats {
  name: string;
  countCas: number;
  countSms: number;
  countApp: number;
  totalAcross: number;
  isAligned: boolean;
  hasCas: boolean;
  hasSms: boolean;
  hasApp: boolean;
}

type ProductFilterStatus = "ALL" | "ALIGNED" | "DISCREPANCY" | "ONLY_CAS" | "ONLY_SMS" | "ONLY_APP";
type ProductSortField = "name" | "countCas" | "countSms" | "countApp" | "totalAcross" | "status";
type SortOrder = "asc" | "desc";

export default function ProductsReportTable({
  comparisonMode,
  showCas,
  showSms,
  showApp,
  validationToken,
}: ProductsReportTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilter, setActiveFilter] = useState<ProductFilterStatus>("ALL");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [sortField, setSortField] = useState<ProductSortField>("name");
  const [sortOrder, setSortOrder] = useState<SortOrder>("asc");

  // Aggregate product stats
  const { productList, summaryStats } = useMemo(() => {
    const records = getAllDisplayRecords(comparisonMode);
    const productMap = new Map<string, { countCas: number; countSms: number; countApp: number }>();

    for (let i = 0; i < records.length; i++) {
      const rec = records[i];
      
      // CAS (C)
      if (showCas && rec.aProducts) {
        rec.aProducts.forEach(p => {
          if (!p) return;
          const existing = productMap.get(p) || { countCas: 0, countSms: 0, countApp: 0 };
          existing.countCas++;
          productMap.set(p, existing);
        });
      }

      // SMS (B)
      if (showSms && rec.bProducts) {
        rec.bProducts.forEach(p => {
          if (!p) return;
          const existing = productMap.get(p) || { countCas: 0, countSms: 0, countApp: 0 };
          existing.countSms++;
          productMap.set(p, existing);
        });
      }

      // APP (A)
      if (showApp && rec.cProducts) {
        rec.cProducts.forEach(p => {
          if (!p) return;
          const existing = productMap.get(p) || { countCas: 0, countSms: 0, countApp: 0 };
          existing.countApp++;
          productMap.set(p, existing);
        });
      }
    }

    const list: ProductStats[] = [];
    let alignedCount = 0;
    let discrepancyCount = 0;
    let totalCasEntries = 0;
    let totalSmsEntries = 0;
    let totalAppEntries = 0;

    productMap.forEach((counts, name) => {
      totalCasEntries += counts.countCas;
      totalSmsEntries += counts.countSms;
      totalAppEntries += counts.countApp;

      // Determine if aligned based on active comparison mode
      let isAligned = true;
      const activeCounts: number[] = [];
      if (showCas) activeCounts.push(counts.countCas);
      if (showSms) activeCounts.push(counts.countSms);
      if (showApp) activeCounts.push(counts.countApp);

      if (activeCounts.length > 1) {
        const first = activeCounts[0];
        isAligned = activeCounts.every(c => c === first);
      }

      if (isAligned) {
        alignedCount++;
      } else {
        discrepancyCount++;
      }

      list.push({
        name,
        countCas: counts.countCas,
        countSms: counts.countSms,
        countApp: counts.countApp,
        totalAcross: counts.countCas + counts.countSms + counts.countApp,
        isAligned,
        hasCas: counts.countCas > 0,
        hasSms: counts.countSms > 0,
        hasApp: counts.countApp > 0,
      });
    });

    return {
      productList: list,
      summaryStats: {
        totalUnique: productMap.size,
        alignedCount,
        discrepancyCount,
        totalCasEntries,
        totalSmsEntries,
        totalAppEntries,
      }
    };
  }, [comparisonMode, showCas, showSms, showApp, validationToken]);

  // Handle Search Input Change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  // Handle Filter Change
  const handleFilterChange = (filter: ProductFilterStatus) => {
    setActiveFilter(filter);
    setCurrentPage(1);
  };

  // Handle Sorting
  const handleSort = (field: ProductSortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
    setCurrentPage(1);
  };

  // Process and Filter List
  const processedList = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return productList.filter(item => {
      // Search filter
      if (term && !item.name.toLowerCase().includes(term)) {
        return false;
      }

      // Tab/Status filter
      if (activeFilter === "ALIGNED") return item.isAligned;
      if (activeFilter === "DISCREPANCY") return !item.isAligned;
      if (activeFilter === "ONLY_CAS") return item.hasCas && !item.hasSms && !item.hasApp;
      if (activeFilter === "ONLY_SMS") return item.hasSms && !item.hasCas && !item.hasApp;
      if (activeFilter === "ONLY_APP") return item.hasApp && !item.hasCas && !item.hasSms;

      return true;
    }).sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];

      if (sortField === "status") {
        valA = a.isAligned ? 1 : 0;
        valB = b.isAligned ? 1 : 0;
      }

      if (typeof valA === "string" && typeof valB === "string") {
        return sortOrder === "asc" ? valA.localeCompare(valB) : valB.localeCompare(valA);
      } else {
        return sortOrder === "asc" ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
      }
    });
  }, [productList, searchTerm, activeFilter, sortField, sortOrder]);

  // Pagination Math
  const totalRecords = processedList.length;
  const totalPages = Math.ceil(totalRecords / pageSize) || 1;
  const activePage = Math.min(Math.max(1, currentPage), totalPages);
  const startIdx = (activePage - 1) * pageSize;
  const paginatedList = processedList.slice(startIdx, startIdx + pageSize);

  const startRecordIdx = totalRecords === 0 ? 0 : startIdx + 1;
  const endRecordIdx = Math.min(activePage * pageSize, totalRecords);

  return (
    <div className="bg-slate-900/40 backdrop-blur-md rounded-2xl border border-slate-700/80 shadow-xl overflow-hidden flex flex-col h-full lg:flex-1 min-h-0">
      
      {/* Metric Cards Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 p-4 border-b border-slate-800/60 bg-slate-950/20 shrink-0">
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase font-bold tracking-wider">Unique Products</span>
            <ShoppingBag size={13} className="text-indigo-400" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="text-lg font-black text-white font-mono">{summaryStats.totalUnique}</span>
            <span className="text-[10px] text-slate-500">total unique</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase font-bold tracking-wider font-sans">Aligned Products</span>
            <CheckCircle2 size={13} className="text-emerald-400" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="text-lg font-black text-emerald-400 font-mono">{summaryStats.alignedCount}</span>
            <span className="text-[10px] text-emerald-500">
              {summaryStats.totalUnique > 0 ? Math.round((summaryStats.alignedCount / summaryStats.totalUnique) * 100) : 0}% rate
            </span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase font-bold tracking-wider">Discrepancies</span>
            <AlertTriangle size={13} className="text-amber-400" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="text-lg font-black text-amber-400 font-mono">{summaryStats.discrepancyCount}</span>
            <span className="text-[10px] text-amber-500">mismatched counts</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase font-bold tracking-wider">Product Catalog size</span>
            <Database size={13} className="text-sky-400" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="text-lg font-black text-white font-mono">
              {(showCas ? summaryStats.totalCasEntries : 0) + 
               (showSms ? summaryStats.totalSmsEntries : 0) + 
               (showApp ? summaryStats.totalAppEntries : 0)}
            </span>
            <span className="text-[10px] text-slate-500">total item tags</span>
          </div>
        </div>
      </div>

      {/* Toolbar / Search & Filters */}
      <div className="p-4 border-b border-slate-800/60 space-y-3 shrink-0 bg-slate-900/20">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <span>Products Level Analysis</span>
              <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                Interactive Directory
              </span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Unique product distribution tracking across all configured worksheets.
            </p>
          </div>

          <div className="relative w-full md:w-64">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={13} />
            <input
              type="text"
              placeholder="Filter product names..."
              value={searchTerm}
              onChange={handleSearchChange}
              className="w-full bg-slate-950/60 border border-slate-800 text-slate-200 placeholder-slate-500 rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:border-indigo-500/80 font-medium"
            />
          </div>
        </div>

        {/* Filter Badges Row */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <button
            onClick={() => handleFilterChange("ALL")}
            className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold tracking-wide transition cursor-pointer select-none border ${
              activeFilter === "ALL"
                ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/45 shadow-sm"
                : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-800/20 hover:text-slate-300"
            }`}
          >
            All Unique ({productList.length})
          </button>

          <button
            onClick={() => handleFilterChange("ALIGNED")}
            className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold tracking-wide transition cursor-pointer select-none border ${
              activeFilter === "ALIGNED"
                ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/45 shadow-sm"
                : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-800/20 hover:text-slate-300"
            }`}
          >
            Aligned Only ({summaryStats.alignedCount})
          </button>

          <button
            onClick={() => handleFilterChange("DISCREPANCY")}
            className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold tracking-wide transition cursor-pointer select-none border ${
              activeFilter === "DISCREPANCY"
                ? "bg-amber-500/20 text-amber-300 border-amber-500/45 shadow-sm animate-pulse-subtle"
                : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-800/20 hover:text-slate-300"
            }`}
          >
            Discrepancies ({summaryStats.discrepancyCount})
          </button>

          {showCas && (
            <button
              onClick={() => handleFilterChange("ONLY_CAS")}
              className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold tracking-wide transition cursor-pointer select-none border ${
                activeFilter === "ONLY_CAS"
                  ? "bg-violet-500/20 text-violet-300 border-violet-500/45 shadow-sm"
                  : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-800/20 hover:text-slate-300"
              }`}
            >
              Only in CAS (C)
            </button>
          )}

          {showSms && (
            <button
              onClick={() => handleFilterChange("ONLY_SMS")}
              className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold tracking-wide transition cursor-pointer select-none border ${
                activeFilter === "ONLY_SMS"
                  ? "bg-sky-500/20 text-sky-300 border-sky-500/45 shadow-sm"
                  : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-800/20 hover:text-slate-300"
              }`}
            >
              Only in SMS (B)
            </button>
          )}

          {showApp && (
            <button
              onClick={() => handleFilterChange("ONLY_APP")}
              className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold tracking-wide transition cursor-pointer select-none border ${
                activeFilter === "ONLY_APP"
                  ? "bg-pink-500/20 text-pink-300 border-pink-500/45 shadow-sm"
                  : "bg-slate-950/40 text-slate-400 border-slate-850 hover:bg-slate-800/20 hover:text-slate-300"
              }`}
            >
              Only in SMS (S)
            </button>
          )}
        </div>
      </div>

      {/* Main Table Content */}
      <div className="flex-1 overflow-x-auto min-h-0">
        <table className="w-full text-left border-collapse min-w-[700px]">
          <thead>
            <tr className="bg-slate-950/40 border-b border-slate-800 text-[10px] uppercase font-bold tracking-wider text-slate-400 select-none">
              <th 
                className="py-3 px-6 cursor-pointer hover:bg-slate-850/50 hover:text-slate-200 transition"
                onClick={() => handleSort("name")}
              >
                <div className="flex items-center space-x-1.5">
                  <span>Product Name</span>
                  <ArrowUpDown size={10} className="opacity-70 shrink-0" />
                </div>
              </th>

              {showCas && (
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-850/50 hover:text-slate-200 transition text-center"
                  onClick={() => handleSort("countCas")}
                >
                  <div className="flex items-center justify-center space-x-1.5">
                    <span>In CAS (C)</span>
                    <ArrowUpDown size={10} className="opacity-70 shrink-0" />
                  </div>
                </th>
              )}

              {showSms && (
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-850/50 hover:text-slate-200 transition text-center"
                  onClick={() => handleSort("countSms")}
                >
                  <div className="flex items-center justify-center space-x-1.5">
                    <span>In SMS (B)</span>
                    <ArrowUpDown size={10} className="opacity-70 shrink-0" />
                  </div>
                </th>
              )}

              {showApp && (
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-850/50 hover:text-slate-200 transition text-center"
                  onClick={() => handleSort("countApp")}
                >
                  <div className="flex items-center justify-center space-x-1.5">
                    <span>In SMS (S)</span>
                    <ArrowUpDown size={10} className="opacity-70 shrink-0" />
                  </div>
                </th>
              )}

              <th 
                className="py-3 px-4 cursor-pointer hover:bg-slate-850/50 hover:text-slate-200 transition text-center"
                onClick={() => handleSort("totalAcross")}
              >
                <div className="flex items-center justify-center space-x-1.5">
                  <span>Total Sum</span>
                  <ArrowUpDown size={10} className="opacity-70 shrink-0" />
                </div>
              </th>

              <th 
                className="py-3 px-4 cursor-pointer hover:bg-slate-850/50 hover:text-slate-200 transition text-center"
                onClick={() => handleSort("status")}
              >
                <div className="flex items-center justify-center space-x-1.5">
                  <span>Alignment Status</span>
                  <ArrowUpDown size={10} className="opacity-70 shrink-0" />
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850">
            {paginatedList.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-slate-500 text-xs">
                  No matching products found. Adjust your filters or search query.
                </td>
              </tr>
            ) : (
              paginatedList.map((item, idx) => {
                const isMatch = item.isAligned;
                return (
                  <tr 
                    key={`${item.name}-${idx}`} 
                    className={`hover:bg-slate-800/30 transition-colors ${
                      !isMatch ? "bg-amber-500/[0.01]" : ""
                    }`}
                  >
                    {/* Name */}
                    <td className="py-2.5 px-6 font-semibold text-slate-200 text-xs whitespace-nowrap">
                      {item.name}
                    </td>

                    {/* CAS */}
                    {showCas && (
                      <td className="py-2.5 px-4 text-center font-mono text-xs whitespace-nowrap">
                        {item.countCas > 0 ? (
                          <span className="text-violet-300 font-bold">{item.countCas} rows</span>
                        ) : (
                          <span className="text-slate-600 italic">—</span>
                        )}
                      </td>
                    )}

                    {/* SMS */}
                    {showSms && (
                      <td className="py-2.5 px-4 text-center font-mono text-xs whitespace-nowrap">
                        {item.countSms > 0 ? (
                          <span className="text-sky-300 font-bold">{item.countSms} rows</span>
                        ) : (
                          <span className="text-slate-600 italic">—</span>
                        )}
                      </td>
                    )}

                    {/* APP */}
                    {showApp && (
                      <td className="py-2.5 px-4 text-center font-mono text-xs whitespace-nowrap">
                        {item.countApp > 0 ? (
                          <span className="text-pink-300 font-bold">{item.countApp} rows</span>
                        ) : (
                          <span className="text-slate-600 italic">—</span>
                        )}
                      </td>
                    )}

                    {/* Total sum across active */}
                    <td className="py-2.5 px-4 text-center font-mono text-xs whitespace-nowrap text-slate-400">
                      {item.totalAcross} entries
                    </td>

                    {/* Alignment State */}
                    <td className="py-2.5 px-4 text-center whitespace-nowrap text-xs">
                      {isMatch ? (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          <CheckCircle2 size={11} />
                          <span>ALIGNED</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/25">
                          <AlertTriangle size={11} />
                          <span>DISCREPANCY</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-3 bg-slate-950/40 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-400 text-xs shrink-0 select-none">
        <div>
          Showing <span className="font-bold text-slate-300">{startRecordIdx}</span> to{" "}
          <span className="font-bold text-slate-300">{endRecordIdx}</span> of{" "}
          <span className="font-bold text-slate-300">{totalRecords}</span> products
        </div>

        <div className="flex items-center space-x-1">
          <button
            onClick={() => setCurrentPage(1)}
            disabled={activePage === 1}
            className="p-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-slate-900 border border-slate-800 rounded-lg text-slate-300 hover:text-white transition disabled:cursor-not-allowed cursor-pointer"
            title="First Page"
          >
            <ChevronsLeft size={13} />
          </button>
          <button
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={activePage === 1}
            className="p-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-slate-900 border border-slate-800 rounded-lg text-slate-300 hover:text-white transition disabled:cursor-not-allowed cursor-pointer"
            title="Previous Page"
          >
            <ChevronLeft size={13} />
          </button>

          <div className="px-3 py-1 bg-slate-950 rounded-lg border border-slate-850 font-mono text-[11px]">
            Page <span className="font-bold text-slate-200">{activePage}</span> of{" "}
            <span className="font-bold text-slate-400">{totalPages}</span>
          </div>

          <button
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={activePage === totalPages}
            className="p-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-slate-900 border border-slate-800 rounded-lg text-slate-300 hover:text-white transition disabled:cursor-not-allowed cursor-pointer"
            title="Next Page"
          >
            <ChevronRight size={13} />
          </button>
          <button
            onClick={() => setCurrentPage(totalPages)}
            disabled={activePage === totalPages}
            className="p-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-slate-900 border border-slate-800 rounded-lg text-slate-300 hover:text-white transition disabled:cursor-not-allowed cursor-pointer"
            title="Last Page"
          >
            <ChevronsRight size={13} />
          </button>
        </div>
      </div>

    </div>
  );
}
