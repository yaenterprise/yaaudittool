import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  FileSpreadsheet,
  Upload,
  Trash2,
  Check,
  Sliders,
  Eye,
  Search,
  Info,
  RefreshCw,
  SlidersHorizontal,
  Layers,
  ArrowRight,
  Database,
  ShoppingBag,
  CheckCircle2
} from "lucide-react";
import { MasterProduct, MasterMapping } from "../types";
import { parseMasterProductFileAsync } from "../utils/parser";

interface ProductMasterWorkspaceProps {
  onNavigateToProducts?: () => void;
}

export default function ProductMasterWorkspace({
  onNavigateToProducts
}: ProductMasterWorkspaceProps) {
  const [masterFileName, setMasterFileName] = useState<string>(() => localStorage.getItem("products_master_name") || "");
  const [masterFileSize, setMasterFileSize] = useState<number>(() => parseInt(localStorage.getItem("products_master_size") || "0", 10));
  const [masterColumns, setMasterColumns] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("products_master_cols") || "[]");
    } catch {
      return [];
    }
  });
  const [masterRawRows, setMasterRawRows] = useState<any[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("products_master_rows") || "[]");
    } catch {
      return [];
    }
  });
  const [masterMapping, setMasterMapping] = useState<MasterMapping>(() => {
    try {
      const saved = localStorage.getItem("products_master_mapping");
      return saved ? JSON.parse(saved) : {
        productIdCol: "",
        productNameCol: "",
        casCol: "",
        broadcasterCol: ""
      };
    } catch {
      return { productIdCol: "", productNameCol: "", casCol: "", broadcasterCol: "" };
    }
  });

  const [useUniqueOnly, setUseUniqueOnly] = useState<boolean>(() => {
    const saved = localStorage.getItem("products_use_unique_only");
    return saved !== "false";
  });

  const [bothNoValue, setBothNoValue] = useState<boolean>(() => {
    const saved = localStorage.getItem("products_both_no_value");
    return saved !== "false";
  });

  const [ignoreZeroProductEnabled, setIgnoreZeroProductEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("ya_ignore_zero_product_enabled");
    return saved !== "false";
  });

  const [isMasterDragging, setIsMasterDragging] = useState<boolean>(false);
  const [isMasterParsing, setIsMasterParsing] = useState<boolean>(false);
  const [masterParseProgress, setMasterParseProgress] = useState<{ stage: string; percent: number } | null>(null);
  const [masterSearch, setMasterSearch] = useState<string>("");
  const [saveNotification, setSaveNotification] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 15;

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem("products_use_unique_only", String(useUniqueOnly));
  }, [useUniqueOnly]);

  useEffect(() => {
    localStorage.setItem("products_both_no_value", String(bothNoValue));
  }, [bothNoValue]);

  useEffect(() => {
    localStorage.setItem("ya_ignore_zero_product_enabled", String(ignoreZeroProductEnabled));
  }, [ignoreZeroProductEnabled]);

  const handleMasterFileSelect = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    setMasterFileName(file.name);
    setMasterFileSize(file.size);
    setIsMasterParsing(true);
    setMasterParseProgress({ stage: "Preparing catalog reader...", percent: 10 });

    try {
      const { columns, rows, suggestedMapping } = await parseMasterProductFileAsync(
        file,
        (stage, percent) => {
          setMasterParseProgress({ stage, percent });
        }
      );

      setMasterColumns(columns);
      setMasterRawRows(rows);

      // Auto assign mapping if not existing
      const newMapping: MasterMapping = {
        productIdCol: suggestedMapping.productIdCol || columns[0] || "",
        productNameCol: suggestedMapping.productNameCol || (columns.length > 1 ? columns[1] : ""),
        casCol: suggestedMapping.casCol || "",
        broadcasterCol: suggestedMapping.broadcasterCol || ""
      };
      setMasterMapping(newMapping);

      try {
        localStorage.setItem("products_master_name", file.name);
        localStorage.setItem("products_master_size", String(file.size));
        localStorage.setItem("products_master_cols", JSON.stringify(columns));
        localStorage.setItem("products_master_rows", JSON.stringify(rows));
        localStorage.setItem("products_master_mapping", JSON.stringify(newMapping));
        window.dispatchEvent(new CustomEvent("products_master_updated"));
      } catch (storageErr) {
        console.warn("Storage quota exceeded when caching master file rows:", storageErr);
      }

      setSaveNotification(`Master catalog parsed: ${rows.length} rows loaded successfully!`);
      setTimeout(() => setSaveNotification(null), 3500);
    } catch (err: any) {
      console.error("Master catalog parse failure:", err);
      alert(`Failed to parse master catalog file: ${err.message || err}`);
    } finally {
      setIsMasterParsing(false);
      setMasterParseProgress(null);
    }
  };

  const handleSaveMasterMapping = () => {
    if (!masterMapping.productIdCol) {
      alert("Please map at least the Product ID Header!");
      return;
    }
    localStorage.setItem("products_master_mapping", JSON.stringify(masterMapping));
    window.dispatchEvent(new CustomEvent("products_master_updated"));
    setSaveNotification("Product Master parameters and column mappings saved successfully!");
    setTimeout(() => setSaveNotification(null), 3000);
  };

  const handleClearMaster = () => {
    if (!confirm("Are you sure you want to clear the loaded Product Master catalog?")) return;
    setMasterFileName("");
    setMasterFileSize(0);
    setMasterColumns([]);
    setMasterRawRows([]);
    setMasterMapping({ productIdCol: "", productNameCol: "", casCol: "", broadcasterCol: "" });
    localStorage.removeItem("products_master_name");
    localStorage.removeItem("products_master_size");
    localStorage.removeItem("products_master_cols");
    localStorage.removeItem("products_master_rows");
    localStorage.removeItem("products_master_mapping");
    window.dispatchEvent(new CustomEvent("products_master_updated"));
    setSaveNotification("Master catalog cleared.");
    setTimeout(() => setSaveNotification(null), 2500);
  };

  // Derive mapped master products
  const masterProducts = useMemo<MasterProduct[]>(() => {
    if (!masterMapping.productIdCol || masterRawRows.length === 0) return [];

    return masterRawRows.map((row) => {
      const id = String(row[masterMapping.productIdCol] || "").trim().replace(/'/g, "");
      const name = masterMapping.productNameCol 
        ? String(row[masterMapping.productNameCol] || "").trim().replace(/'/g, "") 
        : "N/A";
      const cas = masterMapping.casCol ? String(row[masterMapping.casCol] || "").trim() : "N/A";
      const broadcaster = masterMapping.broadcasterCol ? String(row[masterMapping.broadcasterCol] || "").trim() : "Other / Unmapped";

      return {
        id,
        name: name || `Product ${id}`,
        cas: cas || "N/A",
        broadcaster: broadcaster || "Other / Unmapped"
      };
    }).filter(p => p.id !== "");
  }, [masterRawRows, masterMapping]);

  // Filtered rows for search preview
  const filteredMasterRows = useMemo(() => {
    if (!masterSearch) return masterProducts;
    const term = masterSearch.toLowerCase().trim();
    return masterProducts.filter(p => 
      p.id.toLowerCase().includes(term) ||
      p.name.toLowerCase().includes(term) ||
      p.cas.toLowerCase().includes(term) ||
      p.broadcaster.toLowerCase().includes(term)
    );
  }, [masterProducts, masterSearch]);

  const totalPages = Math.ceil(filteredMasterRows.length / pageSize) || 1;
  const paginatedRows = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredMasterRows.slice(start, start + pageSize);
  }, [filteredMasterRows, currentPage, pageSize]);

  return (
    <div className="flex-1 flex flex-col gap-4 min-h-0 h-full w-full">
      {/* Top Banner / Navigation Bar */}
      <div className="bg-slate-900/40 border border-slate-800/80 p-3 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <FileSpreadsheet size={18} />
          </div>
          <div>
            <h2 className="text-sm font-black uppercase tracking-wider text-slate-100 flex items-center gap-2">
              <span>Product Master Data Catalog</span>
              {masterProducts.length > 0 && (
                <span className="px-2 py-0.5 text-[10px] font-bold font-mono rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                  {masterProducts.length.toLocaleString()} Products Configured
                </span>
              )}
            </h2>
            <p className="text-[11px] text-slate-400">
              Master catalog for product ID, name, CAS system, and broadcaster correlation across all workspaces.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto shrink-0 justify-end">
          {masterFileName && (
            <button
              onClick={handleClearMaster}
              className="py-2 px-3.5 rounded-xl text-xs font-bold text-slate-400 hover:text-rose-400 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-rose-900/60 transition flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Trash2 size={12} />
              <span>Clear Catalog</span>
            </button>
          )}

          {onNavigateToProducts && (
            <button
              onClick={onNavigateToProducts}
              className="py-2 px-4 rounded-xl text-xs font-extrabold bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white transition flex items-center gap-2 shadow-lg shadow-indigo-950/40 cursor-pointer"
            >
              <ShoppingBag size={13} />
              <span>Go to Products Report</span>
              <ArrowRight size={13} />
            </button>
          )}
        </div>
      </div>

      {saveNotification && (
        <div className="bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 size={15} className="text-emerald-400 shrink-0" />
          <span>{saveNotification}</span>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-h-0 bg-slate-950/30 border border-slate-850/60 rounded-3xl p-5 overflow-hidden flex flex-col lg:flex-row gap-5 shadow-2xl">
        {/* Left Column: Upload & Mapping Parameters */}
        <div className="w-full lg:w-[38%] shrink-0 flex flex-col gap-4 overflow-y-auto pr-1">
          {/* Upload Card */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4.5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-850 pb-3">
              <div className="flex items-center space-x-2">
                <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  <Upload size={14} />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">1. Master Catalog File</h3>
                  <p className="text-[10px] text-slate-500">Upload central product database</p>
                </div>
              </div>
              {masterFileName && (
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full font-bold">
                  Active
                </span>
              )}
            </div>

            {masterFileName ? (
              <div className="bg-slate-950/80 border border-slate-800/90 rounded-2xl p-4 flex flex-col items-center justify-center space-y-3">
                <div className="p-3 bg-indigo-500/10 rounded-2xl text-indigo-400 border border-indigo-500/20">
                  <FileSpreadsheet size={26} />
                </div>
                <div className="text-center">
                  <p className="text-xs font-bold text-slate-100 truncate max-w-[240px]" title={masterFileName}>{masterFileName}</p>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                    ({(masterFileSize / 1024).toFixed(0)} KB • {masterRawRows.length.toLocaleString()} Rows)
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-[10.5px] font-bold text-slate-300 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw size={11} />
                    <span>Replace File</span>
                  </button>
                  <button
                    onClick={handleClearMaster}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-rose-950/50 border border-slate-800 hover:border-rose-900/60 text-[10.5px] font-bold text-slate-400 hover:text-rose-400 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 size={11} />
                    <span>Remove</span>
                  </button>
                </div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => handleMasterFileSelect(e.target.files)}
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                />
              </div>
            ) : (
              <div
                onDragOver={(e) => { e.preventDefault(); setIsMasterDragging(true); }}
                onDragLeave={() => setIsMasterDragging(false)}
                onDrop={(e) => { e.preventDefault(); setIsMasterDragging(false); handleMasterFileSelect(e.dataTransfer.files); }}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center min-h-[140px] ${
                  isMasterDragging
                    ? "border-indigo-500 bg-indigo-950/20"
                    : "border-slate-800 hover:border-indigo-500/50 bg-slate-950/40 hover:bg-indigo-950/10"
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => handleMasterFileSelect(e.target.files)}
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                />
                {isMasterParsing && masterParseProgress ? (
                  <div className="space-y-2 w-full text-center py-2">
                    <div className="flex items-center justify-center gap-2 text-indigo-400">
                      <RefreshCw size={16} className="animate-spin" />
                      <span className="text-xs font-bold text-slate-200">Parsing Catalog...</span>
                    </div>
                    <div className="bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800 mx-4 shadow-inner">
                      <div
                        style={{ width: `${masterParseProgress.percent}%` }}
                        className="bg-indigo-500 h-full rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(99,102,241,0.5)]"
                      />
                    </div>
                    <p className="text-[10px] text-slate-400">{masterParseProgress.stage}</p>
                  </div>
                ) : (
                  <>
                    <Upload size={22} className="text-indigo-400 mb-2" />
                    <span className="text-xs font-bold text-slate-200">Click or Drag Master File</span>
                    <span className="text-[10.5px] text-slate-500 mt-1">Accepts Excel (.XLSX, .XLS) and .CSV</span>
                  </>
                )}
              </div>
            )}

            {/* Header Configuration Mapping */}
            {masterColumns.length > 0 && (
              <div className="space-y-3.5 pt-3 border-t border-slate-850">
                <div className="flex items-center space-x-1.5">
                  <Sliders size={13} className="text-indigo-400" />
                  <span className="text-[11px] font-black uppercase text-indigo-400 tracking-wider">2. Map Field Headers</span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-400 text-[10px] uppercase flex justify-between">
                      <span>Product ID Header *</span>
                      <span className="text-[9px] text-rose-400 font-bold">Required</span>
                    </label>
                    <select
                      value={masterMapping.productIdCol}
                      onChange={(e) => setMasterMapping(p => ({ ...p, productIdCol: e.target.value }))}
                      className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl p-2.5 focus:outline-none focus:border-indigo-500 text-xs cursor-pointer"
                    >
                      <option value="">-- Select Product ID --</option>
                      {masterColumns.map((col, idx) => (
                        <option key={`id-${col}-${idx}`} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-400 text-[10px] uppercase">Product Name Header</label>
                    <select
                      value={masterMapping.productNameCol}
                      onChange={(e) => setMasterMapping(p => ({ ...p, productNameCol: e.target.value }))}
                      className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl p-2.5 focus:outline-none focus:border-indigo-500 text-xs cursor-pointer"
                    >
                      <option value="">-- Select Product Name --</option>
                      {masterColumns.map((col, idx) => (
                        <option key={`name-${col}-${idx}`} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-400 text-[10px] uppercase">CAS System Header</label>
                    <select
                      value={masterMapping.casCol}
                      onChange={(e) => setMasterMapping(p => ({ ...p, casCol: e.target.value }))}
                      className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl p-2.5 focus:outline-none focus:border-indigo-500 text-xs cursor-pointer"
                    >
                      <option value="">-- Select CAS Code --</option>
                      {masterColumns.map((col, idx) => (
                        <option key={`cas-${col}-${idx}`} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-400 text-[10px] uppercase">Broadcaster Header</label>
                    <select
                      value={masterMapping.broadcasterCol}
                      onChange={(e) => setMasterMapping(p => ({ ...p, broadcasterCol: e.target.value }))}
                      className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl p-2.5 focus:outline-none focus:border-indigo-500 text-xs cursor-pointer"
                    >
                      <option value="">-- Select Broadcaster --</option>
                      {masterColumns.map((col, idx) => (
                        <option key={`broad-${col}-${idx}`} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  onClick={handleSaveMasterMapping}
                  disabled={!masterMapping.productIdCol}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer shadow-md ${
                    masterMapping.productIdCol
                      ? "bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-950/40 active:scale-[0.98]"
                      : "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-800/80"
                  }`}
                >
                  <Check size={13} />
                  <span>CONFIRM & SAVE MAPPING</span>
                </button>
              </div>
            )}
          </div>

          {/* Advanced Logic Toggles */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4.5 space-y-3 shadow-xl">
            <div className="flex items-center space-x-1.5 pb-2 border-b border-slate-850">
              <SlidersHorizontal size={13} className="text-amber-400" />
              <h4 className="text-[11px] font-black uppercase text-amber-400 tracking-wider">3. Advanced Matching Logic</h4>
            </div>

            <div className="space-y-2.5 pt-1">
              <label className="flex items-center justify-between cursor-pointer p-2 rounded-xl bg-slate-950/40 border border-slate-850 hover:bg-slate-950/60 transition">
                <div>
                  <span className="text-xs font-bold text-slate-200 block">Use Unique Only</span>
                  <span className="text-[10px] text-slate-500">De-duplicate identical product IDs</span>
                </div>
                <input
                  type="checkbox"
                  checked={useUniqueOnly}
                  onChange={(e) => setUseUniqueOnly(e.target.checked)}
                  className="rounded border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer h-4 w-4"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer p-2 rounded-xl bg-slate-950/40 border border-slate-850 hover:bg-slate-950/60 transition">
                <div>
                  <span className="text-xs font-bold text-slate-200 block">Exclude '0' Products</span>
                  <span className="text-[10px] text-slate-500">Ignore empty/zero ID values</span>
                </div>
                <input
                  type="checkbox"
                  checked={ignoreZeroProductEnabled}
                  onChange={(e) => setIgnoreZeroProductEnabled(e.target.checked)}
                  className="rounded border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer h-4 w-4"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer p-2 rounded-xl bg-slate-950/40 border border-slate-850 hover:bg-slate-950/60 transition">
                <div>
                  <span className="text-xs font-bold text-slate-200 block">Both No Value Match</span>
                  <span className="text-[10px] text-slate-500">Treat missing data as aligned</span>
                </div>
                <input
                  type="checkbox"
                  checked={bothNoValue}
                  onChange={(e) => setBothNoValue(e.target.checked)}
                  className="rounded border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer h-4 w-4"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: Preview of mapped master products */}
        <div className="flex-1 min-h-0 flex flex-col bg-slate-900/20 border border-slate-800/60 rounded-2xl p-4 shadow-inner overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-850 pb-3 shrink-0">
            <div>
              <h3 className="text-xs font-extrabold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Eye size={13} className="text-indigo-400" />
                <span>Catalog Mapping Preview</span>
              </h3>
              <p className="text-[10px] text-slate-500 mt-0.5">Live view of parsed master product structures</p>
            </div>

            {masterProducts.length > 0 && (
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <div className="relative w-full sm:w-56 shrink-0">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={12} />
                  <input
                    type="text"
                    placeholder="Search by ID, Name, CAS, Broadcaster..."
                    value={masterSearch}
                    onChange={(e) => {
                      setMasterSearch(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-500 rounded-xl pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Mapped Table Preview */}
          <div className="flex-1 overflow-auto mt-3 rounded-xl border border-slate-850/60 bg-slate-950/40">
            {masterProducts.length === 0 ? (
              <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-center p-8 space-y-4">
                <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-850/60 text-indigo-400">
                  <Info size={28} />
                </div>
                <div className="max-w-sm space-y-1.5">
                  <p className="text-xs font-bold text-slate-200 uppercase tracking-wider">No Master Mappings Available</p>
                  <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
                    Upload your Master Product database catalog spreadsheet in the left card, then select your standard header keys to instantiate the directory.
                  </p>
                </div>
              </div>
            ) : (
              <table className="w-full text-left border-collapse min-w-[550px]">
                <thead>
                  <tr className="bg-slate-950 border-b border-slate-850 text-[10px] uppercase font-black tracking-wider text-slate-400 select-none sticky top-0 z-10 shadow-sm">
                    <th className="py-2.5 px-4 font-bold">#</th>
                    <th className="py-2.5 px-4 font-bold">Product ID</th>
                    <th className="py-2.5 px-4 font-bold">Product Name</th>
                    <th className="py-2.5 px-4 font-bold">CAS System</th>
                    <th className="py-2.5 px-4 font-bold">Broadcaster / Operator</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-900 text-xs">
                  {paginatedRows.map((p, idx) => (
                    <tr key={`${p.id}-${idx}`} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-2.5 px-4 font-mono text-[10.5px] text-slate-500">
                        {(currentPage - 1) * pageSize + idx + 1}
                      </td>
                      <td className="py-2.5 px-4 font-mono font-bold text-indigo-300">{p.id}</td>
                      <td className="py-2.5 px-4 text-slate-200 font-semibold">{p.name}</td>
                      <td className="py-2.5 px-4 text-slate-400 font-mono text-[11px]">{p.cas}</td>
                      <td className="py-2.5 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/10 border border-indigo-500/25 text-indigo-300">
                          {p.broadcaster}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Pagination Footer */}
          {filteredMasterRows.length > 0 && (
            <div className="flex items-center justify-between pt-3 border-t border-slate-850 text-xs text-slate-400 shrink-0">
              <span className="text-[11px] text-slate-500">
                Showing {Math.min((currentPage - 1) * pageSize + 1, filteredMasterRows.length)} to {Math.min(currentPage * pageSize, filteredMasterRows.length)} of {filteredMasterRows.length.toLocaleString()} Products
              </span>

              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-850 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold transition cursor-pointer"
                >
                  Prev
                </button>
                <span className="px-2 font-mono text-[11px] font-bold text-indigo-400">
                  {currentPage} / {totalPages}
                </span>
                <button
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage >= totalPages}
                  className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-850 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold transition cursor-pointer"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
