export interface FileState {
  fileName: string;
  totalRows: number;
  columns: string[];
  detectedKeyCol: string;
  detectedProductCol: string;
  parsedData: Record<string, string[]>; // Map of Key -> normalized products
  rawRows: any[]; // Raw parsed rows for manual inspection or column mapping adjustments
}

export interface SheetState {
  id: string; // Unique combination of fileId and sheetName
  fileId: string;
  fileName: string;
  sheetName: string;
  grid?: any[][]; // Raw sheet rows as array of arrays
  skipRows: number;
  columns: string[]; // Decoded headers for skipRows
  rawRows?: any[]; // Decoded rows as objects
  rowCount?: number; // Total row count
  detectedKeyCol: string;
  detectedProductCol: string;
  detectedCasCol?: string;
  parsedData: Record<string, string[]>; // Cleaned map of Key -> normalized products
  parsedCasData?: Record<string, string>; // Cleaned map of Key -> CAS name (for APP files)
  role: "CAS" | "SMS" | "APP" | "SKIP"; // Is this dataset card source or product system comparison?
  referenceName?: string; // Custom reference name
  useReferenceFile?: boolean;
  selectedReferenceFileId?: string;
  associatedCasName?: string;
  uniqueCasNames?: string[];
}

export interface UploadedFile {
  id: string;
  fileName: string;
  fileSize: number;
  totalRows: number;
  sheetCount: number;
  role?: "CAS" | "SMS" | "APP";
  referenceName?: string; // Custom reference name
  associatedCasName?: string;
}

export interface ValidationRecord {
  key: string;
  casName?: string;
  aProducts: string[];
  bProducts: string[];
  cProducts: string[];
  status: "MATCH" | "MISMATCH";
  aExtra: string[];
  bExtra: string[];
  cExtra: string[];
}

export interface ValidationSummary {
  totalKeys: number;
  matchCount: number;
  mismatchCount: number;
  matchRate: number; // Percentage
  onlyInA: number; // Keys only in A
  onlyInB: number; // Keys only in B
  onlyInC: number; // Keys only in C
}

export interface MasterProduct {
  id: string;
  name: string;
  cas: string;
  broadcaster: string;
}

export interface MasterMapping {
  productIdCol: string;
  productNameCol: string;
  casCol: string;
  broadcasterCol: string;
}

export interface ProductsWorkspaceFile {
  id: string;
  fileName: string;
  fileSize: number;
  rowCount: number;
  columns: string[];
  skipRows: number;
  detectedKeyCol: string;
  detectedProductCol: string;
  detectedCasCol?: string;
  parsedData: Record<string, string[]>; // Card ID -> normalized products
  parsedCasData?: Record<string, string>; // Card ID -> CAS name
  role: "CAS" | "APP";
}

export interface GlobalReferenceMapping {
  id: string;
  referenceFileId: string;
  casName: string;
}

export interface StoredReferenceFile {
  id: string;
  referenceName: string;
  originalName: string;
  fileSize: number;
  totalRows: number;
  sheetCount: number;
  headers: string[];
  savedAt: string;
  productIdCol?: string;
  referenceValueCol?: string;
  lookupMap?: Record<string, string>;
}

export interface IgnoreDigitRule {
  id: string;
  cas: string;
  length: number;
  direction: "FORWARD" | "BACKWARD";
  count: number;
}



